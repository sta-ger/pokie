[← Back to docs index](README.md)

# CLI

`pokie` ships a CLI alongside the library for creating and operating on [game packages](game-packages.md). A fresh
install has one safe first contact: `npx pokie` prints the next actions without starting a server or writing files.

```
npx pokie
# Start a ready-to-run package: npx pokie init <directory>
# Or design a Blueprint Project:   npx pokie create <name>
# Learn any workflow:              npx pokie <command> --help
```

Use `npx pokie init <directory>` when you want a prepared game package immediately. Use `npx pokie create <name>`
from an interactive terminal to design an editable Blueprint Project, or add `--blank` / `--random` for a
non-interactive blueprint. Run `npx pokie <command> --help` before a workflow for its required arguments and
options.

## `pokie --help` / `pokie -h`

Prints the general usage line, the full list of commands with their descriptions, and the next workflow choices,
then exits with status `0`:

```
pokie --help
pokie -h
```

Both flags are answered by the CLI itself before any command runs. A flag that follows a command name still belongs
to that command: `pokie build --help` is `pokie build`'s to interpret, not a top-level help request.

## `pokie --version` / `pokie -V`

Prints the installed POKIE package version and exits with status `0`. This is a CLI-level flag, so it is never
parsed as a Studio option or confused with `pokie init --version <version>`.

```
pokie --version
pokie -V
```

## Invalid commands and recovery

An unknown command exits with status `1`, explains that it is unknown, and gives a next step. A close spelling is
suggested when one is unambiguous; for example, `pokie creat` suggests `pokie create --help`. Otherwise, run
`pokie --help` to browse every command. Command-specific missing arguments and option values also exit with status
`1` and print that command's `Usage:` line, which shows the required input.

## `pokie create [name]`

Designs a **Blueprint Project** — a standalone `GameBlueprint` JSON file (reels, symbols, paytable, reel
weighting) — through an interactive wizard, rather than a ready-to-run package. Reach for this when you want that
Blueprint file on its own: to build it with [`pokie build <file> --target tsPackage --out <dir>`](#pokie-build-project),
or to feed it into another tool (PAR sheet import/export, reel strip generation, a build pipeline of your own). To get a
ready-to-run package directly instead — the recommended way to start a new game — use
[`pokie init`](#pokie-init-directory) below.

```
npm i -g pokie
pokie create sample-slot
```

Run in a terminal, `pokie create [name]` launches an interactive wizard that asks, in order, for: game id/name/
version; reels/rows; symbols; wild symbols; scatter symbols; available bets; paylines; paytable; reel weighting
(symbol weights or explicit reel strips); scatter-triggered free games (only asked at all if a scatter symbol was
declared); and the destination file. A given `<name>` *pre-fills* the id/name questions' own default instead of
requiring it to be typed. Once every question is answered, it prints a preview of the resulting blueprint and asks
for confirmation before writing anything:

```
Preview:
  Game:        Sample Slot (id: "sample-slot", v0.1.0)
  Layout:      5 reels x 3 rows
  Symbols:     A, K, Q, J
  Paytable:    4 symbol(s) with payouts
  Bets:        1, 2, 5
  Mechanics:   (none)
  Destination: ./sample-slot.blueprint.json

Save this blueprint? [Y/n]: y
  created  ./sample-slot.blueprint.json

Game blueprint "Sample Slot" (id: "sample-slot") created at "./sample-slot.blueprint.json".

Build it:
  pokie build ./sample-slot.blueprint.json --target tsPackage --out <dir> --dry-run
  pokie build ./sample-slot.blueprint.json --target tsPackage --out <dir>
```

Declining that confirmation, cancelling (**Ctrl+C**), or closing the input stream (**EOF**) at any point — including
at the confirmation itself, or because the destination already exists — leaves no file behind; nothing is ever
written until every question has been answered and the preview has been confirmed.

### Interactive wizard walkthrough

**Every question has a default and shows it in `[brackets]`**, so pressing Enter through the entire wizard — without
typing a single answer — produces a complete, valid blueprint: one that passes `GameBlueprintValidator` with no
errors. Those defaults are not a second set of values maintained here: they are read off the same canonical starter
blueprint `createStarterGameBlueprint()` builds internally, so an Enter-only run describes the same game (5×3,
symbols `A,K,Q,J`, their payouts and weights) apart from the generated id/name.

Typing an answer always overrides the default, so symbols, paytable entries and reel weighting can still be
specified by hand exactly as before. Two questions additionally accept `-` to opt out of the default entirely
rather than replace it: a paytable symbol answered with `-` gets no payout at all, and reel weighting answered
with `-` leaves weighting to the engine (no `symbolWeights`/`reelStrips` in the blueprint).

The wizard covers the same fields Studio's own guided **Design Game** editor does (game basics, layout, symbols and
their wild/scatter roles, reels, paytable, bets), plus the one mechanic Studio's guided editor doesn't offer yet:
scatter-triggered free games (see `mechanics.freeGames`) — asked only when at least one scatter symbol was
declared, since a free games award needs a scatter symbol to trigger off of. A symbol marked wild never gets its
own paytable question — an all-wild line resolves to no winning symbol id, so a payout for one would be dead data —
it always ends up with no payout in the written blueprint. Selectable bet modes (`betModes`) aren't offered yet;
add those by hand-editing the generated blueprint.

The game id question offers a ready-made suggestion rather than requiring one to be typed: the wizard mints a
single [`SlotGameNameGenerator`](#slotgamenamegenerator--randomgameblueprintgenerator) result once at the start of
the run — the same generator Design Game uses directly, never a second naming implementation — and offers its
`packageName` (e.g. `[blazing-riches]`) as the id default — the plain, words-only form, never `slug`'s numerically
suffixed one, since this id becomes the written filename's own default stem. Pressing Enter accepts it; typing
anything else always wins and is used verbatim as the id instead. That one suggestion is minted before the id
question's own reprompt loop, so it stays exactly the same across however many invalid attempts that question
takes — it is never re-rolled mid-run. The name question's own default follows suit: accepting the suggested id
defaults the name to the suggestion's `title` (e.g. `Blazing Riches`); typing a different id instead falls back to
title-casing that typed id, the same as before this generator integration existed.

The wizard assembles a plain `GameBlueprint` object — the same shape a `<config.json>` file has — and hands it to
`GameBlueprintValidator`, so everything in [`pokie build`](#pokie-build-project)'s own section (the field
format, validation rules) applies identically; the wizard has no *generation* logic of its own. It does do light,
per-prompt input-shape checks (a number is a number, a symbol id isn't blank, ...), and a handful of these
deliberately mirror `GameBlueprintValidator`'s own error-level rules — specifically the ones cheap to check
immediately against fields already collected earlier in the same run (a paytable `matchCount` between 2 and the
chosen reel count; a reel-weighting/reel-strip symbol that's actually one of the symbols entered earlier) — so a
typo is caught and re-asked on the spot instead of only surfacing as a validator error after answering every
remaining question. This is a convenience, not a second source of truth: the final answer is always whatever
`GameBlueprintValidator` decides once the wizard hands off its result, same as for `<config.json>`.

Per-question input handling:

- An answer that doesn't parse (e.g. non-numeric reels, a duplicate symbol id, a malformed `matchCount:multiplier`
  pair, a paytable `matchCount` outside `2..reels`, a reel-weighting symbol not among the symbols entered earlier)
  prints a one-line reason and re-asks the same question — it never silently drops or guesses at bad input.
- Pressing **Ctrl+C** at any prompt cancels the wizard gracefully: it prints `Create cancelled.` and exits with a
  non-zero status without writing anything, rather than a stack trace. So does closing/exhausting the input stream
  (EOF) — e.g. a scripted/piped run that provides fewer answers than the wizard asks for.
- The paytable and reel-strip prompts are asked once per symbol/reel (so the number of prompts scales with how
  many symbols/reels you configured earlier in the same run).
- Reel weighting is a single choice up front — blank for default weights covering exactly the symbols entered
  earlier (the preset's own weight for every symbol it knows, a rarest-first fallback for any it doesn't), `w` for
  symbol weights typed by hand (one combined `symbol:count` line), `s` for explicit reel strips (one line per
  reel), or `-` for the engine's built-in default weighting — mirroring the blueprint's own
  `reelStrips`/`symbolWeights` mutual exclusivity.
- A blank paytable answer applies that symbol's default payouts rather than leaving it unpaid: the preset's own
  entry when it fits the chosen reel count, otherwise a generated ladder that respects it (match counts never
  exceed `reels`, and matching more never pays less). Answer `-` to leave a symbol without a payout.
- Symbol ids can't contain `:` — the wizard's own prompts reuse it as a pair separator later on (paytable, symbol
  weights), so a symbol id containing one would be unparseable there.
- Wild/scatter symbols must each be one of the symbols already entered, and a symbol can't be both at once. Leaving
  either question blank omits `wilds`/`scatters` from the blueprint entirely, rather than writing out an empty list.
- Free games, when asked at all, offers the first declared scatter as the trigger symbol's own default (or `-` to
  skip the mechanic entirely), then asks for its `matchCount:games` award pairs (e.g. `3:8,4:15,5:20`).

Answers can also be piped/scripted (e.g. `printf '...\n...\n' | pokie create`, or piping a saved answers file) —
each question is answered from the piped input in the same order it would be asked interactively, one line per
prompt, and the same reprompt-on-invalid-input and EOF-cancellation rules apply.

Without a real terminal to run the wizard in (a script, CI, or any other non-interactive invocation), `pokie
create`/`pokie create [name]` exits immediately with guidance toward its two non-interactive shortcuts below,
instead of hanging or silently cancelling:

```
pokie create needs an interactive terminal to run its Blueprint wizard, and this one is not connected to one.
Re-run inside a terminal, or use a non-interactive shortcut instead: "pokie create --blank" (a bare-minimum
blueprint) or "pokie create --random" (an always-valid randomly generated one).
```

Options:

- `--blank` — **non-interactively** write the bare-minimum blueprint (3x3, three symbols, one payout each, no
  paylines/`symbolWeights`/`availableBets`) instead of running the wizard — never prompts, for someone who wants to
  author every field themselves or run this from a script. `<name>` still overrides the manifest id/name;
  `--out <file>` still picks the destination.
- `--out <file>` — the wizard's own destination question defaults to this instead of
  `./<manifest.id>.blueprint.json` (still editable, like every other question); with `--blank`/`--random`, writes
  here directly, without asking. It fails if the destination file already exists — pick a different `--out` path,
  or remove/edit the existing file first.

### `pokie create [name] --random`

Writes a random, always-valid `GameBlueprint` to a Blueprint Project file, rather than building a package — same as
the plain `pokie create` path above, just with randomly generated content. This is POKIE's one entry point for
first-class random game generation — there is no `pokie build random`/`--random`; building the written file into a
real package is a separate, explicit second step (see below). Its reel weighting is always expressed as valid
**per-reel generation**: an independent, reproducible `reelStripGeneration` entry per reel, inspectable straight
off the written file. For `--preset default`, `DefaultRandomGameBlueprintStrategy` already generates its reel
weighting this way by itself; for `--preset variant`, when `RandomGameBlueprintVariantStrategy` instead picks a
flat `symbolWeights` map, `pokie create` converts it into the same per-reel shape (targeting the same symbol:weight
ratio) before writing — a blueprint that already carries its own literal `reelStrips`/`reelStripGeneration` is left
untouched.

```
pokie create --random                          # name and file path picked for you
pokie create my-random-game --random           # named ./my-random-game.blueprint.json instead
pokie create --random --seed 42                # reproduce a specific earlier random blueprint
pokie create --random --seed 42 --preset variant # same seed, richer strategy -- a different game
pokie create --random --out my-game.blueprint.json # write to a specific path instead
```

```
Generated random game "Blazing Riches" (id: "blazing-riches") from seed 1845220913.
Reproduce this exact game with: pokie create --random --seed 1845220913 --preset default
Provenance: generator 1.1.0, strategy "default-line-pay".
  created  ./blazing-riches.blueprint.json

Game blueprint "Blazing Riches" (id: "blazing-riches") created at "./blazing-riches.blueprint.json".

Build it:
  pokie build ./blazing-riches.blueprint.json --target tsPackage --out <dir> --dry-run
  pokie build ./blazing-riches.blueprint.json --target tsPackage --out <dir>
```

`<name>`, when given, is used verbatim as the manifest name (and, via the default output path, the written
filename); omitted, a generated name/id is used for both instead. The blueprint is validated before writing — a
validation error exits non-zero with a printed explanation instead of writing anything — but nothing is ever built
or smoke-simulated here: `pokie create --random` only ever writes the blueprint file. Feed the result into
[`pokie build <file> --target tsPackage --out <dir>`](#pokie-build-project) for a real, playable package.

> **No target-RTP promise.** `RandomGameBlueprintGenerator`'s math is *structurally* valid — every blueprint it
> produces is guaranteed to pass [`GameBlueprintValidator`](#validation) with zero errors and zero warnings, by
> construction — but it is not production-tuned math: it makes no promise about what RTP, volatility, or win-size
> distribution a specific generated game will settle at. Run a real [`pokie sim`](#pokie-sim-packageroot) (thousands
> of rounds) on the built package before treating a randomly generated game as anything more than a structurally
> sound starting point.

`--random` generates a complete `GameBlueprint` in memory using two public, standalone services also available
programmatically:

- [`SlotGameNameGenerator`](#slotgamenamegenerator--randomgameblueprintgenerator) — picks a themed name (e.g.
  `title: "Blazing Riches"`) from small curated word lists, projected as a `title`/`slug`/`packageName` triple;
- [`RandomGameBlueprintGenerator`](#slotgamenamegenerator--randomgameblueprintgenerator) — fills in reels (3-6),
  rows (3-4), 5-8 symbols, a paytable, and reel weights, using `SlotGameNameGenerator` for the manifest, and one
  of two `RandomGameBlueprintStrategy` implementations (see `--preset` below) for the mechanic-bearing fields.

Both take an optional integer `seed`: the same seed (and the same `--preset`) always produces the exact same
name/blueprint. Options:

- `--seed <integer>` — reproduce a specific earlier random game. Omit it to mint a fresh one — the seed actually
  used is always echoed back on the first line, together with the exact command to reproduce it.
- `--preset default|variant` — which `RandomGameBlueprintStrategy` fills in the mechanic-bearing fields. Defaults
  to `default`:
  - `default` (`DefaultRandomGameBlueprintStrategy`, `provenance.strategy` `"default-line-pay"`) — the minimal
    line-pay shape (reels/rows/symbols/paytable/`reelStripGeneration`, default paylines, no
    wilds/scatters/`winModel`) — its reel weighting is always inspectable, already-per-reel-generated content, not
    a flat `symbolWeights` map;
  - `variant` (`RandomGameBlueprintVariantStrategy`, `provenance.strategy` `"random-variant"`) — a richer shape
    drawn from the same guaranteed-valid space: custom paylines, "ways"/"clusters" `winModel`, and literal
    `reelStrips` in place of `symbolWeights`, picked per build (never combining `paylines` with a `winModel`, since
    `GameBlueprintValidator` warns on that combination).
  Same seed *and* same `--preset` always reproduces the same blueprint — switching `--preset` with the same seed
  produces a different game, since it selects an entirely different strategy.

The line right after the reproduce-command hint — `Provenance: generator <generatorVersion>, strategy
"<strategy>".` — echoes `RandomGameBlueprintResult.provenance` (also available programmatically, see below):
`generatorVersion` identifies `RandomGameBlueprintGenerator`'s own algorithm version (bumped only when a change
would make the same seed produce a different blueprint) and `strategy` identifies which `RandomGameBlueprintStrategy`
actually built the mechanics (`"default-line-pay"` or `"random-variant"`) — together with the seed, enough to know
*exactly* what produced a given generated blueprint without re-deriving it from its own content.

#### `SlotGameNameGenerator` / `RandomGameBlueprintGenerator`

Both are ordinary, standalone exports from `"pokie"` — useful outside the CLI too (tooling, tests, generating
several candidate games to pick from):

```ts
import {RandomGameBlueprintGenerator, RandomGameBlueprintVariantStrategy, SlotGameNameGenerator} from "pokie";

const {title, slug, packageName} = new SlotGameNameGenerator().generate();          // fresh every call
const reproduced = new SlotGameNameGenerator().generate({seed: 42});                // deterministic for seed 42
const themed = new SlotGameNameGenerator().generate({theme: "cosmic", style: "bold", wordCount: 3});
const batch = new SlotGameNameGenerator().generateUnique(5, {seed: 42});            // 5 distinct titles, one seed

const {blueprint, seed, provenance} = new RandomGameBlueprintGenerator().generate(); // seed is minted and echoed back
const reproduced = new RandomGameBlueprintGenerator().generate({seed}); // .blueprint deep-equals blueprint above
const variant = new RandomGameBlueprintGenerator(new SlotGameNameGenerator(), new RandomGameBlueprintVariantStrategy());
```

`SlotGameNameGenerator.generate(request?)` accepts an optional `seed`, `theme`, `style`, `wordCount` (`2 | 3`),
`exclusions` (titles to never produce), and a custom `vocabulary` (`{adjectives, nouns}`) that fully replaces the
built-in theme/style word pools. `generateUnique(count, request?)` returns `count` results sharing one batch seed,
with pairwise-distinct titles; either method throws `SlotGameNameExhaustedError` if the vocabulary/exclusions are
too tight to satisfy within its attempt budget. `title` is the display name, `slug` is a directory/manifest-id-safe
form with a numeric suffix (e.g. `"blazing-riches-4821"`), and `packageName` is an npm-package-name-safe form with
no suffix (e.g. `"blazing-riches"`) — the same title always yields the same `packageName`, unlike `slug`. The
suffixed `slug` is available through the design workflow when a guaranteed-distinct id is wanted, but nothing that *creates*
a game uses it: both [`pokie create`](#pokie-create-name)'s own wizard and `RandomGameBlueprintGenerator` name
games from `packageName`, so generated ids stay words-only.

`RandomGameBlueprintGenerator.generate(request?)` accepts an optional `{seed?, overrides?}` — `overrides` is an
`{id?, name?}` override (what `pokie create [name] --random` uses to pin the manifest to the given `<name>` instead
of a generated one) — pass a `name` to use it verbatim with an id slugified from it, or both `id`/`name` to pin both
explicitly. Its constructor optionally takes a name generator, a `RandomGameBlueprintStrategy` (defaults to
`DefaultRandomGameBlueprintStrategy`; pass `RandomGameBlueprintVariantStrategy` for the same richer mechanics
`--preset variant` selects), and a `GameMechanicCompatibilityPolicy` that rejects an incompatible strategy at
construction time rather than at `generate()` time. The result's `provenance` (`{generatorVersion, strategy, seed}`)
is what the CLI's `Provenance: ...` output line above echoes.

`SlotGameNameGenerator` is also the implementation behind every name the CLI itself suggests — Design Game (see
below) and [`pokie create`](#pokie-create-name)'s own wizard's game-id suggestion both call through it directly;
neither re-implements naming, slugging, or theming on its own.

## `pokie edit <blueprint> [--out <file>]`

Interactively edits an existing **Blueprint Project** (a `GameBlueprint` JSON file — see [`pokie
create`](#pokie-create-name)) through the exact same wizard `pokie create` runs, just seeded with the file's own
current values instead of the starter template:

```
pokie edit sample-slot.blueprint.json
```

Every question shows the value already on the loaded file as its own default, and pressing Enter *preserves* it
rather than falling back to some other value — the same "traverse every section" flow `pokie create` uses (game
basics, layout, symbols/wild/scatter roles, available bets, paylines, paytable, reel weighting, scatter-triggered
free games), just editing in place instead of designing from scratch. Once every question is answered, it validates
the result (same `GameBlueprintValidator` every other Blueprint path uses — see [`pokie build`](#pokie-build-project)
for the field/validation rules) and prints a diff against the file as it was loaded:

```
Changes:
  version: 0.1.0 -> 0.2.0
  symbols: ["A","K","Q","J"] -> ["A","K","Q","J","W"]
  wilds: (none) -> ["W"]

Destination: sample-slot.blueprint.json

Save this blueprint? [Y/n]: y

  saved  sample-slot.blueprint.json

Game blueprint "Sample Slot" (id: "sample-slot") saved at "sample-slot.blueprint.json".
```

Nothing is written until that confirmation — declining it, cancelling (**Ctrl+C**), closing the input stream
(**EOF**), or a validation error all leave the original file completely untouched, at any point in the run. The
write itself is atomic (staged beside the destination, then renamed into place — see `writeFileAtomically`), so a
failed or interrupted save can never leave a truncated or partially-edited file behind either.

`--out <file>` is a **Save As**: the result is always written there instead of overwriting `<blueprint>`, leaving the
original file untouched. The destination question still shows `--out`'s value as its own default and still asks, but
unlike every other question here it isn't actually editable — whatever it's answered, the file is written to `--out`.

A blueprint whose reel weighting is a "generated" `reelStripGeneration` (see [`pokie reel
generate`](#pokie-reel-generate-blueprintjson) and `docs/reel-strip-generation.md`) has that field carried through
completely untouched — the reel-weighting question isn't even asked in that case, since this wizard has no way to
represent that shape. `pokie reel generate` remains the one dedicated editor for it; edit everything else about the
blueprint with `pokie edit`, then adjust its generated reels separately.

Pointed at a path that resolves to a project type other than `blueprint` (an already-built `tsPackage`, a `wasm`
component, an `outcomeLibrary`/`stakeAdapter` export, a `parWorkbook`), `pokie edit` never even reaches the wizard —
it reports the same resolver-derived capability diagnostic every other migrated CLI command does (see
`describeUnsupportedProjectOperation`), explaining which capability is missing and which project types actually
support editing:

```
"edit" is not supported for a "tsPackage" project (missing the "blueprint.build" capability). No project type currently supports it.
```

Without a real terminal to run the wizard in (a script, CI, or any other non-interactive invocation), `pokie edit`
exits immediately with guidance instead of hanging or silently doing nothing — there's no non-interactive shortcut
here the way `pokie create --blank`/`--random` offer: hand-edit the JSON file directly, then check it with `pokie
validate`/`pokie build --dry-run`.

## `pokie build <project>`

POKIE's universal build pipeline: resolves `<project>` to a POKIE project and builds `--target <artifact>` from
it, writing the result to `--out <path>` (default: a `<target>`-named sibling of `<project>`, e.g. building
`tsPackage` from `./blueprints/sample-slot.blueprint.json` defaults to `./blueprints/tsPackage`).

The build command supports targets: `blueprint`, `tsPackage`, `outcomeLibrary`, `stakeAdapter`, and `parWorkbook`.
It can resolve a compatible `wasm` component only to reject conversion before publication: WASM is an
inspection-only input, not a source workflow or a build target.

## `pokie generate <packageRoot>`

Generates a weighted outcome library from a runnable package's exact-enumeration runtime. The normal exact path
fails safely when the outcome space is too large or the game does not support exact enumeration; use the explicit
sampled form only when its deterministic approximation is the workflow you intend:

```
pokie generate ./sample-slot --out outcomes.json
pokie generate ./sample-slot --sample 10000 --seed audit-seed --format json --out outcomes.json
```

`--exact` is the default and is mutually exclusive with `--sample <n> --seed <string>`. `--estimate` (or
`--dry-run`) reports the selected strategy without writing or enumerating outcomes. `--mode`, `--stake`,
`--config-hash`, `--library-id`, `--max-outcome-space-size`, `--resume`, and `--progress` retain their exact
meanings from `pokie generate --help`; the help output is the complete grammar for this intentionally
specialized workflow.

## `pokie build <project> --target <artifact>`

The public CLI supports the executable output formats `json`, `markdown`, and `html`. Project-defined mode names are accepted where a command exposes `--mode`; `pokie sim` additionally accepts `all` to process every declared mode.

```
pokie build <project> --target <artifact> [--exact | --sample <n> --seed <string>] [--out <path>] [--dry-run]
```

```
pokie build examples/blueprints/sample-slot.blueprint.json --target tsPackage --out sample-slot
cd sample-slot
npm install
```

Options:

- `<project>` — a path the CLI resolves to a POKIE project: a `GameBlueprint` JSON file (a `blueprint` project), or an
  already-built `tsPackage`/`outcomeLibrary`/`stakeAdapter`/`parWorkbook` artifact directory/file. Missing or
  unrecognized throws, naming the project types the CLI understands.
- `--target <artifact>` — **required**; one of `blueprint`, `tsPackage`, `outcomeLibrary`, `stakeAdapter`, `parWorkbook`.
  Never an output directory (that's `--out`, below) — omitting it, or passing an unrecognized value, throws listing
  the full accepted vocabulary. `--target` must also be buildable from `<project>`'s own resolved type — building a
  unsupported source/target pair, for instance, throws naming which source types that target actually
  supports (`ArtifactBuilderRegistry.describe(target)`, also available
  programmatically, reports the same thing without resolving a project first).
- `--exact` — only for `--target outcomeLibrary`; forces full exact enumeration instead of the managed
  bounded-coverage default for a large Blueprint/package source.
- `--sample <n> --seed <string>` — only for `--target outcomeLibrary`; explicitly chooses `n` deterministic
  bounded-coverage draws and records that choice in the library manifest.
- `--out <path>` — where the built artifact is written; optional, defaulting to a `<target>`-named sibling of
  `<project>` (a `.xlsx` file for `parWorkbook`, a `.json` file for `blueprint`, a bare directory for every other target). An explicit `--out`
  always overrides the default and never changes what `--target` means. Must not already exist, or must be an
  empty directory (a file target like `parWorkbook` must simply not exist yet) — see [Conflict
  handling](#conflict-handling-an-existing---out-destination) below.
- `--dry-run` — validate and preview without writing anything.

The executable source × target matrix is exported as `BUILD_PRODUCT_MATRIX`: its 14 supported cells are
`blueprint` → `tsPackage`/`outcomeLibrary`/`stakeAdapter`/`parWorkbook`, `tsPackage` → `outcomeLibrary`/`stakeAdapter`,
`outcomeLibrary` → `outcomeLibrary`/`stakeAdapter`, `stakeAdapter` → `stakeAdapter`, and `parWorkbook` →
`blueprint`/`tsPackage`/`outcomeLibrary`/`stakeAdapter`/`parWorkbook`. Every other advertised cell reports its exact missing prerequisite and a next command. WASM remains
inspection-only. PAR-derived targets first import a durable Blueprint intermediate; dry-run prints that stage and
any generated/reused Outcome intermediate without writing it.

A `blueprint` → `tsPackage` conversion is the classic "generate a game package from a `GameBlueprint`" path,
described in full below. Blueprint → PAR Workbook freezes generated, weighted, or default reels as a deterministic
literal snapshot in the workbook; the source Blueprint remains unchanged. Blueprint and package sources can also create or reuse their managed compatible Outcome
Library before producing an Outcome Library or Stake Engine artifact. Small finite reel-stop spaces are enumerated
exactly. To keep a newcomer-created large Blueprint usable on Node's normal memory limit, a larger managed
Blueprint/package export automatically writes a deterministic, labelled bounded-coverage library (5,000 draws;
the manifest records its strategy and seed). Use `pokie build <project> --target outcomeLibrary --exact` only when
you specifically need every outcome and have sized memory and storage for the full artifact library; `--sample <n>
--seed <seed>` selects a different deterministic coverage size explicitly. Same-type Outcome, Stake, and PAR cells
republish their recognized artifact to a new destination. Every writer is atomic and validates its input before
publishing, never attempting to recover a game model from an outcome-based artifact.

For random game generation, there is no `build random`/`--random` — generation and building are two separate,
explicit steps: [`pokie create --random`](#pokie-create-name---random) writes a Blueprint Project, then `pokie
build <the written file> --target tsPackage --out <dir>` turns it into a real package.

### `blueprint` -> `tsPackage`: generating a game package from a `GameBlueprint`

Generates a working [game package](game-packages.md) from a `GameBlueprint` — reels/rows, symbols, paylines,
paytable, and reel strips/weights for a standard line-pay video slot. It writes the exact same canonical package
file set `pokie init` does (`package.json`, `package-lock.json`, `tsconfig.json`, `README.md`, `src/index.ts`,
`dist/index.js`) — `dist/index.js` is written directly rather than requiring a real `npm install`/`npm run build`
first: it's immediately loadable by every other command below, with `src/index.ts` there so a real `npm run build`
(if you ever run one) still reproduces an equivalent `dist/index.js`. (`pokie create`, unlike `pokie build`/`pokie
init`, never writes a package at all — see [`pokie create [name]`](#pokie-create-name) above.)

To design the `GameBlueprint` first instead of building directly, use [`pokie create [name]`](#pokie-create-name)
to write a Blueprint Project file, then feed it into `pokie build <file> --target tsPackage --out <dir>` above. (For
a ready-to-run package directly instead, see [`pokie init [directory]`](#pokie-init-directory) below.) Both produce
the exact same `GameBlueprint` shape, go through the exact same validation ([`GameBlueprintValidator`](#validation))
and generation ([`GamePackageGenerator`](#pokie-build-project)), and the resulting package supports the exact same
[`build -> inspect -> validate -> sim -> report -> replay -> serve`/`dev` workflow](#workflow-build---inspect---validate---sim---report---replay---servedev).

`pokie build <config.json> --target tsPackage --out <dir>` validates the blueprint first (see below) and, if it has
no errors, creates `<dir>` — which must not already exist, or must be empty (see [Conflict
handling](#conflict-handling-an-existing---out-destination) below) — and writes:

- `package.json` — name/version/description from `manifest` (a default description if `manifest.description` is
  omitted), a `pokie` dependency, `start`/`server`/`client`/`build` scripts, and `pokie.entry`/`main`/`exports`
  all pointing at `./dist/index.js` — the exact same entry path `pokie init` packages compile their own
  TypeScript source into, written by the exact same shared `buildPackageJsonPatch` those commands use;
- `package-lock.json`/`tsconfig.json` — the same lockfile seed/compiler config `pokie init` writes (`tsconfig.json`
  via the same shared `renderTsconfig`), so `npm install && npm run build` behaves identically in a built package;
- `README.md` — a short orientation doc for the built package itself: what each file is, that `src/index.ts`/
  `dist/index.js` shouldn't be hand-edited, and the `build -> inspect -> validate -> sim -> report -> replay ->
  serve`/`dev` workflow below;
- `src/index.ts`/`dist/index.js` — a `PokieGame` implementation built from the blueprint: a `VideoSlotConfig`
  with the given reels/rows/symbols/wilds/scatters/paytable/paylines/reel strips, wrapped in a
  `VideoSlotSession`, with `getSessionSerializer()` returning `new VideoSlotSessionSerializer()`. Both files hold
  the exact same generated logic — organized into labeled sections (blueprint data, config assembly, `PokieGame`
  exports) with a short header comment naming the game and the `pokie` version that built it — no blueprint-
  hash/provenance metadata is embedded, so re-running `pokie build` on an unchanged blueprint always regenerates
  byte-identical files. `dist/index.js` is written directly, not compiled from `src/index.ts`, so the package is
  immediately loadable with no `npm install`/`npm run build` step; `src/index.ts` is typed (`GameBlueprint`
  imported from `pokie`) so a real `npm run build`, if you ever run one, reproduces an equivalent `dist/index.js`.

The built package carries no metadata of its own about where it came from — no embedded blueprint copy, no
build-info file, no `src/generated` nesting — so a later source edit or rebuild never has to reconcile against,
or is constrained by, whatever produced it originally; see [Conflict
handling](#conflict-handling-an-existing---out-destination) below.

After generation, `pokie build` prints a build summary to stdout: the files it wrote, package root,
game id/name/version, blueprint hash, and source path (when known) — all computed purely for this printout, never
persisted into the package itself. `--dry-run` prints the equivalent preview (game id/name/version, reels x rows,
symbol count, payline count, bets, blueprint hash, the files a real build would generate, and the resolved
`--out` destination — explicit or defaulted, exactly as a real build would use it) without creating or touching
that destination at all. Exit code follows the same rule either way: non-zero if the blueprint has errors, `0` if
it's valid (warnings included).

### Republishing an already-built `outcomeLibrary`/`stakeAdapter`/`parWorkbook` artifact

`--target outcomeLibrary`/`stakeAdapter`/`parWorkbook`, given a `<project>` that already resolves to that same
artifact type, atomically copies it to `--out <path>` — the same "read it back with the exporter's own importer,
re-export unchanged" round trip each format's own import/export commands already exercise (see `pokie export
<config.json> --to adapter`/`pokie import <stakeDir>` and `pokie par export <config.json>` below).
`--dry-run` here only prints a one-line
"would build \<target\> from \<project\> to \<out\>" preview — there is no blueprint to validate or summarize for
these targets, since nothing is generated, only copied.

```
pokie build ./my-outcome-bundle --target outcomeLibrary --out ./my-outcome-bundle-copy
pokie build ./my-stake-export --target stakeAdapter --out ./my-stake-export-copy
pokie build ./my-par-sheet.xlsx --target parWorkbook --out ./my-par-sheet-copy.xlsx
```

### The `GameBlueprint` format

```ts
{
    manifest: {id: string; name: string; version: string; description?: string; author?: string};
    reels: number;
    rows: number;
    symbols: string[];
    wilds?: string[];        // must be a subset of "symbols"
    scatters?: string[];     // must be a subset of "symbols"
    // Row index (0-based) per reel, one array per payline. Omit for the engine's default: one
    // horizontal line per row (VideoSlotConfig's own default via HorizontalLines).
    paylines?: number[][];
    // symbolId -> matchCount -> bet multiplier, applied across every configured bet.
    paytable: Record<string, Record<string, number>>;
    // One strip (an ordered array of symbol ids) per reel. Takes precedence over reelStripGeneration
    // and symbolWeights. Unchanged since before reelStripGeneration existed.
    reelStrips?: string[][];
    // Per-reel build-time alternative to a literal reelStrips: one entry per reel (must have exactly
    // "reels" entries), each independently either a literal strip or its own generation config — see
    // "reelStripGeneration" below. Mutually exclusive with reelStrips (an error if both are set);
    // takes precedence over symbolWeights.
    reelStripGeneration?: ReelStripGenerationSpec[];
    // symbolId -> relative count, applied uniformly (independently shuffled) to every reel. Ignored
    // when reelStrips or reelStripGeneration is present. Omit all three for the engine's built-in
    // default weighting.
    symbolWeights?: Record<string, number>;
    availableBets?: number[];
}
```

A minimal example (5x3, 3 symbols, no wilds/scatters, default paylines and reel weighting):

```json
{
    "manifest": {"id": "sample-slot", "name": "Sample Slot", "version": "0.1.0"},
    "reels": 5,
    "rows": 3,
    "symbols": ["A", "K", "Q"],
    "paytable": {
        "A": {"3": 5, "4": 10, "5": 20},
        "K": {"3": 4, "4": 8, "5": 16},
        "Q": {"3": 3, "4": 6, "5": 12}
    }
}
```

A complete example using every optional field (wilds, scatters, `symbolWeights`, `availableBets`) lives at
[`examples/blueprints/sample-slot.blueprint.json`](../examples/blueprints/sample-slot.blueprint.json) in this
repository — see [`examples/blueprints/README.md`](../examples/blueprints/README.md) for how to try it directly
from a checkout. It's also what the workflow below and `pokie build`'s own smoke test
(`tests/cli/BuildWorkflow.integration.test.ts`) both run, so it's guaranteed to actually work, not just parse.

### `reelStripGeneration` (build-time reel strip generation)

A **per-reel** alternative to hand-authoring `reelStrips`: an array with exactly one entry per reel, each entry
independently either a literal strip or its own build-time generation config run through the same
[`ReelStripGenerator`](reel-strip-generation.md) you'd use programmatically. Literal and generated reels freely mix
within one blueprint — there is no blueprint-wide shared config, every "generated" reel is entirely independent
(own `length`, own `symbolCounts`/`symbolWeights`, own `seed`, own `constraints`). `pokie build` bakes the resulting
exact strips into the generated package as plain `reelStrips` — the runtime game module never depends on the
generation API at all, only ever seeing a plain literal array (the same shape a hand-authored `reelStrips`
blueprint already has).

```ts
type ReelStripGenerationSpec =
    | {type: "literal"; strip: string[]}                    // same data a reelStrips[i] entry would hold
    | {type: "generated"} & ReelStripGenerationConfig;

type ReelStripGenerationConfig = {
    length: number;
    // Exactly one of these two must be set.
    symbolCounts?: Record<string, number>;
    symbolWeights?: Record<string, number>;
    // Required (not optional): build-time generation must be reproducible.
    seed: number;
    roundingPolicy?: "floor" | "round" | "ceil";                              // only with symbolWeights
    remainderTieBreakPolicy?: "symbol-id" | "declared-order" | "largest-weight-first"; // only with symbolWeights
    lockedPositions?: Record<number, string>;
    constraints?: ReelStripConstraintSpec[];
    maxAttempts?: number;
};
```

Generation is fully **deterministic**: each "generated" entry supplies its own `seed`, so building the same
unchanged blueprint always reproduces the same exact strip for every generated reel — and the same byte-identical
built package — exactly like a literal-`reelStrips` blueprint would.

`constraints` entries are plain JSON, not class instances — a `type` field picks which
[constraint](reel-strip-generation.md#constraints-reelstripconstraint) to build, and every other field maps onto
that constraint's own constructor parameters:

```ts
type ReelStripConstraintSpec =
    | {type: "minimumCircularDistance"; minimumDistance: number; symbolIds?: string[]; wrapAround?: boolean}
    | {type: "maximumCircularDistance"; maximumDistance: number; symbolIds?: string[]; wrapAround?: boolean}
    | {type: "maximumConsecutiveOccurrences"; maximumConsecutive: number; symbolIds?: string[]; wrapAround?: boolean}
    | {type: "forbiddenAdjacency"; pairs: [string, string][]; wrapAround?: boolean; directed?: boolean}
    | {type: "requiredAdjacency"; pairs: [string, string][]; directed?: boolean; wrapAround?: boolean}
    | {type: "forbiddenSequence"; sequence: string[]; maximumOccurrences?: number; reversed?: boolean; wrapAround?: boolean}
    | {type: "requiredSequence"; sequence: string[]; minimumOccurrences?: number; maximumOccurrences?: number; reversed?: boolean; wrapAround?: boolean};
```

A complete example (one hand-placed literal reel, four independently generated reels — different lengths, seeds,
constraints, `symbolCounts` vs. `symbolWeights`, and a locked position) lives at
[`examples/blueprints/generated-reels.blueprint.json`](../examples/blueprints/generated-reels.blueprint.json) — see
[`examples/blueprints/README.md`](../examples/blueprints/README.md) to try it directly from a checkout.

**When generation fails** — a "generated" entry's constraints can't be satisfied within its own `maxAttempts` —
`pokie build` reports it exactly like a validation error: printed per failing reel with its index, seed, attempt
count, and the closest attempt's constraint violations, then exits non-zero without writing any files. Other
reels' generation is unaffected (each is entirely independent) — only the failing reel(s) are reported. This only
runs *after* validation passes (validation only checks `reelStripGeneration`'s shape — one entry per reel, each a
well-formed `{type: "literal", strip}` or `{type: "generated", ...}` with a positive `length`, an integer `seed`,
exactly one of `symbolCounts`/`symbolWeights`, and a fully validated `constraints` array — every required field
present, correct types, unknown symbols, and numeric bounds checked per constraint `type`; see
[Validation](#validation) below) — whether a configuration is actually *satisfiable* is a question only
`ReelStripGenerator` itself can answer, by actually trying.

The built package itself carries no separate record of the generation that produced it — each generated reel's
resolved strip is materialized straight into a plain `reelStrips` array embedded in `dist/index.js`, with the
`reelStripGeneration` config (including each reel's own `seed`) gone entirely; the runtime module never depends
on the generation API. `pokie build`'s own console summary's `blueprint hash`, though, is computed from the
blueprint exactly as **authored** (with its `reelStripGeneration` array intact), not from the materialized
`reelStrips` a build produces — two different authored configs that happen to generate byte-identical strips
still hash differently.

### Validation

Every field above is checked before anything is generated: `manifest.id`/`name`/`version` must be non-empty
strings; `reels`/`rows` must be positive integers; `symbols` must be a non-empty array of unique non-empty
strings; `wilds`/`scatters` must be arrays of unique symbol ids with no overlap between the two; `wilds`/`scatters`/
`paytable` keys/`reelStrips` symbols/`reelStripGeneration` symbols/`symbolWeights` keys must all reference symbols
actually listed in `symbols`; `paytable` match-counts must be integers between 2 and `reels`, with positive
multipliers; `paylines` entries must have exactly `reels` row indexes, each within `[0, rows)`; `reelStrips` must
have exactly one strip per reel; `reelStripGeneration` must have exactly one entry per reel, each entry either a
well-formed `{type: "literal", strip}` (a non-empty array of known symbol ids) or `{type: "generated", ...}` with
a positive `length`, an integer `seed`, exactly one of `symbolCounts`/`symbolWeights`, well-shaped
`lockedPositions`, a positive `maxAttempts`, and valid `roundingPolicy`/`remainderTieBreakPolicy` enum values where
present; `availableBets` must be positive numbers.

Every `constraints[]` entry inside a `"generated"` reel is fully validated too, not just its `type`: every field
that `type` requires must be present with the correct JS type (a number, a boolean, an array of known symbol ids,
...), numeric bounds must make sense (positive/non-negative integers, and for `requiredSequence`,
`maximumOccurrences >= minimumOccurrences`), and any symbol id referenced anywhere in the spec (`symbolIds`,
sequence/pair entries, ...) must actually be listed in `symbols`.

A `symbolCounts` entry of exactly `0` is treated as **absent from that reel** for reachability purposes (it will
never actually land), exactly like a symbol simply omitted from a literal `reelStrips` entry — declaring
`{A: 5, B: 0}` does not make `B` reachable via that reel.

Since `reelStrips` (or, absent that, `reelStripGeneration`, or absent that, `symbolWeights`) fully replaces the
engine's default reel generator, every symbol referenced by `paytable`/`wilds`/`scatters` must also actually appear
somewhere across it — otherwise that payout, wild, or scatter can physically never land, which is flagged as an
error, not a warning. Note that this only checks `reelStripGeneration`'s declared `strip`/`symbolCounts`/
`symbolWeights` content — whether a `"generated"` reel's generation actually *succeeds* is checked separately,
after validation passes (see [`reelStripGeneration`](#reelstripgeneration-build-time-reel-strip-generation) above).

Setting both `reelStrips` and `reelStripGeneration` is an error (not a warning): a reel's strip must come from
exactly one of them, so there's no sensible precedence to fall back to. Within a single blueprint, though, literal
and generated reels freely mix — that mixing lives entirely inside `reelStripGeneration`'s own per-reel array (a
`{type: "literal", ...}` entry alongside `{type: "generated", ...}` entries), not between `reelStrips` and
`reelStripGeneration`.

A number of further checks catch configs that parse fine but are almost certainly mistakes, so they're reported as
**warnings** rather than errors (they don't block generation): a paytable entry for a wild symbol's own id (an
all-wild line resolves to no winning symbol id, so the entry is never looked up); setting both `reelStrips` and
`symbolWeights` (`reelStrips` wins, `symbolWeights` is ignored), or both `reelStripGeneration` and `symbolWeights`
(`reelStripGeneration` wins); duplicate `paylines` entries or duplicate `availableBets` values; a `reelStrips`
entry shorter than `rows` (guaranteed to repeat a symbol within a single spin due to wrapping); a `paytable` entry
that pays less for more matching symbols than for fewer; a non-wild, non-scatter symbol in `symbols` with no
`paytable` entry at all (it can never win anything); and `reels`/`rows` values above 10 (unusually large for a
line-pay video slot).

#### Math-quality warnings

A further set of warnings look for blueprints that parse and generate fine but are likely to produce an
unrealistic RTP — the exact kind of mistake that's easy to make by hand and only obvious after running
[`pokie sim`](#pokie-sim-packageroot). All of these are static, cheap checks on the blueprint's own numbers (not a
simulation) and only apply to non-scatter, non-wild symbols with at least one payout — scatters are exempt, since
their economics (paying from 2-of-a-kind, much bigger multipliers) are legitimately different:

- **Frequent low-match payouts** (`blueprint-paytable-frequent-low-match`) — a payout at 2 matching symbols. Most
  line-pay symbols start at 3-of-a-kind; paying from 2 hits very often and inflates hit frequency and RTP.
- **Missing base payout** (`blueprint-paytable-missing-base-payout`) — payouts defined only for 4/5-of-a-kind but
  not 3, when `reels` is at least 3.
- **Generous entry-tier payout** (`blueprint-paytable-generous-entry-payout`) — a symbol's lowest configured
  match-count pays more than 10x bet, unusually generous for what's normally the most frequently-hit tier.
- **No low/high-pay tiering** (`blueprint-paytable-no-tiering`) — every symbol with a payout tops out at the exact
  same multiplier, so there's no differentiation between filler and premium symbols.
- **A symbol dominates the reels** (`blueprint-weighting-dominant-symbol`) — one symbol makes up more than 40% of
  `symbolWeights` (or `reelStripGeneration`'s own `symbolCounts`/`symbolWeights`, or, counting occurrences across
  every strip, `reelStrips`), crowding out the rest.
- **A wild is too common** (`blueprint-weighting-wild-too-common`) — a wild symbol's weight is at least as high as
  the average of the regular symbols. Wilds substitute for everything, so landing this often inflates RTP well
  beyond what the paytable alone suggests.
- **Payout doesn't track rarity** (`blueprint-weighting-pay-mismatch`) — a higher-paying symbol isn't rarer (in
  `symbolWeights`/`reelStripGeneration`/`reelStrips`) than a lower-paying one. This is the most common way a
  blueprint's RTP quietly runs away: identical weights across symbols with different payouts (every symbol equally
  likely, but some worth much more) mean the high-value symbol lands just as often as the low-value one — see
  [`examples/blueprints/sample-slot.blueprint.json`](../examples/blueprints/sample-slot.blueprint.json)'s own
  `symbolWeights`/`paytable` for what a fix looks like (low-pay symbols weighted heavier, high-pay symbols rarer).

None of these check the actual math (that's what [`pokie sim`](#pokie-sim-packageroot) is for) — they flag shapes
that are very likely to be a mistake, so run `pokie sim --rounds 100000` on anything they flag before trusting the
math either way.

Every error is printed with its code and message, so a failed `pokie build` always tells you what's wrong before
generating anything.

Failure modes:

- `<project>` missing, or not recognized as a POKIE project at all (`pokie build` with no arguments, or an unknown
  option) throws a `Usage: pokie build <project> --target <artifact> [--out <path>]` error naming the project types
  the CLI understands.
- `--target` omitted, or given a value outside `tsPackage`/`outcomeLibrary`/`stakeAdapter`/`parWorkbook`,
  throws before `<project>` is even resolved, listing the full accepted vocabulary.
- `--target` given a value `<project>`'s own resolved type can't build throws naming which source types that target
  actually supports and how to recover.
- A blueprint (`tsPackage` target) with any error-level issue prints every error and exits `1` without generating
  anything.
- `--out` already existing as a *file* where a directory target expects one (or vice versa for `parWorkbook`)
  throws — pick a different `--out` or remove it first.
- `--out` already existing and having any content in it at all — even just your own unrelated `package.json`, or a
  directory a previous `pokie build` run itself produced — throws, naming the destination. See the next section.

### Conflict handling: an existing `--out` destination

`pokie build` only ever writes into a missing (or, for a directory target, empty) destination — there is no
in-place merge/rebuild, and no recognition of "this directory is safe to overwrite because a prior `pokie build`
run produced it": a built artifact carries no metadata of its own for a later build to recognize itself by (see
above). Building again — after editing the blueprint, picking up a newer `pokie` version, or republishing to the
same place a second time — means removing the destination (or its contents) first, or pointing `--out` at a
different, empty destination. Every target enforces this the same way (`ArtifactBuildConflictError`), not a
per-target-different overwrite policy.

Building the *same* blueprint with the same `pokie` version, into two different empty directories, reproduces
every generated file byte-for-byte — every `tsPackage` build is a pure function of the blueprint, never dependent
on whatever (if anything) previously occupied the destination. Want to check this without writing anything at all?
`pokie build <config.json> --target tsPackage --out <dir> --dry-run` validates and prints the same blueprint hash a
real build would produce, with no `--out` destination created or touched.

### Workflow: `build` -> `inspect` -> `validate` -> `sim` -> `report` -> `replay` -> `serve`/`dev`

The minimal loop from a blueprint to a running local server, chaining every command this file documents. Unlike
the [`init` workflow](#workflow) below, there's no `npm run build` step in the middle — `pokie build`
output is loadable immediately after `npm install`:

```
pokie build examples/blueprints/sample-slot.blueprint.json --target tsPackage --out sample-slot
cd sample-slot && npm install && cd ..

pokie inspect ./sample-slot

pokie validate ./sample-slot

pokie sim ./sample-slot --rounds 100000 --seed demo --out sim.json
pokie report sim.json

pokie replay ./sample-slot --seed demo --round 42

pokie dev ./sample-slot
```

`pokie build`'s own success output prints exactly this sequence (with real paths substituted in) as its "Next:"
lines, so you don't have to come back to this doc to remember the order.

Each step is the same command documented elsewhere in this file, with the same options/failure modes —
[`inspect`](#pokie-inspect-packageroot), [`validate`](#pokie-validate-project),
[`sim`](#pokie-sim-packageroot)/[`report`](#pokie-report-projectorsimulationreportjson),
[`replay`](#pokie-replay-packageroot), and [`serve`](#pokie-serve-packageroot)/
[`dev`](#pokie-dev-packageroot) work identically whether the package came from `pokie build` or
`pokie init` — none of them care how a package was produced, only that it satisfies the
[game package](game-packages.md) contract. `pokie sim --out` twice (before/after a tweak) also lets you
[`pokie diff`](#pokie-diff-leftprojectorreportjson-rightprojectorreportjson) the two reports, same as the [`init`
workflow](#workflow) below.

## `pokie par import <input.xlsx>` / `pokie par export <config.json>`

Builds/exports a `GameBlueprint` to, and imports one from, a "PAR sheet" — a workbook laid out the way a game
designer would author symbols/reel strips/paytable/paylines/bets in Excel, instead of hand-writing JSON. A Blueprint
can create the workbook through either `pokie par export` or `pokie build <blueprint> --target parWorkbook`.
PAR workbooks carry literal reel strips, so literal, generated (`reelStripGeneration`), weighted
(`symbolWeights`), and default reel sources become a deterministic literal workbook snapshot. The authored Blueprint
remains unchanged. If a generated reel cannot satisfy its own constraints, export returns the field-level actionable
`parsheet-reel-generation-failed` diagnostic, naming the failing `reelStripGeneration[index]` and directing you to
adjust that entry. A generated reel without its own integer `seed` is rejected before any file is written with
`parsheet-reel-generation-seed-required`, naming `reelStripGeneration[index].seed` and directing you to add the
seed; PAR snapshots never fall back to nondeterministic generation. The workbook maps manifest, reels/rows, symbols (with wilds/scatters), literal snapshot
`reelStrips`, `paytable`, `paylines`, `availableBets`, `winModel`, `mechanics.freeGames`, and `betModes`.

```
pokie par export examples/parsheets/starter.blueprint.json --out starter.par.xlsx
pokie par import starter.par.xlsx --out starter.blueprint.json
```

The target-oriented aliases use these same physical PAR paths: `pokie export <config.json>
--to workbook` exports the identical workbook, and `pokie import <input.xlsx>` imports it. The
workbook suffix is case-insensitive (`.xlsx` and `.XLSX` both select the PAR importer); the
generic import command only routes a directory to Stake Engine reconstruction when it is a
POKIE-produced export with `pokie-manifest.json`. For a compatible foreign Stake directory,
use `pokie report` or `pokie diff`, which intentionally do not require that
manifest and do not claim to reconstruct missing POKIE provenance.

See `examples/parsheets/` for a worked example (`starter.blueprint.json` and the `starter.par.xlsx` exported from
it).

### Workbook format

A `.par.xlsx` workbook has up to ten sheets:

| Sheet | Columns | Required | Maps to |
|---|---|---|---|
| `Manifest` | `Key`, `Value` (rows: `Id`, `Name`, `Version`, `Description`, `Author`, `Reels`, `Rows`) | yes | `manifest`, `reels`, `rows` |
| `Symbols` | `Symbol`, `Wild`, `Scatter` — one row per symbol, in reel order | yes | `symbols`, `wilds`, `scatters` |
| `Paytable` | `Symbol`, `Matches`, `Multiplier` — one row per payout tier | yes | `paytable` |
| `ReelStrips` | `Reel 1`..`Reel N` (exact names — see below) — one row per strip position; a shorter (ragged) reel just leaves trailing blank cells | no | `reelStrips` (literal only) |
| `Paylines` | `Line` (a 1-based label, not read back), `Reel 1`..`Reel N` (row index per reel) | no | `paylines` |
| `AvailableBets` | `Bet` — one row per value | no | `availableBets` |
| `WinModel` | `Key`, `Value` (rows: `Type` — one of `lines`/`ways`/`clusters`; `Minimum Cluster Size`, only for `clusters`) | no | `winModel` |
| `Mechanics` | `Scatter Symbol`, `Matches`, `Free Games` — one row per award tier (a single free-games award has exactly one scatter symbol, repeated on every row) | no | `mechanics.freeGames` |
| `BetModes` | `Id`, `Label`, `Cost Multiplier`, `Target RTP`, `Runtime Type`, `Is Default`, `Forced Free Games` — one row per selectable bet mode | no | `betModes` |
| `Meta` | `Key`, `Value` (rows: `Schema Version`, `Pokie Version`, `Exported At`, `Source`, `Blueprint Hash`) | no | nothing — provenance only, see below |

`ReelStrips`/`Paylines` columns must be named exactly `Reel 1`, `Reel 2`, ... `Reel N` (case-insensitive, one
physical column per reel) — a column with any other name is never treated as reel data (see Diagnostics below).

`BetModes`' `Runtime Type`/`Is Default`/`Forced Free Games` columns are an explicit, opt-in runtime-semantics
contract, separate from `Id`/`Label`/`Cost Multiplier` (which stay pure metadata unless `Runtime Type` is also
set): leave `Runtime Type` blank on every row for the old metadata-only behavior, or set it to `base`/`ante`/
`buyFeature` on *every* row to opt in — a mix of blank and set is a validation error, as is a `buyFeature` row
missing `Cost Multiplier`/`Forced Free Games`, or having anything other than exactly one `Is Default` row. Only a
blueprint whose whole `BetModes` sheet validates cleanly under this contract gets `pokie build`'s generated
session actually wired for bet-mode selection (`VideoSlotWithBetModesSession`) — see `betModes` in
[the `GameBlueprint` format](#the-gameblueprint-format) and `gamepackage/BetMode.ts`'s own doc comment for the
full contract.

`Target RTP` is independent of that opt-in — it's meaningful (and optional) on any row, with or without `Runtime
Type` set, same as `Cost Multiplier` always was. A blank cell means the mode simply doesn't declare a target; a
non-numeric cell (e.g. `"very high"`) is `parsheet-betmodes-invalid-targetrtp-cell` and drops that row, same
treatment as an invalid `Cost Multiplier`/`Forced Free Games` cell. See
[`pokie sim`'s `targetRtp`/`rtpDeviation`](#pokie-sim-packageroot) for where an imported value ends up being used.

`pokie par export <config.json> --out <file>` and `pokie build <config.json> --target parWorkbook` preflight the
entire export before writing anything: if the Blueprint fails any check, **no file is created and an existing file
at the output path is left completely untouched**. PAR workbooks carry literal reel strips, so generated,
weighted, and default-reel Blueprints are exported as a deterministic literal snapshot. The authored Blueprint is
never changed; the workbook's `Meta` sheet records its source and the snapshot hash. A generated reel that cannot
satisfy its own constraints reports `parsheet-reel-generation-failed` naming the failing
`reelStripGeneration[index]` and tells you to adjust that entry.

### `pokie par import <input.xlsx>`

Reads `<input.xlsx>`, maps every sheet above to a `GameBlueprint`, then runs the result through the same
[`GameBlueprintValidator`](#validation) `pokie build` uses — so an imported PAR sheet gets the exact same
reachability/paytable-quality/weighting checks as a hand-written blueprint. If there are no error-level issues,
writes the resulting `GameBlueprint` JSON to `--out <file>` (default: `<input>` with its extension replaced by
`.blueprint.json`).

Options:

- `--out <file>` — where to write the imported `GameBlueprint` JSON.
- `--format json` — print the full `{blueprint, provenance, issues, conversionEvidence}` importer result as JSON instead of a human-readable
  summary. `conversionEvidence` retains the original Meta cells, diagnostics and explicit import facts.
- `--dry-run` — validate and show the prepared file destination and evidence sidecar without writing either file.

Successful imports also write `<blueprint>.conversion-evidence.json`. The sidecar records the source workbook,
verbatim Meta cells, parsed provenance, diagnostics, formula/ignored/default facts, and whether the imported
Blueprint hash proves lossless eligibility. It is part of the publication: an existing sidecar is never overwritten.

Exit code is non-zero (and nothing is written) if there are any error-level diagnostics.

### `pokie par export <config.json>`

Loads `<config.json>` (a `GameBlueprint`, same as [`pokie build`](#pokie-build-project)), validates it, materializes
its canonical reel source into the workbook's literal snapshot, and writes a `.par.xlsx` workbook to `--out <file>` (default:
`<config.json>` with `.blueprint.json`/`.json` replaced by `.par.xlsx`). On any error, nothing is written — see
the atomicity guarantee above.

Options:

- `--out <file>` — where to write the exported workbook.
- `--dry-run` — validate and show the prepared file destination without writing a workbook.

### Diagnostics

Both directions report problems as `ValidationIssue`s (the same `{code, severity, message, details, suggestion}`
shape as [`pokie build`'s validation](#validation)):

- an unrecognized sheet name (`parsheet-unknown-sheet`, warning) or column (`parsheet-unknown-column`, warning) —
  a column that isn't literally `Reel <k>` in `ReelStrips`/`Paylines` is reported this way too, and its data never
  becomes part of the imported blueprint;
- a missing required sheet (`parsheet-missing-sheet`) or column (`parsheet-missing-column`);
- a `Reel <k>` column repeated more than once (`parsheet-reel-column-duplicate`, error — only the first occurrence
  is used) or missing from the `1..N` sequence (`parsheet-reel-column-missing`, error, one per missing index);
- a cell that can't be parsed as the type its column expects — e.g. a non-numeric `Multiplier`
  (`parsheet-paytable-invalid-multiplier-cell`) or an unrecognizable `Wild`/`Scatter` flag
  (`parsheet-symbol-invalid-flag`);
- a blank cell in a required column, which drops that row (`parsheet-symbol-missing-id`,
  `parsheet-paytable-missing-symbol`);
- two rows that collide once turned into a single `GameBlueprint` field, e.g. the same `(Symbol, Matches)` pair
  twice in `Paytable` (`parsheet-paytable-duplicate-entry`, warning — the last one wins) or the same key twice in
  `Manifest`/`Meta` (`parsheet-manifest-duplicate-key`, warning);
- a gap in `ReelStrips` — a blank cell followed by a non-blank one further down the same column
  (`parsheet-reelstrips-gap`) — as opposed to a shorter (ragged) reel's trailing blank cells, which are fine;
- on export, a generated reel that cannot satisfy its own constraints
  (`parsheet-reel-generation-failed`, naming `reelStripGeneration[index]`) — export aborts with nothing written;
- on import, a `WinModel` sheet with no recognizable `Type` value at all (`parsheet-winmodel-missing-type` if
  blank, `parsheet-winmodel-invalid-type` if present but not `lines`/`ways`/`clusters`) — `winModel` is dropped
  rather than silently defaulting to `lines`; a `Minimum Cluster Size` given for a non-`clusters` type is ignored
  with a warning (`parsheet-winmodel-cluster-size-ignored`); a `Minimum Cluster Size` that's present but not a
  number is reported (`parsheet-winmodel-invalid-cluster-size`, error) rather than silently dropped;
- on import, a `Mechanics` sheet whose rows disagree on which scatter symbol they're for
  (`parsheet-mechanics-multiple-scatter-symbols`) — a single free-games award has exactly one scatter symbol, so
  this can't round-trip losslessly and is reported as an error rather than silently picking one;
- on import, provenance problems — see below;
- everything `GameBlueprintValidator` itself already checks once the blueprint is assembled (unknown/duplicate
  symbols, unreachable symbols, out-of-range match counts, paytable/weighting quality warnings, ...) — these use
  the same `blueprint-*` codes documented under [Validation](#validation), not `parsheet-*`.

### Provenance (`Meta` sheet)

`pokie par export <config.json>` always writes a `Meta` sheet recording the `GameBlueprint` schema version, the `pokie` version
that exported it, an ISO 8601 export timestamp, the source blueprint's file path (when known), and a `sha256`
hash of the exported literal snapshot. `Source` identifies the authored Blueprint path, while `Blueprint Hash`
identifies the materialized data actually stored in the workbook. That hash is computed over a canonical field order
(not the source JSON's own key order — see `computeBlueprintHash`), so an untouched round trip always reproduces
the same hash regardless of how the original file's keys were ordered.

`pokie par import <input.xlsx>` returns this as structured `provenance` on the result (`ParSheetImportResult`), not just as an
issue, and verifies it against the blueprint it just assembled:

- no `Meta` sheet at all → `provenance` is `undefined`, and `parsheet-provenance-missing` (warning) — e.g. a
  hand-authored PAR sheet that was never exported by `pokie par export <config.json>` in the first place;
- `Meta` present but missing/invalid `Schema Version`/`Blueprint Hash` → `parsheet-provenance-malformed` (warning);
  no further hash/schema check is attempted;
- a well-formed but unrecognized `Schema Version` → `parsheet-provenance-schema-mismatch` (warning);
- a well-formed `Blueprint Hash` that doesn't match a fresh hash of the imported data →
  `parsheet-provenance-hash-mismatch` (warning) — the workbook was likely hand-edited (or otherwise changed) since
  `pokie par export <config.json>` produced it;
- otherwise, `parsheet-provenance-present` (info) — the recorded hash matches the imported data.

## `pokie reel generate <blueprint.json>`

Runs one or every `"generated"` entry of a Blueprint Project's [`reelStripGeneration`](#reelstripgeneration-build-time-reel-strip-generation)
through the same [`ReelStripGenerator`](reel-strip-generation.md) `pokie build` already runs silently at build time
— as its own inspectable command. No separate constraint/preset vocabulary: whatever
`counts`/`weights`/locked positions/`maximumConsecutiveOccurrences`/adjacency/sequence/circular-distance
constraints/`seed` a reel's own `reelStripGeneration[i]` entry already declares (by hand, via POKIE Studio's
Blueprint editor, or via [`pokie create --random`](#pokie-create-name---random)'s own per-reel generation) is
exactly what this command runs, previews, and — only with `--apply`/`--materialize` — pins back in.

```
pokie reel generate <blueprint.json> [--reel <index>] [--seed <integer>] [--apply | --materialize] [--out <file>] [--format json]
```

By default this is a **dry run**: it prints every targeted reel's generated strip (and, when the blueprint already
has a `reelStrips` entry at that index, how many positions differ from it) and writes nothing. Options:

- `--reel <index>` — target a single 0-based reel index instead of every `"generated"` entry. Errors if the index
  is out of range, or names a reel that's already `"literal"` (there's no generation config to run).
- `--seed <integer>` — override every targeted reel's own `seed` for this run only (useful for trying a different
  candidate without editing the file) — never written back unless combined with `--apply`.
- `--apply` — pin each successfully generated reel's resulting strip into `reelStripGeneration[i]` as
  `{type: "literal", strip}`, replacing that entry outright. Every other reel (untargeted, or already `"literal"`)
  is left completely unchanged. Nothing is written at all unless **every** targeted reel generates successfully —
  see below. `reelStripGeneration` stays present (now all-`"literal"`), so a blueprint that started this way still
  can't be read by a tool that only understands plain `reelStrips` — see `--materialize` for that. If a hand-edited
  input also has an incompatible top-level `reelStrips` field, the applied output removes that stale source so the
  saved Blueprint validates and downstream tools use the newly pinned per-reel entries.
- `--materialize` — resolve **every** `"generated"` entry (always the whole blueprint, using each reel's own
  declared `seed` — incompatible with `--reel`/`--seed`/`--apply`) and collapse the result into a plain top-level
  `reelStrips` array with `reelStripGeneration` removed entirely. This is the same materialization `pokie build`
  performs internally when compiling a runtime module, exposed here as its own persisted output — it's the
  optional way to persist the literal snapshot beside the authored Blueprint; PAR export and
  `pokie build --target parWorkbook` materialize their workbook snapshot automatically without changing the source.
- `--out <file>` — write the resulting blueprint to a different path instead of overwriting `<blueprint.json>` in
  place (only meaningful together with `--apply`/`--materialize`).
- `--format json` — print the full per-reel result (`success`, `attemptsUsed`, `diagnostics`, `strip`) as JSON
  instead of the human-readable summary.

This command only ever reads and writes the given Blueprint Project file — it never touches a built package.

**When generation fails** — a targeted reel's constraints can't be satisfied within its own `maxAttempts` — this
command reports it exactly like `pokie build` does: the failing reel's index, seed, attempt count, and the closest
attempt's constraint violations. No file is written at all in that case, even with `--apply`/`--materialize` —
every targeted reel must succeed for any of them to be written, so a broken reel never silently strands the
blueprint half-updated.

```
pokie reel generate game.blueprint.json --reel 2 --seed 4242 --apply
pokie reel generate game.blueprint.json --materialize --out game.materialized.json
```

See [`examples/blueprints/generated-reels.blueprint.json`](../examples/blueprints/generated-reels.blueprint.json)
for a `reelStripGeneration` blueprint to try this against.

## Target-oriented export aliases

`pokie export` names the artifact a project receives. Every target-oriented alias accepts the same preview flag:

```
pokie export outcomelibrary-config.json --to outcomes --out bundle --dry-run
pokie export stake-config.json --to adapter --out stakeengine --dry-run
pokie export game.blueprint.json --to workbook --out game.par.xlsx --dry-run
```

For `outcomes`, `adapter`, and `workbook`, `--dry-run` validates both the selected target's source and resolved
destination without writing anything. It fails if either is incompatible or unavailable; remove the problem or use
a different `--out` path, then run the command again without `--dry-run` to publish the artifact.

When `<source>` is a Blueprint or runnable game package, `outcomes` and `adapter` share the managed Outcome
Library lifecycle described in [`pokie build`](#pokie-build-project). Large reel-stop spaces automatically use its
deterministic bounded-coverage library, so a random Blueprint can then use either artifact conversion on the
standard Node heap; inspect `manifest.json` to see the recorded strategy and seed.

## `pokie export <config.json> --to adapter [--out <dir>] [--dry-run]`

Exports one or more canonical [`WeightedOutcomeLibrary`](weighted-outcome-library.md) JSON files (one per bet
mode) to the real [Stake Engine math-sdk static file format](https://stakeengine.github.io/math-sdk/rgs_docs/data_format/)
— see [Stake Engine Export](stake-engine-export.md) for the full output layout, validation rules, and the
`RoundArtifact` → Stake "events" mapping.

```
pokie export stake-config.json --to adapter --out stakeengine [--dry-run]
```

`<config.json>` lists one `WeightedOutcomeLibrary` JSON file per mode:

```json
{
    "modes": [
        {"modeName": "base", "cost": 1, "libraryPath": "./libraries/base.json"},
        {"modeName": "bonus", "cost": 100, "libraryPath": "./libraries/bonus.json"}
    ]
}
```

`libraryPath` entries resolve relative to `<config.json>`'s own directory.

A mode entry can load from a canonical [Outcome Library Bundle](outcome-library-bundle.md) instead — replace
`libraryPath` with `bundleDir` (and optionally `bundleModeName`, which defaults to `modeName`):

```json
{"modeName": "bonus", "cost": 100, "bundleDir": "./bundle", "bundleModeName": "bonus"}
```

Exactly one of `libraryPath`/`bundleDir` is required per mode. When **every** mode in the config uses
`bundleDir`, the export streams each mode's outcomes directly from its bundle — never materializing a
`WeightedOutcomeLibrary`, never calling `readLibrary()`. Mixing even one `libraryPath` mode into the same export
falls back to the existing (non-streaming) path; both produce byte-identical output.

Options:

- `--out <dir>` — where to write the export (default: `<config.json>`'s directory plus `/stakeengine`).
- `--dry-run` — validate the adapter source and destination without writing anything.

Preflights the entire export before writing anything — on any error-level `ValidationIssue` (see
[Stake Engine Export](stake-engine-export.md#validation)), nothing is written and the exit code is non-zero.
Every `payoutMultiplier`/amount is converted into Stake's own integer unit convention (`ratio * cost * 100`,
never rounded — see [Stake unit conversion](stake-engine-export.md#stake-unit-conversion--explicit-never-rounded))
before it's written.

The target-oriented adapter alias rejects an occupied destination, including a prior adapter export, without
touching it. Choose a different unused `--out` path (or remove the destination yourself after checking it) and
retry. A failed export never leaves a partial artifact — see [Rebuild safety](stake-engine-export.md#rebuild-safety--the-programmatic-writer-replaces-the-whole-directory-atomically)
for the writer's publish discipline.

## `pokie import <source>`

`pokie import <workbook.xlsx> --out <blueprint.json> [--format json] [--dry-run]` is the target-oriented PAR
import alias. It uses the same prepared Blueprint/evidence publication as `pokie par import`; dry-run validates
without writing. A Stake Engine export directory continues to import as an Outcome Library.

Imports a Stake Engine export directory (`index.json`, per-mode lookup CSV/books, and its own sibling
`pokie-manifest.json`) back into one `WeightedOutcomeLibrary` per mode — see
[Stake Engine Import](stake-engine-import.md) for the full lossy/lossless boundary, the events reconstruction,
and the validation-code table. Only ever round-trips a directory `pokie export <config.json> --to adapter` itself produced —
`pokie-manifest.json` is required, not optional.

```
pokie import stakeengine --out imported
```

Writes exactly the shape `pokie export <config.json> --to adapter` reads back in:

```json
{
    "modes": [
        {"modeName": "base", "cost": 1, "libraryPath": "./libraries/base.json"},
        {"modeName": "bonus", "cost": 100, "libraryPath": "./libraries/bonus.json"}
    ]
}
```

Also writes `source-provenance.json` (SHA-256 hashes of the raw `index.json`/manifest/CSV/books bytes this import
read — see [Source provenance](stake-engine-import.md#source-provenance)) whenever the import produced one.

Options:

- `--out <dir>` — where to write `config.json`/`libraries/*.json` (default: `<stakeDir>` plus `-imported`).

`--out` is published atomically as a whole directory (temp-dir-then-swap, same discipline as `export`): a write
failure never leaves partial files behind and never alters an existing `--out` in place, and a mode dropped from
the source no longer leaves a stale `libraries/<name>.json` file.

On any error-level `ValidationIssue` (see [Stake Engine Import](stake-engine-import.md#validation)), nothing is
written and the exit code is non-zero. The result's `modes` can be fed straight back into
`pokie export <outDir>/config.json --to adapter` — importing and re-exporting the same directory reproduces
byte-identical `index.json`/CSVs/books (see
[The real round-trip property](stake-engine-import.md#the-real-round-trip-property)), even though the
reconstructed `roundId`/win breakdown/`provenance.pokieVersion` don't match the original pre-export library (see
[Lossy vs. lossless](stake-engine-import.md#lossy-vs-lossless--read-this-before-anything-else)).

## `pokie report <stakeDir>`

Resolves, validates, and computes exact weighted statistics over **any** Stake Engine outcome directory
(`index.json`, per-mode lookup CSV, per-mode zstd-compressed JSONL books) through its canonical reader — no
`pokie-manifest.json` required. See [Stake Engine Standalone](stake-engine-standalone.md) for the full data
shapes, validation-code table, and pluggable event classification.

```
pokie report stakeengine
```

It prints the source kind, streaming limitation(s), structural issues when present, and otherwise an exact
per-mode summary (RTP, hit frequency, and standard deviation). `--format json` instead prints the canonical
structured outcome-source analysis (`rootPath`, `descriptor`, `issues`, and per-mode `analysis`), and `--out
<file>` writes the same payload. Without `--format json`, `--out <file>` writes the human-readable analysis.

## Diffing Stake Engine outcome directories: `pokie diff <leftPath> <rightPath>`

Reads and analyzes two Stake Engine outcome directories with the same canonical-reader pipeline `pokie report` uses,
then diffs the two resulting analyses mode-by-mode: added/removed modes, every scalar metric (`rtp`,
`hitFrequency`, `variance`, ...), event classification categories, and the payout distribution. See
[Diffing two analyses](stake-engine-standalone.md#diffing-two-analyses) for the full shape and why it never
attempts an event-level (per-outcome) diff.

```
pokie diff stakeengine-before stakeengine-after --format json
```

Options:

- `--format json` — print the machine-readable `{stakeDir: {left, right}, issues: {left, right}, diff}` shape
  instead of a text summary.
- `--out <file>` — also write that same JSON shape to a new file. It refuses an existing destination and any path
  inside either input directory; choose a new unused path before retrying.

`diff` is `undefined` whenever either side reports an error-level issue. Exit code follows the Unix `diff(1)`
convention rather than the usual plain 0/1:

| Exit code | Meaning |
| --- | --- |
| `0` | Both sides read cleanly and no material difference was found. |
| `1` | Both sides read cleanly but a material difference was found (an added/removed mode, or a per-mode metric drift past the differ's own warning threshold). |
| `2` | Either directory reported an error-level issue while reading, so no diff was computed. |

## `pokie export <config.json> --to outcomes [--out <dir>] [--dry-run]`

Builds a canonical [Outcome Library Bundle](outcome-library-bundle.md) — a directory with a small manifest, a
small per-mode index, and one streaming JSONL outcomes file per mode — streaming each mode's outcomes straight to
disk one at a time, never materializing a full `WeightedOutcomeLibrary` in memory to do it. This is the one
canonical bundle format both the pre-generated runtime and `pokie export <config.json> --to adapter` (via a mode's
`bundleDir`/`bundleModeName`) load from.

```
pokie export outcomelibrary-config.json --to outcomes --out bundle [--dry-run]
```

`<config.json>` lists one outcome source per mode, either a plain `WeightedOutcomeLibrary` JSON file (fully
loaded into memory) or a streaming JSONL file of outcomes for a mode too large to hold in memory at once:

```json
{
    "modes": [
        {"modeName": "base", "libraryPath": "./libraries/base.json"},
        {"modeName": "bonus", "outcomesPath": "./outcomes-bonus.jsonl", "libraryId": "bonus-lib"}
    ]
}
```

- `libraryPath` — a plain `WeightedOutcomeLibrary` JSON file, resolved relative to `<config.json>`.
- `outcomesPath` — a JSONL file of outcomes, one canonical `{"id", "weight", "artifact"}` record per line, **not**
  wrapped in a library object, resolved relative to `<config.json>` and streamed line by line. Requires a string
  `libraryId` alongside it (there's no wrapping library object to read one from); `schemaVersion` is optional.

Exactly one of `libraryPath`/`outcomesPath` is required per mode.

Options:

- `--out <dir>` — where to write the bundle (default: `<config.json>`'s directory plus `/outcomelibrary`).
- `--dry-run` — validate the outcome-library source and destination without writing anything.

Published atomically as a whole directory (temp-dir-then-swap, the same discipline as `pokie export <config.json> --to adapter`): a write
failure never leaves partial files behind and never alters an existing `--out` in place, and a mode dropped from
the source no longer leaves a stale `index_<name>.json`/`outcomes_<name>.jsonl` behind. On any error-level
`ValidationIssue` (an invalid outcome, a duplicate/case-colliding mode name), nothing is written and the exit
code is non-zero.

## Outcome-source project workflows

Use `pokie report <path>`, `pokie sample <path> --mode <modeName>`, or `pokie diff <leftPath> <rightPath>`.

Operates directly on a resolved outcome-source project — an Outcome Library Bundle written by `pokie export
<config.json> --to outcomes` or a Stake adapter directory written by `pokie export <config.json> --to adapter`
— through its own canonical reader/selector, never `loadPokieGame` and never a re-derived
game-model calculation.

```
pokie report bundle
pokie sample bundle --mode <modeName>
pokie sample bundle --mode <modeName> --seed demo-seed
pokie diff bundle-v1 bundle-v2
pokie diff bundle stake-export --format json --out diff.json
```

`report` prints the source's own kind/streaming/limitations plus, for a structurally valid source, an exact
per-mode analysis (every outcome's own weight, enumerated exactly — no simulation). `sample` draws exactly one
outcome from a native outcome library's own mode through the same selector/session/server path live and
pre-generated play already use (`WeightedOutcomeSelector` over the mode's own index). With `--seed <string>`, it
selects derived round 1 (`derived-round-seed-v1`) and prints the standard JSON `ReplayDescriptor`, including its
complete `outcomeSource` provenance (seed, round, mode, game/library identity and canonical result). Replay it
with `pokie replay <bundle> --seed <seed> --round 1 --mode <mode>`. Without `--seed`, `sample` uses a
cryptographically secure source and prints a human-readable selection only; it does **not** emit portable replay
provenance. A
Stake Engine export has no such draw contract, so `sample` against one reports the same missing-capability
diagnostic every other unsupported project operation does, rather than attempting to run it. `diff` compares
two resolved outcome sources' own exact analyses mode-by-mode over the core metrics both a native bundle and a
Stake Engine export already share (rtp, hit frequency, zero-win frequency, variance, standard deviation, max
win probability) — either side may be either kind, since diffing never draws/samples anything and both kinds
already expose a canonical reader's own exact analysis.

## `pokie certification build <bundleDir> <config.json>`

Builds a canonical [Certification/Evidence Bundle](certification-evidence-bundle.md) on top of an already-built
[Outcome Library Bundle](outcome-library-bundle.md) — a deterministic manifest (game/library hashes, provenance,
per-mode exact weighted metrics, the source bundle's own deep-validation diagnostics) plus one JSONL file per
mode of deterministically sampled, independently verifiable `RoundArtifact` records. Never a second calculation
path: every hash/metric is read verbatim off the source bundle's own `manifest.json`, and every sample is drawn
via the same weighted-draw algorithm the pre-generated runtime itself uses.

```
pokie certification build bundle certification-config.json --out certification
```

`<config.json>` lists one sample source per mode of `<bundleDir>`:

```json
{
    "modes": [
        {"modeName": "base", "seed": "cert-2026-07-15-base", "sampleCount": 200},
        {"modeName": "bonus", "seed": "cert-2026-07-15-bonus", "sampleCount": 50}
    ]
}
```

- `seed` — drives a `SeededWeightedOutcomeRandomSource` for this mode: the same `(bundleDir, seed, sampleCount)`
  always reproduces the exact same sequence of sampled outcomes, byte-identically.
- `sampleCount` — how many rounds to draw (with replacement) from this mode as evidence.

Options:

- `--out <dir>` — where to write the bundle (default: `<config.json>`'s directory plus `/certification`).

Refuses to write anything (the source bundle's own deep validation is run first) if the source bundle doesn't
validate cleanly, or if a requested mode isn't present in it — the same "no partial bundle" guarantee
`pokie export <config.json> --to outcomes` gives, published atomically the same way. On any error, the exit code is non-zero and
nothing is written.

## `pokie certification verify <certDir> --source <bundleDir>`

Verifies a certification/evidence bundle: first its own internal self-consistency (does every mode's samples
file still hash to what its manifest recorded, does every embedded `RoundArtifact` still hash to its own
recorded `artifactHash`), then cross-checks it against the *live* source Outcome Library Bundle it was built
from, detecting drift in four places: the evidence bundle's own manifest fields, the source bundle's own on-disk
files, its recorded metrics, and each individually sampled outcome. See
[Certification/Evidence Bundle](certification-evidence-bundle.md#verification) for the full code table.

```
pokie certification verify certification --source ../bundle
```

Options:

- `--source <bundleDir>` — **required.** Where the live source Outcome Library Bundle actually is. The
  certification bundle's own recorded `manifest.sourceBundleDir` is informational only and is never used as a
  fallback — omitting `--source` fails with a usage error, and running `verify` without it programmatically
  reports a diagnostic instead of reading anything outside `<certDir>`.

Exit code is non-zero if any issue is `error`-severity; warnings/info are printed either way.

## `pokie fairness seed-commit <serverSeed.txt> [--out <file>] [--overwrite]`

The first step of the [Provably Fair](provably-fair.md) commit-reveal flow: reads a secret `serverSeed` from a
plain text file and calls `computeFairnessServerSeedCommitment` to build the `FairnessServerSeedCommitment` that
gets published to the player immediately, before `clientSeed`/`nonce` are even solicited. The written/printed
artifact is structurally incapable of carrying the raw `serverSeed` — `FairnessServerSeedCommitment` only ever
has `serverSeedHash` — so nothing about this command's own output ever needs to be redacted.

**Seed file normalization** (shared byte-for-byte with `reveal` below, via one internal
`normalizeServerSeedFileContents` helper): at most one terminal line ending (`\n` or `\r\n` — whichever a text
editor appended when the file was saved) is stripped, and nothing else. A leading space, intentional trailing
spaces before that final line ending, or a second/earlier line ending elsewhere in the file are all preserved
exactly as typed, since any of it could be a deliberate part of the secret — this is deliberately not a plain
`.trim()`, which would silently strip all of that too. An empty result (the file held nothing but its own
trailing line ending, or was empty outright) is rejected.

```
pokie fairness seed-commit serverSeed.txt --out seed-commitment.json
```

Options:

- `--out <file>` — where to write the commitment JSON. Optional; the commitment is always printed to stdout
  either way. If `<file>` already exists, the command fails with a usage error unless `--overwrite` is also given
  (the same explicit-override convention `--overwrite` uses on `commit`/`reveal` below).
- `--overwrite` — allow `--out` to replace an existing file.

Exit code is non-zero (and nothing is written) if `serverSeed.txt` is empty/unreadable or a custom `issuedAt`
would be invalid.

## `pokie fairness commit <serverSeedCommitment.json> --client-seed <seed> --nonce <n> --source <bundleDir> --mode <modeName> [--out <file>] [--overwrite]`

The second step: once the player's `clientSeed`/`nonce` are known, builds the `FairnessCommitment` (the "round
commitment") published before the round is played. `libraryId`/`libraryHash` are never taken from a CLI flag —
they're always read straight off the live source bundle's own mode index (`OutcomeLibraryBundleReading.readModeIndex`,
the same reader `FairnessRoundProofBuilder`/`Verifier` themselves use), so a commitment can only ever pin the
`libraryId`/`libraryHash` a real bundle actually has, never one a caller merely claims.

```
pokie fairness commit seed-commitment.json --client-seed player-seed --nonce 0 --source ../bundle --mode <modeName> --out commitment.json
```

Options:

- `--client-seed <seed>` — **required.** The player-supplied client seed.
- `--nonce <n>` — **required.** A canonical non-negative decimal integer string (`"0"`, `"1"`, `"2"`, ... — the
  same `"0"|[1-9]\d*"` rule `docs/stake-engine-export.md`'s own outcome-id parsing already uses), no larger than
  `Number.MAX_SAFE_INTEGER`. Rejects a leading zero/sign, a decimal point, scientific notation (`"1e3"`), and
  hexadecimal notation (`"0x10"`) — all of which `Number(...)` alone would otherwise silently accept.
- `--source <bundleDir>` — **required.** The live Outcome Library Bundle `--mode` is read from.
- `--mode <modeName>` — **required.** Which mode's own index to pin `libraryId`/`libraryHash` from.
- `--out <file>` — where to write the commitment JSON. Optional; always printed to stdout either way. Same
  `--overwrite` convention as `seed-commit` above.
- `--overwrite` — allow `--out` to replace an existing file.

Exit code is non-zero (and nothing is written) if `<serverSeedCommitment.json>` doesn't parse or doesn't itself
validate, `--mode <modeName>` isn't present in `--source <bundleDir>`, or any of `--client-seed`/`--nonce` is
invalid.

## `pokie fairness reveal <commitment.json> --server-seed <serverSeed.txt> --source <bundleDir> [--out <file>] [--overwrite]`

The reveal step: once the round settles, reads the revealed `serverSeed` from a plain text file and calls
`FairnessRoundProofBuilder.build(commitment, serverSeed, sourceBundleDir)` to draw the one outcome this
commitment's own `clientSeed`/`nonce`/(now-revealed) `serverSeed` deterministically select, producing the
`FairnessRoundProof` published to the player after the round. Unlike the two commitments above, the proof *does*
carry the revealed `serverSeed` — that's the point of a reveal — so redacting it would defeat the command.

```
pokie fairness reveal commitment.json --server-seed serverSeed.txt --source ../bundle --out proof.json
```

Options:

- `--server-seed <file>` — **required.** Plain text file holding the revealed `serverSeed`, normalized the
  exact same way `seed-commit`'s own `<serverSeed.txt>` is (see that section's own "Seed file normalization"
  above) — the same file used for both commands round-trips correctly by construction.
- `--source <bundleDir>` — **required.** The live Outcome Library Bundle the round is drawn from.
- `--out <file>` — where to write the proof JSON. Optional; always printed to stdout either way. Same
  `--overwrite` convention as `seed-commit`/`commit` above.
- `--overwrite` — allow `--out` to replace an existing file.

Exit code is non-zero (and nothing is written) if `<commitment.json>` doesn't parse or doesn't itself validate,
the revealed `serverSeed` doesn't hash to the commitment's own `serverSeedHash`, or the live mode index no longer
matches the commitment's own pinned `libraryId`/`libraryHash` (see `FairnessRoundProofBuildError` in
[Provably Fair](provably-fair.md#building-a-proof)).

## `pokie fairness verify <proof.json> --commitment <commitment.json> --source <bundleDir>`

Verifies a [Provably Fair](provably-fair.md) round proof: first its own self-consistency (does the shape match,
is `algorithmVersion` supported, does the revealed `serverSeed` actually hash to its own recorded
`serverSeedHash`), then cross-checks it against the given `FairnessCommitment` (is this proof genuinely bound to
that exact commitment — `commitmentHash` plus an exact field-by-field match of
`algorithmVersion`/`serverSeedHash`/`clientSeed`/`nonce`/`libraryId`/`libraryHash`/`modeName` — never just a
proof's own, unverifiable copies of those fields), and finally against the *live* source Outcome Library Bundle
it claims to have been drawn from — the pinned `libraryHash`/index hash (bundle drift), the drawn outcome's own
recorded `weight`/`recordHash` (a substituted outcome), and a full reproduction of the deterministic HMAC-SHA256
draw itself, against one pinned snapshot of the live bundle (a forged proof). No game/win calculation is ever
involved. See [Provably Fair](provably-fair.md#verification) for the full code table.

```
pokie fairness verify proof.json --commitment commitment.json --source ../bundle
```

Options:

- `--commitment <commitment.json>` — **required.** The original `FairnessCommitment` this proof claims to have
  been built from. A `FairnessRoundProof` carries its own copies of the fields a commitment pins, but copies
  alone can't prove they match anything that was ever actually committed to — without `--commitment`, full
  verification is impossible and the command fails with a usage error (or, programmatically, a
  `fairness-verify-commitment-required` diagnostic without reading anything).
- `--source <bundleDir>` — **required.** Where the live source Outcome Library Bundle actually is. A
  `FairnessRoundProof` carries no bundle location of its own — omitting `--source` fails with a usage error, and
  running `verify` without it programmatically reports a diagnostic instead of reading anything.

Exit code is non-zero if any issue is `error`-severity; warnings/info are printed either way.

## `pokie init [directory]`

Turns the current or given `[directory]` into a **prepared, immediately valid** [game package](game-packages.md) —
in place, with **no game-id subdirectory** — the "programmer-first" package workflow: a real, editable
`src/index.ts` a developer owns, installed and built and verified on the spot. For an editable `GameBlueprint` JSON
file instead, see [`pokie create`](#pokie-create-name) above.

```
npm i -g pokie
mkdir sample-slot && cd sample-slot
pokie init
```

```
  created  package.json
  created  tsconfig.json
  created  README.md
  created  src/index.ts

Game package "sample-slot" (id: "sample-slot") prepared and verified in "/path/to/sample-slot".
Load it anywhere with: loadPokieGame("/path/to/sample-slot") from "pokie".

Next:
  pokie validate /path/to/sample-slot
  pokie sim /path/to/sample-slot --rounds 10000 --seed demo --out sim.json
  pokie dev /path/to/sample-slot
  npm start
```

`pokie init` never asks a single reel/paytable/mechanics question — it is entirely non-interactive, every default
coming from the target directory itself:

1. **Merge/create `package.json`** — a pre-existing `package.json` is patched in place: its own `name`, `version`,
   and any other fields are preserved, and `main`/`exports`/`pokie.entry`/`scripts.build`/the `pokie` dependency
   are filled in wherever they're missing. If one of those already has a *different* value — a real npm
   project's own build output, or a `package.json` hand-edited since a previous `pokie init` — nothing is forced
   over it: `pokie init` fails with exactly which field(s) conflict and leaves `package.json` completely
   unmodified, so re-running after resolving the conflict by hand is always safe. With no `package.json` yet, one
   is created fresh, with its `name` defaulting to the target directory's own basename (slugified into a valid
   npm package name — lowercased, spaces/invalid characters replaced — since a directory name was never chosen
   to double as one).
2. **Write `tsconfig.json`, `README.md`, `src/index.ts` wherever they're missing** — an existing one of these is
   never overwritten, only reported as `skipped`, so re-running `pokie init` in a directory you've already started
   hand-editing never clobbers your changes.
3. **Install dependencies** (`npm install`, writing `package-lock.json`) — skip with `--no-install`.
4. **Build** (`npm run build`, i.e. `tsc`, producing `dist/index.js`) and **verify** the result actually loads (the
   same check [`pokie validate`](#pokie-validate-project) runs) — skipped, along with step 3, by `--no-prepare`.
   A validation error or a failed build/load exits non-zero with the printed issues instead of silently leaving a
   broken package on disk.

`--package-name <name>` overrides `package.json`'s own `name` field directly; short of that, an existing
`package.json`'s own `name` is preserved untouched, and only with neither does the target directory's own
basename become the default. `--game-id <id>`/`--game-name <name>`/`--version <version>` override the game
manifest's `id`/`name`/`version` only — `--game-id` never seeds or otherwise changes `package.json`'s `name`,
which is controlled solely by `--package-name`/the existing name/the directory-derived default above.

**Safety guard:** a directory that already has files in it, and doesn't yet look like a package `pokie init`
itself produced or is resuming (no `package.json`, or one whose `pokie.entry` doesn't already match what a fresh
merge would write there), is left untouched unless `--yes` is given:

```
$ pokie init ./some-other-project
"/path/to/some-other-project" already has files in it and doesn't look like a POKIE package yet.
Re-run with --yes to merge POKIE's package files into it -- existing files are only ever added to, never overwritten.
$ pokie init ./some-other-project --yes
  updated  package.json
  created  tsconfig.json
  ...
```

An empty or not-yet-existing directory never needs `--yes`, and neither does re-running `pokie init` again in a
directory it already merged into (its own `package.json` already carries the `pokie.entry` field that marks it as
such) — the natural way to **retry** after a failed `npm install`/`npm run build`: fix whatever failed and re-run
the exact same `pokie init` invocation. Nothing from a prior attempt needs to be cleaned up first — every step
above is safe to repeat. Merely depending on `pokie` as a library isn't enough on its own — an existing npm project
that uses `pokie` but was never merged by this command (no matching `pokie.entry`) still needs `--yes`, the same as
any other non-empty directory.

The result is loadable like any other [game package](game-packages.md):

```ts
import {loadPokieGame} from "pokie";

const game = await loadPokieGame("/path/to/sample-slot");
game.createSession().play();
```

From here, replace the generated `src/index.ts` with your own symbols, paytable, and session wiring — see
[Getting Started](getting-started.md) and [Game Session & Configuration](game-session.md). `npm start` (from
inside the package directory) runs [`pokie dev .`](#pokie-dev-packageroot) — the fastest way to see a change.

## `pokie sim <packageRoot>`

Loads a [game package](game-packages.md) with `loadPokieGame` and runs an [aggregate simulation](simulation.md)
(`AggregateSimulationRunner`) against it, then reports RTP/hit-frequency/max-win statistics.

```
pokie sim ./sample-slot --rounds 10000 --seed demo --out report.json
pokie sim ./sample-slot --rounds 1000000 --seed demo --workers 4 --out report.json
```

Options:

- `--rounds <number>` — how many rounds to play (default `1000`, `SimulationConfig.DEFAULT_NUMBER_OF_ROUNDS`).
- `--seed <string>` — forwarded as `context.seed` to `game.createSession(context)`. **Best-effort, not guaranteed**:
  POKIE has no built-in way to seed an arbitrary loaded game — it's up to the game package's own `createSession`
  to read `context.seed` and thread it into a `SeededRandomNumberGenerator`. A game that ignores `context` will
  simply run unseeded, seed or no seed. Note also that `VideoSlotConfig`'s *default* reel-strip generator shuffles
  with an unseeded `Math.random()` at construction time, independently of any RNG passed to
  `SymbolsCombinationsGenerator` — a game package needs fixed (non-shuffled) symbol sequences, e.g. via
  `config.setSymbolsSequences(...)`, for `--seed` to make a whole run reproducible, not just individual reel stops.
- `--workers <number>` — split `--rounds` across this many worker threads (default `1`; must be an integer between
  1 and `MAX_SIMULATION_WORKERS`, currently 32). See
  [Parallel simulation](simulation.md#parallel-simulation-workers) for the full mechanism, reproducibility
  guarantees, and memory/CPU tradeoffs — the short version: `--workers 1` is the original, unchanged sequential
  path; `--workers N > 1` runs N real OS threads, each independently loading `<packageRoot>` and playing its own
  share of the rounds, merged back into one report. **`--workers > 1` requires `<packageRoot>` to be a real,
  on-disk game package** — each worker thread calls `loadPokieGame` on it independently, so this doesn't work
  against an in-memory/mocked game (not a concern for normal CLI use, only for embedding `pokie sim`'s underlying
  API in your own tooling).
- `--out <file>` — write the JSON report to `<file>`.
- `--format json` — print the JSON report to stdout instead of the default human-readable summary. Independent of
  `--out`: combine both to see the report and save it in the same run.
- `--min-rounds <number>`, `--rtp-tolerance <number>`, `--check-interval <number>`, `--stable-checks <number>` —
  opt-in adaptive early stop. See [Adaptive early stop (convergence)](#adaptive-early-stop-convergence) below.

The session's credit balance is set to `Number.MAX_SAFE_INTEGER` before the run starts — `pokie sim` measures
RTP/volatility, not risk of ruin, so `--rounds` is never cut short by the session running out of credits.

The JSON report shape:

```ts
{
    game: {id: string; name: string; version: string};
    requestedRounds: number;
    rounds: number;           // rounds actually played — can be less than requestedRounds if the game
                               // itself stops early (canPlayNextGame() returning false)
    seed: string | null;
    totalBet: number;
    totalWin: number;
    rtp: number;               // 0-1, e.g. 0.9532 for 95.32%
    hitFrequency: number;      // 0-1
    maxWin: number;
    durationMs: number;
    spinsPerSecond: number;
    workers?: number;            // how many worker threads the run was split across (1 by default)
    reproducibility?: {
        game: {id: string; name: string; version: string};
        seed: string | null;
        requestedRounds: number;
        actualRounds: number;
        command: string;         // e.g. `pokie sim <packageRoot> --rounds 10000 --seed demo`, ready to re-run
                                  // (includes `--workers N` when N > 1)
        workerSeedStrategy?: string; // human-readable description of how per-worker seeds were derived
    };
    warnings?: string[];         // e.g. no seed given, low rounds, 0 hit frequency/maxWin/totalBet, early stop
    recommendations?: string[];  // simple next-step hints, e.g. use --seed, raise --rounds, run pokie diff/--out
    breakdown?: {
        components: Record<string, {         // keyed by category, e.g. "base", "freeGames"
            rounds: number;
            totalBet: number;
            totalWin: number;
            rtp: number;           // this category's OWN payback ratio: totalWin / totalBet (within the category)
            contribution: number;  // this category's share of the report's overall rtp: totalWin / report.totalBet
            hitFrequency: number;
            maxWin: number;
        }>;
    };
    stopReason?: "maxRounds" | "sessionStopped" | "converged"; // why `rounds` stopped where it did
    convergence?: {               // present only when --min-rounds/--rtp-tolerance/--check-interval were given
        minRounds: number;
        rtpTolerance: number;
        checkIntervalRounds: number;
        stableChecks: number;
        checksPerformed: number;
        consecutiveStableChecks: number;
        achievedRtpHalfWidth: number;
    };
}
```

`reproducibility`, `warnings`, and `recommendations` were added in v1.3 as purely additive, **optional** fields —
a `sim.json` produced by an older `pokie` (or handwritten JSON without them) still validates and renders fine with
[`pokie report`](#pokie-report-simulationreportjson), it just won't have these sections. `pokie sim` itself always
populates all three on every report it produces.

`breakdown` is a later v1.3 addition, also purely additive and optional: a feature-level RTP breakdown split by
category. `components` is a plain `Record<string, ...>` — there's no fixed category list, and its key order is
stable (`"base"` first when present, then alphabetically) regardless of which round was categorized first during
simulation. Each round is categorized by a 3-step fallback chain, in this order:

1. **Explicit** — the session implements the optional `SimulationCategoryDetermining` contract
   (`getSimulationCategory(): string`) and returns a valid category (`"bonus"`, `"respins"`, `"holdAndWin"`,
   `"jackpot"`, anything — see [category name rules](simulation.md#category-name-rules-simulationcategorynamenormalizer))
   for this particular round.
2. **Stake-based** — otherwise, the session implements `StakeAmountDetermining` — the same contract
   `SpinCommandHandler` already uses server-side to tell a charged base-game round from an unfinished free-games
   round that charges nothing (see [Free Games](free-games.md) and
   [Spin orchestration & idempotency](#spin-orchestration--idempotency)). The round is `"freeGames"` when, right
   before it's played, `session.getStakeAmount() === 0`; `"base"` otherwise.
3. **No breakdown** — otherwise, the round simply isn't attributed to any category (it still plays and counts
   toward `totalBet`/`totalWin`/etc. as normal). If *every* round in the run falls through to this step, `pokie
   sim` omits `breakdown` from the report entirely — it never guesses a category from incidental data like
   balance, and it doesn't nag about the absence either: most games don't have a free-games (or other special)
   feature, and that's not a problem worth flagging on every single report forever.

See [Simulation → Feature-level breakdown](simulation.md#feature-level-breakdown-simulationroundcategorydetermining)
for the full mechanism, including how to plug in an entirely custom `SimulationRoundCategoryDetermining` as
`AggregateSimulationRunner`'s 4th constructor argument. An invalid/empty category — from either the built-in
explicit determiner or a custom one — is always safely treated as step 3 above, never used as-is; it can't crash a
run or end up as a stray key in the JSON report.

Each category's `rtp` and `contribution` answer different questions, and it's easy to misread one for the other:
`rtp` is that category's own payback ratio *in isolation* (`totalWin / totalBet` using only that category's own
rounds) — a `"freeGames"` category routinely shows `rtp > 1` (100%+) since free spins pay out but cost nothing, and
that's expected, not a bug. `contribution` is that category's *share of the report's overall RTP* (`totalWin /`
the report's overall `totalBet`) — contributions across every category always sum to exactly `report.rtp`, so it's
the number to reach for when asking "how many RTP percentage points does this feature account for?".

`pokie sim` only warns about a `breakdown` that looks off, and only when the sample size makes that a safe call —
false positives are worse than missing a real signal here:

- If no non-`"base"` category ever appeared at all, that's only flagged once `rounds >= 10000` (the same threshold
  used for the "requested rounds is low" warning) — below that, a feature simply not having triggered yet is normal
  variance, not a signal.
- If a non-`"base"` category did appear but never won, that's only flagged once it has at least
  `SimulationReportBuilder.MIN_FEATURE_ROUNDS_FOR_ZERO_WIN_WARNING` (20) rounds of its own — an all-zero streak
  shorter than that is common even for an intentional, working feature.

### New metrics on every report (v1.3): `averageBet`/`averagePayout`/`volatility`/`payoutHistogram`/`maxWinFrequency`

Also purely additive/optional, populated on every report `pokie sim` produces (not just bet-mode-locked ones) —
surfaced straight from the same `SimulationStatistics` the run already computed, never recomputed:

```ts
{
    // ...core fields above...
    averageBet?: number;         // totalBet / rounds (uses THIS report's own totalBet, already
                                  // bet-mode-adjusted when a mode is locked — see below)
    averagePayout?: number;      // totalWin / rounds, same basis
    volatility?: number;         // standard deviation of per-round payout amounts (unaffected by bet mode —
                                  // it's the payouts themselves that vary, not which stake basis prices them)
    payoutHistogram?: Record<string, number>; // round counts per fixed payout bucket ("0", "1-9", "10-99", "100+")
    maxWinFrequency?: number;    // share of rounds whose payout landed in the same bucket as maxWin
}
```

### Bet modes: `--mode <betModeId>` / `--mode all`

- `--mode <betModeId>` — locks the run to one [bet mode](game-packages.md) (e.g. `"ante"`, `"buy-bonus"`) via the
  session's optional `BetModeSelecting` contract (`setBetMode`/`getBetModeId`) — see
  [`VideoSlotWithBetModesSession`](game-packages.md). The bet mode actually drives the runtime the whole time
  (real stake multiplier, real forced-feature-entry cost), never just a label: `report.betMode` is set, and
  `report.totalBet`/`totalWin`/`rtp`/`hitFrequency`/`maxWin` reflect the mode's real cost — a persistent `"ante"`
  mode's `totalBet` is genuinely `rounds * bet * stakeMultiplier`, not the plain nominal bet. A game whose session
  doesn't support `BetModeSelecting` at all makes `--mode` (any value) **fail clearly** rather than silently
  simulating the plain base game and still labeling the report with the requested mode. An unknown mode id
  surfaces the runtime's own `UnknownBetModeError`, listing the modes that ARE configured.
- `--mode all` — runs a **full, independent `--rounds` simulation for every mode the game declares** (via
  `PokieGame.getBetModes()` — see [Game Packages](game-packages.md)), one at a time, through the exact same
  pipeline as `--mode <id>` (no math is duplicated between the two paths). Requires the game package to actually
  declare its bet modes; a game with no `getBetModes()` (or an empty array) makes `--mode all` fail clearly rather
  than running just the base game. The result is a **`SimulationReportSet`**, not a single `SimulationReport`:

  ```ts
  {
      game: {id: string; name: string; version: string};
      requestedRounds: number;
      seed: string | null;
      workers?: number;
      modes: Record<string, SimulationReport>; // one full, independent report per bet mode id
  }
  ```

  **There is deliberately no combined/blended RTP, totalBet, or any other "overall across modes" figure anywhere
  on this shape.** Without knowing real traffic/player-selection weights (what share of players actually pick each
  mode), any single blended number would be a made-up average, not a real statistic — compare modes side by side
  instead (see [`pokie report`](#pokie-report-simulationreportjson) below), or compute a real weighted figure
  yourself once you have real weights. The console summary for `--mode all` prints each mode's own summary block
  separately, headed `=== Mode: <id> ===` — never one combined block.

- `targetRtp`/`rtpDeviation` — when a locked mode's [`BetMode`](game-packages.md) declares a `targetRtp`, the
  report carries it through unchanged (`pokie sim` reads it off `getBetModes()`, never guesses or derives it) plus
  the trivial `rtpDeviation = rtp - targetRtp`. Absent for a mode that never declared a `targetRtp`, or when no
  mode was locked at all.

Failure modes:

- Missing `<packageRoot>`, an unknown option, or a non-positive `--rounds` throw a `Usage: pokie sim ...` error.
- An invalid `packageRoot` (no `package.json`, no `pokie.entry`, or an entry module that doesn't export a valid
  `PokieGame`) throws the same descriptive error `loadPokieGame` would throw directly — see
  [Game Packages](game-packages.md).
- `--mode <id>` against a session that doesn't support `BetModeSelecting` at all, or `--mode all` against a game
  that doesn't declare any bet modes, both fail with a clear, descriptive error — never a silent fallback to the
  plain base game.

### Adaptive early stop (convergence)

By default `pokie sim` plays exactly `--rounds` rounds — the pre-existing, unchanged fixed-round behavior. Passing
`--min-rounds`, `--rtp-tolerance`, and `--check-interval` **together** opts a run into stopping early once the
running RTP estimate has stabilized, instead of always playing every requested round:

```
pokie sim ./sample-slot --rounds 5000000 --seed demo \
  --min-rounds 100000 --rtp-tolerance 0.002 --check-interval 25000 --out report.json
```

- `--min-rounds <number>` — no early stop can trigger before this many rounds have been played, even if the
  estimate already looks stable by chance on a tiny sample.
- `--rtp-tolerance <number>` — the run is considered converged once the running RTP's 95% confidence interval
  half-width (the same figure already exposed as `SimulationStatistics.rtpConfidenceInterval95` — never
  recomputed for this feature) is at or under this value, in RTP units (`0.002` = the true RTP is estimated to
  within ±0.2 percentage points).
- `--check-interval <number>` — how many rounds to play between convergence checks. With convergence enabled,
  this also becomes the run's effective chunk size (any `--check-interval` you'd otherwise want as a separate
  progress granularity doesn't apply here — a check can only happen at a chunk boundary).
- `--stable-checks <number>` (optional, default `3`) — how many consecutive checks must satisfy `--rtp-tolerance`
  back to back before the run actually stops. A failing check resets the streak to zero — this is what keeps a
  single lucky/noisy interval from ending the run early.

All three of `--min-rounds`/`--rtp-tolerance`/`--check-interval` must be given together — providing only one or
two is a usage error, and `--stable-checks` on its own (without the other three) is also a usage error, so a
mistyped flag name is never silently ignored. With `--rounds` capping the maximum, the report's existing
`rounds`/`requestedRounds` fields already say everything about how many rounds were actually played vs. requested
— convergence just adds *why*:

- `stopReason` — `"maxRounds"` (every requested round was played — the only possibility without convergence
  enabled, and still possible with it enabled if the criteria are never satisfied within `--rounds`),
  `"sessionStopped"` (the pre-existing `canPlayNextGame()`/play-strategy early stop), or `"converged"` (the
  adaptive stop criteria were satisfied). `pokie sim`'s usual "actual rounds is less than requested rounds"
  warning is suppressed for a `"converged"` stop — that's the feature working as intended, not a problem.
- `convergence` — echoes the options used plus what actually happened: `checksPerformed`, `consecutiveStableChecks`
  at the point the run stopped, and `achievedRtpHalfWidth` at the last check. Absent whenever convergence wasn't
  enabled for that run, same as `betMode`/`targetRtp` being absent for a run that never locked a bet mode.

**`--workers > 1` and convergence**: each worker evaluates `--min-rounds`/`--rtp-tolerance`/`--check-interval`
independently against its own share of the rounds — there's no live coordination of a single global running RTP
across worker threads. This keeps a multi-worker converging run exactly as deterministic/reproducible as
`--workers > 1` already was (see [Reproducibility guarantees](simulation.md#reproducibility-guarantees)): each
worker's stop point depends only on its own derived seed and its own share, never on message-arrival timing
between threads, which real cross-worker coordination would make non-deterministic. The practical consequence is
that `--min-rounds`/`--check-interval` should be sized relative to each worker's share (roughly `--rounds /
--workers`), not to the total `--rounds` — a `--min-rounds` picked for the whole run will rarely be reached by any
individual worker's smaller share. The report's `stopReason` and `convergence` fields summarize across every
worker: `"sessionStopped"` always wins (a session ending early is the most notable outcome, regardless of what any
other worker did); otherwise `"converged"` requires **every** worker to have independently converged — a single
converged worker among several that instead exhausted their own share and hit `"maxRounds"` still reports the
whole run as `"maxRounds"`, not `"converged"`, since the merged report would otherwise mix a converged estimate
with a plain fixed-round one. `convergence.checksPerformed` sums, `consecutiveStableChecks` takes the minimum,
`achievedRtpHalfWidth` takes the maximum — the weakest-converged, least-precise worker, not a made-up global
statistic.

The legacy fixed-round `Simulation`/`SimulationConfig` class (see [Simulation](simulation.md)) is entirely
unaffected by this feature — it has no concept of convergence and never will; adaptive early stop only exists on
the `AggregateSimulationRunner`/`ParallelSimulationRunner`/`pokie sim` path.

## `pokie report <projectOrSimulationReportJson>`

Renders a JSON report produced by [`pokie sim --out`](#pokie-sim-packageroot) as JSON, a human-readable Markdown
document, or a complete HTML document. When the path instead resolves to an Outcome Library Bundle or Stake adapter
project, it dispatches to that project's canonical reader and renders the same three formats from that source's
exact per-mode outcome analysis.

```
pokie sim ./sample-slot --rounds 10000 --out sim.json
pokie report sim.json --format html --out report.html

pokie report outcome-library-bundle
pokie report stakeengine --format json --out stake-analysis.json
```

Options:

- `--format markdown|html|json` — output format for either supported input (default `markdown`). JSON preserves the
  complete simulation report (including every mode of an all-modes simulation report set) or canonical source-analysis
  payload; Markdown and HTML are readable documents.
- `--out <file>` — also write the complete printed artifact to `<file>`. The command writes atomically and only
  announces the destination after success; for a write error choose an existing writable directory and rerun the
  shown command.

The rendered report includes, at minimum: game id/name/version, requested rounds, actual rounds, seed, total bet,
total win, RTP, hit frequency, max win, duration, and spins per second. The HTML output is plain semantic HTML
(a heading and a table) — no charts.

When the report has a `reproducibility` block, a **Reproducibility** section follows with the game, seed,
requested/actual rounds, and a ready-to-run `pokie sim` command. When `warnings`/`recommendations` are non-empty,
matching **Warnings**/**Recommendations** sections list them. When the report has a `breakdown` block, a
**Breakdown** section lists rounds/total bet/total win/RTP/contribution/hit frequency/max win per category (e.g.
`base`, `freeGames`) as a table. All sections are omitted when the report doesn't have the corresponding field
(e.g. an older `sim.json` from before v1.3, or a game whose session doesn't support round categorization) or the
array is empty — a report can always be rendered, whether it has these fields or not.

The reusable rendering API behind the command lives in `src/reporting`:

```ts
import {HtmlSimulationReportRenderer, MarkdownSimulationReportRenderer, SimulationReportRendering} from "pokie";

const renderer: SimulationReportRendering = new MarkdownSimulationReportRenderer();
const markdown = renderer.render(report); // report: SimulationReport, e.g. from JSON.parse(fs.readFileSync(...))
```

`MarkdownSimulationReportRenderer` and `HtmlSimulationReportRenderer` both implement `SimulationReportRendering`
(`render(report: SimulationReport): string`), so a custom renderer (e.g. plain text, a different HTML layout) can
be swapped in without touching `ReportCommand`.

### Rendering a `SimulationReportSet` (all-modes simulation output)

`pokie report` auto-detects when a simulation-report path is a `SimulationReportSet` (has a `modes` map) instead of
a plain `SimulationReport`, and renders a **side-by-side comparison** instead: one column per bet mode, with rows
for RTP (observed), RTP (target/deviation, only shown when at least one mode declared a `targetRtp`), stake/average
bet, hit/feature rate, average payout, max win, volatility, and max win frequency — followed by each mode's own
full section (its complete single-report render, nested one heading level deeper so it doesn't collide with the
comparison). Exactly like `SimulationReportSet` itself, **the comparison table never has an "overall"/blended
column** — every value is per mode.

`SimulationReportRendering` gained an optional `renderSet?(reportSet: SimulationReportSet): string` method for
this — both built-in renderers implement it; a custom renderer that doesn't is still a valid, working renderer for
plain `SimulationReport`s, it just can't render report sets (`pokie report` fails clearly, naming the limitation,
rather than guessing or rendering only one mode).

Failure modes:

- Missing `<projectOrSimulationReportJson>`, an unknown option, or an invalid `--format`/`--out` value throw a
  `Usage: pokie report ...` error.
- An unrecognized `<projectOrSimulationReportJson>` that can't be read (missing file, permissions) throws
  `Could not read simulation report at "<path>": <reason>`.
- An unrecognized `<projectOrSimulationReportJson>` that isn't valid JSON throws `"<path>" is not valid JSON: <reason>`.
- Valid JSON that doesn't look like a `SimulationReport` or `SimulationReportSet` (missing `game`/`rtp`/`rounds`/...
  or `game`/`modes`/... fields) throws `"<path>" does not look like a pokie sim report ...`.
- A `SimulationReportSet` against a renderer without `renderSet()` throws
  `This renderer does not support multi-mode report sets ...`.

## `pokie diff <leftProjectOrReportJson> <rightProjectOrReportJson>`

Compares two JSON reports produced by [`pokie sim --out`](#pokie-sim-packageroot), or two resolved Outcome
Library bundles and/or Stake Engine exports. Simulation reports show sampled runtime metrics and feature/category
breakdowns; outcome sources show their canonical exact per-mode analyses. A simulation report and an outcome
source cannot be mixed because they do not share one meaningful metric contract.

```
pokie sim ./sample-slot --rounds 100000 --seed demo --out before.json
# ...change the game's config...
pokie sim ./sample-slot --rounds 100000 --seed demo --out after.json
pokie diff before.json after.json
```

Compares, at minimum: game id/name/version, requested rounds, actual rounds, seed, total bet, total win, RTP,
hit frequency, max win, duration, and spins per second. Also compares the feature-level `breakdown` (see
[`pokie sim`](#pokie-sim-packageroot)) when both reports have one.

Options:

- `--format json` — print the JSON diff to stdout instead of the default human-readable summary.
- `--out <file>` — also write the JSON diff to a new `<file>`. Independent of `--format`: the summary/JSON is always
  printed to the console; `--out` additionally saves the JSON diff to disk. It refuses an existing destination or
  either input path. When an input is an Outcome Library bundle or Stake Engine export, it also refuses destinations
  inside that source directory (including symlink aliases), so choose a new unused path (or inspect and remove an old
  diff artifact yourself) before retrying.

The human-readable summary looks like:

```
Diff: Sample Slot (id: "sample-slot")
  seed            demo -> demo2
  requested rounds 10000 -> 10000 (0, 0.00%)
  rounds          9800 -> 9850 (+50, +0.51%)
  total bet       9800.00 -> 9850.00 (+50.00, +0.51%)
  total win       9331.40 -> 9400.00 (+68.60, +0.74%)
  rtp             95.22% -> 95.43% (+0.21 pp, +0.22%)
  hit frequency   24.10% -> 24.50% (+0.40 pp, +1.66%)
  max win         120.50 -> 130.00 (+9.50, +7.88%)
  duration        1234ms -> 1300ms (+66ms, +5.35%)
  spins/s         7942 -> 7900 (-42, -0.53%)
```

A `Warnings:` section is appended whenever RTP, hit frequency, or max win moved by a noticeable amount (by
default: RTP or hit frequency by more than 1 percentage point, or max win by more than 10%) — the signal that
usually matters most after a paytable/config change.

Every machine-readable diff has a top-level `changed` boolean, so scripts can branch without re-walking every
metric. The human summary likewise prints `No changes detected.` for identical inputs.

The simulation-report JSON diff shape:

```ts
{
    changed: boolean;
    game: {left: {id, name, version}; right: {id, name, version}; changed: boolean};
    seed: {left: string | null; right: string | null; changed: boolean};
    requestedRounds: {left: number; right: number; delta: number; percentDelta: number | null};
    rounds: {left: number; right: number; delta: number; percentDelta: number | null};
    totalBet: {left: number; right: number; delta: number; percentDelta: number | null};
    totalWin: {left: number; right: number; delta: number; percentDelta: number | null};
    rtp: {left: number; right: number; delta: number; percentDelta: number | null};
    hitFrequency: {left: number; right: number; delta: number; percentDelta: number | null};
    maxWin: {left: number; right: number; delta: number; percentDelta: number | null};
    durationMs: {left: number; right: number; delta: number; percentDelta: number | null};
    spinsPerSecond: {left: number; right: number; delta: number; percentDelta: number | null};
    warnings: string[];
    breakdown?: {
        components: Record<string, {   // keyed by category, e.g. "base", "freeGames"
            left: {rounds, totalBet, totalWin, rtp, contribution, hitFrequency, maxWin} | null;
            right: {rounds, totalBet, totalWin, rtp, contribution, hitFrequency, maxWin} | null;
            rounds: {left: number; right: number; delta: number; percentDelta: number | null};
            totalBet: {left: number; right: number; delta: number; percentDelta: number | null};
            totalWin: {left: number; right: number; delta: number; percentDelta: number | null};
            rtp: {left: number; right: number; delta: number; percentDelta: number | null};
            contribution: {left: number; right: number; delta: number; percentDelta: number | null};
            hitFrequency: {left: number; right: number; delta: number; percentDelta: number | null};
            maxWin: {left: number; right: number; delta: number; percentDelta: number | null};
        }>;
    };
}
```

Every numeric field is a `{left, right, delta, percentDelta}` tuple — `percentDelta` is `null` when `left` is
`0` (a relative percent change is undefined there), not `Infinity`/`NaN`.

`breakdown` is only populated when **both** reports have one — an older report (or one from a game whose session
doesn't support round categorization) is never diffed against a newer one's breakdown, it's simply left out, same
as [`pokie report`](#pokie-report-simulationreportjson) simply omits the **Breakdown** section for such a report.
Categories are the union of both sides' `components` keys, in the same stable order `pokie sim`/`report` use
(`"base"` first, then alphabetically) — so an added or removed category slots into the same position it would if
it had always been there, rather than showing up at the end.

A category present on only one side is compared against zero for the missing side (`left`/`right` is `null`,
numeric fields read as `0`), and `Warnings:`/`warnings` labels it explicitly instead of reporting a generic RTP
change:

- **Added** (only on the right): `"<category>" is a new category in the right report (rtp X%, contributing Y pp)`.
- **Removed** (only on the left): `"<category>" is no longer present in the right report (was rtp X%, contributing Y pp)`.
- **Present on both sides**: the existing `"<category>" RTP changed by ...` message, still gated by the RTP delta
  threshold like the top-level `RTP changed by ...` warning.

The added/removed messages always fire (a category structurally appearing or disappearing is worth knowing about
regardless of magnitude) — unlike the "RTP changed" message, which only fires past the threshold. A `"freeGames"`
category dropping from 200 rounds to 0 reads as `"freeGames" is no longer present in the right report (...)`, not
as a misleading `"freeGames" RTP changed by -100 percentage points`.

**Both reports missing a breakdown is silent** — that's the common case (two old reports, or two reports from a
game with no free-games feature) and isn't worth a note every time. **Exactly one side having a breakdown** is
different: `breakdown` still comes out `undefined` (there's nothing to diff against), but `warnings` gets an
explicit entry — `Feature-level breakdown comparison skipped — the left/right report has no breakdown data.` — so
it's clear the comparison was skipped for a reason, not silently dropped, typically because one report predates the
game adding a free-games feature (or the session categorization contract) and the other postdates it.

The reusable diffing API behind the command lives in `src/diff`:

```ts
import {SimulationReportDiffer, SimulationReportDiffing} from "pokie";

const differ: SimulationReportDiffing = new SimulationReportDiffer();
const diff = differ.diff(leftReport, rightReport); // leftReport/rightReport: SimulationReport
```

`SimulationReportDiffer`'s constructor optionally takes the three warning thresholds (RTP delta, hit frequency
delta, max win percent delta), in that order, if the defaults don't fit a particular game.

### Diffing bet modes

When either report was locked to a bet mode (see `--mode`/`--mode all` under [`pokie sim`](#pokie-sim-packageroot) above; `report.betMode` set), the
diff carries a `betMode: {left, right, changed}` block. **Comparing two DIFFERENT bet modes is fully supported and
intentional** — `pokie diff` never refuses or blocks it — but every other metric in the diff is meaningless without
knowing the two sides aren't measuring the same thing, so a `Comparing different bet modes: "<left>" -> "<right>"`
warning always fires first when `betMode.changed` is true. Diffing the SAME mode across two versions (the normal
"did my math change" use case) carries no such warning. This is exactly the two things per-bet-mode diffing needs
to support: comparing the same mode across versions, and comparing different modes against each other.

### Diffing a `SimulationReportSet` (`pokie sim --mode all` output)

`pokie diff` auto-detects when both project-or-report inputs are `SimulationReportSet`s (see
`pokie sim --mode all` under [`pokie sim`](#pokie-sim-packageroot) above) instead of plain `SimulationReport`s, and diffs
them mode by mode instead — one `SimulationReportDiff` (see above) per bet mode id present on **both** sides,
computed by the exact same `SimulationReportDiffing` (no diff math is duplicated for this):

```ts
{
    changed: boolean;
    game: {left: {...}; right: {...}; changed: boolean};
    perMode: Record<string, SimulationReportDiff>; // only modes present on BOTH sides
    onlyInLeft: string[];   // mode ids only the left set declared
    onlyInRight: string[];  // mode ids only the right set declared
}
```

A mode id present on only one side is never silently dropped — it's listed under `onlyInLeft`/`onlyInRight` instead
of being diffed against nothing. **Deliberately no combined/blended diff across modes** — same reasoning as
`SimulationReportSet` itself. The console summary prints each common mode's diff separately (`=== Mode: <id> ===`),
followed by the added/removed mode lists when non-empty. Diffing a plain `SimulationReport` against a
`SimulationReportSet` (mismatched shapes) fails clearly rather than guessing which side to treat as which.

The reusable API:

```ts
import {SimulationReportSetDiffer} from "pokie";

const setDiffer = new SimulationReportSetDiffer(); // wraps a SimulationReportDiffer by default
const setDiff = setDiffer.diff(leftSet, rightSet); // leftSet/rightSet: SimulationReportSet
```

### Diffing Outcome Library bundles and Stake Engine exports

When both paths resolve to an Outcome Library bundle or Stake Engine export, `pokie diff` uses each artifact's
canonical reader and exact per-mode analysis. Native bundles, Stake exports, and a native/Stake pair are all
supported. Its JSON is intentionally composable with the report form: `changed`, `perMode`, and
`onlyInLeft`/`onlyInRight` make changed metrics and added/removed modes explicit.

```ts
{
    changed: boolean;
    left: {rootPath: string; kind: "native" | "stakeEngine"; issues: ValidationIssue[]};
    right: {rootPath: string; kind: "native" | "stakeEngine"; issues: ValidationIssue[]};
    perMode: Record<string, {
        modeName: string;
        rtp: {left, right, delta, percentDelta};
        hitFrequency: {left, right, delta, percentDelta};
        zeroWinFrequency: {left, right, delta, percentDelta};
        variance: {left, right, delta, percentDelta};
        standardDeviation: {left, right, delta, percentDelta};
        maxWinProbability: {left, right, delta, percentDelta};
    }>;
    onlyInLeft: string[];
    onlyInRight: string[];
}
```

The default summary names the artifact kinds, each common mode's shared exact metrics, and added/removed modes.
`--format json` prints this exact structure and `--out <file>` writes the same valid JSON without changing the
selected console format.

Failure modes:

- Missing `<leftProjectOrReportJson>`/`<rightProjectOrReportJson>`, an unknown option, or an invalid `--format`/`--out` value throw
  a `Usage: pokie diff ...` error.
- Each report path is read/parsed/validated the same way as [`pokie report`](#pokie-report-simulationreportjson) —
  the same "could not read"/"not valid JSON"/"does not look like a pokie sim report" errors apply to either side.
- Diffing a `SimulationReport` against a `SimulationReportSet` (one single-mode, one multi-mode) throws
  `Cannot diff a single-mode pokie sim report against a multi-mode report set ...`.
- Diffing a simulation report and an Outcome Library bundle or Stake Engine export explains that the command needs
  two simulation reports or two outcome sources; it never exposes resolver implementation terms.

## `pokie replay <packageRoot>`

Best-effort replay of a single round, identified by `--seed`/`--round`, from a [game package](game-packages.md).
This is the first foundation for POKIE replay — it does not (yet) reconstruct full session/RNG/audit state; see
[Limitations](#limitations) below.

```
pokie replay ./sample-slot --seed demo --round 42 --out replay.json
```

Options:

- `--round <number>` — **required**. A positive integer: the 1-indexed round to replay.
- `--seed <string>` — forwarded as `context.seed` to `game.createSession(context)`, same best-effort caveat as
  [`pokie sim --seed`](#pokie-sim-packageroot).
- `--out <file>` — write the JSON replay descriptor to `<file>`.
- `--format json` — accepted for symmetry with `pokie sim`/`pokie validate`; JSON is currently the only supported
  format, and is always printed to stdout regardless of this flag.

When `<packageRoot>` is a native Outcome Library bundle, replay is an exact reconstruction against the currently
opened library rather than best-effort package replay and requires `seed`, one-based `round`, and `mode`:

```sh
pokie replay ./outcome-library --seed recorded-seed --round 7 --mode base --out replay.json
```

The returned descriptor includes `outcomeSource` with the game, library id/hash, mode, selection algorithm,
outcome id, canonical artifact, screen, stake and payout. Do not substitute a default mode: a missing seed or mode
is rejected. The CLI reconstructs from the current bundle; for an exact comparison with a saved recorded round,
the exported `replayOutcomeSourceProject(..., recordedDescriptor)` API requires the complete canonical provenance
and fails closed for omissions or mismatches, telling the caller to restore the original artifact/bundle. Package
replay remains best-effort; it may inspect a round with unavailable state, but must not claim an exact comparison.

Seeded `pokie sample` prints a standard `ReplayDescriptor` whose `outcomeSource` is the portable
provenance. Seeded Studio Outcome Library Play spins retain that provenance in Recent Rounds, and a seeded `pokie
sim <bundle> --mode <mode> --seed <seed>` report exposes its last sampled round as `lastReplay`. These all use
`derived-round-seed-v1`: use the recorded `seed`, `round`, and `modeName` verbatim; a default mode or a raw
seeded-stream sample is not interchangeable provenance.

The session's credit balance is set to `Number.MAX_SAFE_INTEGER` before replaying, so reaching `--round` is never
cut short by the session running out of credits.

The JSON replay descriptor shape (`ReplayDescriptor`):

```ts
{
    game: {id: string; name: string; version: string};
    seed: string | null;
    round: number;
    totalBet: number;          // sum of getBet() across every round played to reach `round`
    totalWin: number;          // sum of getWinAmount() across every round played to reach `round`
    screen: unknown[][] | null; // getSymbolsCombination().toMatrix() when the session exposes it, else null
    timestamp: number;          // Date.now() when the replay started
    durationMs: number;         // wall-clock time spent replaying
}
```

### Limitations

`pokie replay` has no seek-to-round primitive to draw on — `GameSessionHandling` only exposes `play()`, so
replaying round N means creating a fresh session and calling `play()` N times in a row. That makes reproducibility
entirely dependent on the game package:

- The game package's `createSession(context)` must actually read `context.seed` and thread it into a deterministic
  RNG/setup — a game that ignores `context` will not replay identically across runs, seed or no seed.
- Anything else non-deterministic in the game package's session construction (e.g. `VideoSlotConfig`'s default
  reel-strip shuffling, which uses unseeded `Math.random()` — see the [`pokie sim`](#pokie-sim-packageroot) seed
  caveat) will also break reproducibility.
- `screen` is only populated when the session exposes `getSymbolsCombination()` (as `VideoSlotSessionHandling`
  does) — the base `GameSessionHandling` contract has no screen/result accessor, so a plain `GameSession` replays
  with `screen: null`.
- This does **not** replay full session/RNG/audit state — no win breakdown, no free-games state, no RNG call log.
  It is a foundation to build on, not a complete audit trail.

The reusable recording API behind the command lives in `src/replay`:

```ts
import {ReplayRecorder, ReplayRecording} from "pokie";

const recorder: ReplayRecording = new ReplayRecorder();
const descriptor = recorder.record({game, seed: "demo", round: 42}); // game: PokieGame, e.g. from loadPokieGame
```

`ReplayRecorder` implements `ReplayRecording` (`record(options: ReplayRecordingOptions): ReplayDescriptor`), so a
custom recorder can be swapped in without touching `ReplayCommand`.

Failure modes:

- Missing `<packageRoot>`, a missing/non-positive `--round`, a missing `--seed` value, or an unknown option throw a
  `Usage: pokie replay ...` error.
- An invalid `packageRoot` throws the same descriptive error `loadPokieGame` would throw directly — see
  [Game Packages](game-packages.md).

## `pokie validate <project>`

Checks one supported POKIE project without running a game. `<project>` may be:

- a [game package](game-packages.md) directory, checked through `package.json#pokie.entry` and its game
  metadata (`id`, `name`, and `version`);
- a Blueprint JSON file, checked for structural errors and math warnings; or
- an [Outcome Library Bundle](outcome-library-bundle.md) directory, checked through its `manifest.json` and
  per-mode indexes.

An existing directory without `package.json` is treated as an outcome-library candidate. This means an incomplete
bundle gets the actionable `manifest.json` diagnostic instead of a package-loading error.

```
pokie validate ./sample-slot
pokie validate ./game.blueprint.json
pokie validate ./outcomes --deep
```

```
Validating "Sample Slot" (id: "sample-slot", v0.1.0) at "./sample-slot"
  valid           yes

No issues found.
```

Options:

- `--deep` — for outcome-library inputs, additionally streams every outcome and rebuilds each mode's library to
  catch corruption that a structural check cannot (for example, a tampered record or mismatched hash). It is off
  by default so normal bundle validation reads only `manifest.json` and the small per-mode indexes. It does not
  add checks to package or Blueprint inputs.
- `--format json` — print the JSON report to stdout instead of the default human-readable summary.
- `--out <file>` — write the JSON report to `<file>`. Independent of `--format json`: combine both to see the
  report and save it in the same run.

The default summary names the project, says whether it is valid, then lists every error or warning as
`[location] code: explanation` followed by a `Next:` remediation. It never relies on a stack trace or parser
message for normal validation failures.

`--format json` and `--out` use this schemaVersion 1 report shape:

```ts
{
    schemaVersion: 1;
    project: {
        path: string;
        kind: "package" | "blueprint" | "outcome-library" | "unknown";
    };
    deep: boolean;
    valid: boolean;
    errors: ValidateDiagnostic[];
    warnings: ValidateDiagnostic[];
    suggestions: string[];  // deduplicated next actions from the diagnostics
    packageRoot?: string;   // package inputs only
    game?: {id: string; name: string; version: string} | null;
    issues?: ValidateDiagnostic[];  // outcome-library inputs: errors and warnings together
}

type ValidateDiagnostic = {
    code: string;
    severity: "error" | "warning" | "info";
    message: string;
    path: string;
    suggestion: string;
    details?: unknown;
};
```

For a package, `game` is populated whenever its game metadata could be read, even if an individual metadata
field is invalid. For outcome-library inputs, `issues` is the combined diagnostic list; `errors` and `warnings`
remain available for CI to make its decision without filtering by severity itself.

Exit code is `0` when `valid` is `true` and `1` when it's `false` — no thrown/printed error on top of the report,
so scripting against `pokie validate` doesn't have to parse stderr. Only usage mistakes (missing `<project>`,
an unknown option, `--out`/`--format` without a value) throw the usual `Usage: pokie validate ...` error.

## `pokie inspect <packageRoot>`

Prints a package's `package.json` identity — name, version, description — without loading or running the game at
all. Where `pokie validate` answers "does this package satisfy the `PokieGame` contract", `pokie inspect` answers
"what package is this":

```
pokie inspect ./sample-slot
```

```
Inspecting package at "./sample-slot"

  package.json     name: "sample-slot", version: "0.1.0"
```

`pokie inspect` never writes or modifies anything. Exit code is `0` for a valid, readable package and `1` when
`<packageRoot>` itself doesn't exist/isn't a directory, or its `package.json` is missing or fails to parse; the
error is printed to stderr in that case. Only usage mistakes (missing `<packageRoot>`, an unexpected extra
argument) throw the usual `Usage: pokie inspect ...` error.

## `pokie serve <packageRoot>`

Starts a local HTTP server over a single loaded [game package](game-packages.md), so you can
create sessions and spin them over plain JSON HTTP while developing a game. This is a **local/dev reference
server, not a casino backend or RGS** — no real-money wallet, no authentication, and no operator/integration
logic of any kind. Game state (bet/win/screen) goes through a replaceable `SessionRepository`, and credits go
through a separate `WalletPort` — see [Session storage & wallet](#session-storage--wallet) below. The CLI itself
always runs with the defaults (`InMemorySessionRepository`, `InMemoryWallet`), so a `pokie serve` restart still
loses every session; embed `PokieDevServer` directly (see below) to plug in a `FileSessionRepository` or your own
`WalletPort`.

Every response — success and error alike — carries permissive CORS headers (`Access-Control-Allow-Origin: *`,
`Access-Control-Allow-Methods: GET, POST, OPTIONS`, `Access-Control-Allow-Headers: Content-Type`), and `OPTIONS`
requests get a bare `204`. This is what lets [`pokie client`](#pokie-client-packageroot) (a
different origin/port by design) talk to this server's API at all.

```
pokie serve ./sample-slot --port 4000 --host 127.0.0.1
```

```
POKIE dev server listening on http://127.0.0.1:4000
This is a local/dev reference server for a single game package — not a casino backend or RGS.
```

Options:

- `--port <number>` — port to listen on (default `3000`). Pass `0` to let the OS assign a free port.
- `--host <string>` — host/interface to bind (default `127.0.0.1`).

The command loads `<packageRoot>` with `loadPokieGame` and starts listening; it does not return until the process
is killed (e.g. `Ctrl+C`) — that's expected for a server.

### `GET /health`

`200 {"status": "ok"}` — always, once the server is up.

### `GET /game`

`200 <PokieGameManifest>` — the loaded game's `getManifest()` output as-is (`id`, `name`, `version`, and
`description`/`author` if the game provides them).

### `POST /sessions`

Creates a new in-memory session via `game.createSession(context)` and returns its initial state. The exact shape
depends on whether the loaded game implements the optional `PokieGame.getSessionSerializer()` (see
[Game Packages](game-packages.md#the-contract) and [Network Serialization](serialization.md)):

- **No `getSessionSerializer()`** (the original, unchanged behavior for any existing game package):
  ```ts
  {
      sessionId: string;
      game: {id: string; name: string; version: string};
      bet: number;
      credits: number;
      screen?: unknown[][]; // getSymbolsCombination().toMatrix() when the session exposes it, else omitted
  }
  ```
- **`getSessionSerializer()` implemented**: `{sessionId, game, credits, ...serializer.getInitialData(session)}` —
  `credits` is always the authoritative wallet balance, overriding whatever the serializer itself computed. For a
  game returning `new VideoSlotSessionSerializer()` (what `pokie build`/`pokie init` scaffold by default), that
  means `bet`, `availableBets`, `reelsSymbols`, `availableSymbols`, `paytable`, `linesDefinitions`, and more — see
  [Network Serialization](serialization.md) for the full shape, including the `MultiStageRoundSessionSerializer`/
  `CascadeSessionSerializer` payload for multi-stage/cascade mechanics. This is `getInitialData()`'s output only —
  any field a serializer produces *exclusively* from `getRoundData()` (see below) is absent here, since no round
  has been played yet.

An optional JSON body `{"seed": string | number}` is forwarded as `context.seed` — same best-effort caveat as
[`pokie sim --seed`](#pokie-sim-packageroot): only game packages that actually thread `context.seed` into their own
RNG setup honor it.

### `POST /sessions/:sessionId/spin`

Delegates to `SpinCommandHandler` (see [Spin orchestration & idempotency](#spin-orchestration--idempotency)
below), which applies the session's current wallet balance, checks `session.canPlayNextGame()`, and only then
calls `session.play()` on the (possibly just-reconstructed, see
[Session storage & wallet](#session-storage--wallet)) session, returning its new state:

- **No `getSessionSerializer()`**:
  ```ts
  {
      sessionId: string;
      game: {id: string; name: string; version: string};
      bet: number;
      win: number;
      credits: number;
      screen?: unknown[][]; // getSymbolsCombination().toMatrix() when the session exposes it, else omitted
  }
  ```
- **`getSessionSerializer()` implemented**: `{sessionId, game, credits, ...serializer.getRoundData(session)}` —
  the serializer's *round* output for the spin that just happened, not `getInitialData()`. Any field only present
  in `getInitialData()`'s output (e.g. `availableSymbols`, `paytable` — descriptive data that doesn't change
  between rounds) is **not** repeated here; a client that needs both keeps what `POST /sessions` gave it and
  merges in each spin's response, or re-fetches everything at once via `GET /sessions/:sessionId` below.

An optional JSON body `{"requestId"?: string, "expectedSessionVersion"?: number}`:

- `requestId` makes the call idempotent: a repeated request with the same `sessionId`/`requestId` pair returns
  the exact same response instead of spinning (and charging the wallet) again — see
  [Spin orchestration & idempotency](#spin-orchestration--idempotency). Omit it (or send no body) to always spin
  for real, the original behavior.
- `expectedSessionVersion`, when the configured `SessionRepository` supports
  [optimistic locking](#optimistic-locking-session-versioning), lets a caller declare "I expect the session to
  still be at version N" — a mismatch is rejected as a `409` immediately, before `canPlayNextGame()`/`play()`/any
  wallet transaction, so there's nothing to compensate. This is a caller-declared precondition, distinct from (and
  checked before) the repository's own storage-level conflict detection described below; omit it to skip this
  check entirely. Ignored (never causes a conflict) when the configured repository isn't versioned.

`404 {"error": "..."}` for an unknown `sessionId`. `400 {"error": "..."}` if `canPlayNextGame()` returns `false`
(e.g. insufficient credits for the current bet) — `play()` is never called in that case, and the session's
game state, `SessionRepository` entry, and `WalletPort` balance are all left exactly as they were. A game whose
`canPlayNextGame()` ignores balance while an in-progress feature (e.g. a free-games round) is active still spins
normally even at a 0 balance — the gate only ever reflects what `canPlayNextGame()` itself returns. `400
{"error": "..."}` too if a `requestId` is sent but isn't a string, or if `expectedSessionVersion` is sent but
isn't a positive integer. `409 {"error": "..."}` if `expectedSessionVersion` was given and no longer matches (see
above), or if the configured `SessionRepository` supports
[optimistic locking](#optimistic-locking-session-versioning) and this session's version moved between load and
save — the wallet is left exactly as it was before this attempt (every transaction it applied is reversed), same
as the `canPlayNextGame()` case above.

### `GET /sessions/:sessionId`

Returns the current state of an in-memory session without playing a round — for a game with no
`getSessionSerializer()`, the same `PokieDevSessionResponse` shape as `POST /sessions` and
`POST /sessions/:sessionId/spin`, always including `win` (like the spin response, since the session already
tracks it via `getWinAmount()`):

```ts
{
    sessionId: string;
    game: {id: string; name: string; version: string};
    bet: number;
    win: number;      // session.getWinAmount() as it currently stands — 0 before the first spin
    credits: number;
    screen?: unknown[][]; // getSymbolsCombination().toMatrix() when the session exposes it, else omitted
}
```

`404 {"error": "..."}` for an unknown `sessionId`.

This is a **restore/reload** endpoint, not a new capability — it reads the persisted `SessionRepository` state
`POST /sessions`/`POST .../spin` already write, it doesn't play a round or change any state. With the default
`InMemorySessionRepository` (what the CLI always uses), that state doesn't survive a restart, so every stored
`sessionId` 404s after one. With a `FileSessionRepository` (see below), it does.

For a game implementing `getSessionSerializer()`, this returns `{sessionId, game, credits, ...initialPayload,
...roundPayload}` — the session's `getInitialData()` output from creation (see `POST /sessions` above) **merged
with** its `getRoundData()` output from the last spin (see `POST /sessions/:sessionId/spin` above), round data
winning on any overlapping key. This is the one endpoint that returns everything a client needs to fully rebuild
its UI in a single call — neither `POST /sessions` nor `POST .../spin` alone does, by design (see
[Session storage & wallet](#session-storage--wallet) below). Before any spin has happened, `roundPayload` isn't
set yet, so the response is just `{sessionId, game, credits, ...initialPayload}`.

This reads back exactly what was captured at session creation and after the last spin — **not** a freshly
re-serialized session. A freshly reconstructed session only restores a game's own bespoke `featureState` (e.g.
free-games counters via `ConvertableToSessionState`/`BuildableFromSessionState`), never round-outcome data like
the last screen/win/cascade result, so re-running the serializer on a reconstructed session would silently
produce a wrong payload; reading back what was actually captured avoids that entirely.

#### Client reload flow

A frontend that wants to survive a page reload without losing its session can use `GET /sessions/:sessionId` as a
lightweight restore step:

1. On first load, `POST /sessions` and keep the returned `sessionId` (e.g. in `localStorage`).
2. On every reload, call `GET /sessions/:sessionId` with the stored id.
3. If it responds `200`, use the returned state (bet/credits/screen/win) to resume where the client left off.
4. If it responds `404` — the session's state is gone (process restarted with the in-memory default, or the
   sessionId was never valid) — discard the stored id and fall back to step 1 (`POST /sessions` again).

### Public vs. internal/debug responses

**POKIE is not an RGS.** There is no compliance-grade audit trail, no operator/regulator reporting, and no wallet
custody guarantee anywhere in this framework — see the top of this section. What `pokie serve` *does* provide,
starting in v1.3, is an explicit split between what a response sends by default (public, client-safe data) and what
it can optionally include for local development/debugging (internal data — never sent unless a request asks for
it).

Every `GET`/`POST` response above (`POST /sessions`, `POST /sessions/:sessionId/spin`, `GET /sessions/:sessionId`) is
public-only by default — exactly the shapes documented above, unchanged. Adding `?debug=1` (or `?debug=true`) to any
of the three adds one extra field, `internal`, never present otherwise. The match is exact and strict: `?debug=0`,
`?debug=false`, `?debug=` (empty), any other value, an unrelated query parameter (e.g. `?seed=demo`), or no query
string at all all leave the response public-only — there is no fuzzy/truthy parsing, only the two literal strings
`"1"`/`"true"` turn it on, and all three endpoints check it the exact same way.

```ts
{
    // ...the same public response documented above...
    internal?: {
        stateAfter: PokieSessionState;    // the session's raw, persisted state (see below)
        stateBefore?: PokieSessionState;  // only present on a spin response — the state right before it
        debugData?: Record<string, unknown>; // see below — only present if the serializer provides it
        requestId?: string;               // only present on a spin response made with a requestId
        sessionVersion?: number;          // see "Optimistic locking" below — only present when the
                                           // configured SessionRepository supports it
    };
}
```

`stateAfter`/`stateBefore` are the actual `PokieSessionState` objects `SessionRepository` persists (see
[Session storage & wallet](#session-storage--wallet) below) — `context`, `bet`, `win`, `screen`, `featureState`,
`initialPayload`/`roundPayload`, unfiltered. This is meaningfully more than the public response ever exposes: e.g.
`context` (the seed a session was created with) is never part of a public response at all.

`debugData` is populated only when the loaded game's serializer (`PokieGame.getSessionSerializer()`) implements the
optional debug hooks on `GameSessionSerializing`:

```ts
export interface GameSessionSerializing {
    getInitialData(session): GameInitialNetworkData;
    getRoundData(session): GameRoundNetworkData;
    // Optional — implement to expose internal/debug-only data (RNG info, reel stops, evaluator
    // traces, anything else worth inspecting locally) without ever putting it in the public response.
    getInitialDebugData?(session): Record<string, unknown>;
    getRoundDebugData?(session): Record<string, unknown>;
}
```

A serializer that implements neither hook (every built-in serializer — `GameSessionSerializer`,
`VideoSlotSessionSerializer`, `VideoSlotWithFreeGamesSessionSerializer`, `CascadeSessionSerializer` — is unchanged
by this feature and implements neither) simply has no `debugData` — `internal.stateAfter`/`stateBefore` are still
present under `?debug=1`, but there's nothing else to add. A game package with no serializer at all (the legacy
fallback) behaves the same way. Implementing the hooks is entirely additive and optional, same pattern as
`ConvertableToSessionState`/`BuildableFromSessionState`/`StakeAmountDetermining` elsewhere in this server — see
[Network Serialization](serialization.md#internaldebug-data-getinitialdebugdatagetrounddebugdata) for the full
contract and an example.

`GET /sessions/:sessionId` merges `initialDebugPayload`/`roundDebugPayload` the same way it merges the public
`initialPayload`/`roundPayload` — round data wins on any overlapping key.

No option exists to make `internal` the *default* — every endpoint is public-only unless a specific request opts
in. `pokie client`/`pokie dev` never pass `?debug=1` themselves (see `cli/client/apiClient.ts` — every request URL
it builds is a plain `/sessions`/`/sessions/:id`/`/sessions/:id/spin`, no query string), so the browser UI
always talks to the public API exactly as before this feature existed; passing `?debug=1` by hand (e.g. via `curl`
or a browser devtools request) is how a game author inspects the internal data while developing.

This also applies to an idempotent replay (see [Idempotency and concurrency](#idempotency-and-concurrency) below):
`internal` is decided fresh, per request, from that request's own `?debug=` value — not from whatever the original
spin that produced the cached result was called with. Replaying the same `sessionId`/`requestId` with `?debug=1`
returns the same already-committed outcome (state, win, credits — nothing spins again) *plus* `internal` describing
that original spin; replaying it without `?debug=1` returns the exact same public body whether or not the original
call happened to include `?debug=1`.

### Session storage & wallet

`PokieDevServer` never keeps game state only in a live session object — every `POST /sessions` and
`POST .../spin` writes a serializable `PokieSessionState` (`{context?, bet, win, screen?, featureState?,
initialPayload?, roundPayload?}`, no credits) through a `SessionRepository`:

```ts
export interface SessionRepository {
    save(sessionId: string, state: PokieSessionState): Promise<void>;
    load(sessionId: string): Promise<PokieSessionState | undefined>;
}
```

- `InMemorySessionRepository` — the default, a `Map` for the lifetime of the process (same behavior as before
  storage became replaceable).
- `FileSessionRepository` — one JSON file per session under a directory you choose, so state survives a
  `pokie serve` restart. A missing or corrupted file is treated as an unknown session (`404`), not a crash. Session
  ids are hashed into filenames, so an untrusted `sessionId` can't be used for path traversal.

Both also implement an additive optimistic-locking API, `VersionedSessionRepository` — see
[Optimistic locking (session versioning)](#optimistic-locking-session-versioning) below.

`featureState` is where a game's own internal state beyond bet/win/screen lives — e.g. an in-progress free-games
round. It's populated through an optional, feature-detected pair of interfaces a `GameSessionHandling`
implementation can implement:

```ts
export interface ConvertableToSessionState<T = unknown> {
    toSessionState(): T;
}

export interface BuildableFromSessionState<T = unknown> {
    fromSessionState(value: T): this;
}
```

`VideoSlotWithFreeGamesSession` implements both (its free-games num/sum/bank). A game that implements neither gets
a **snapshot-only fallback**: `PokieDevServer` still restores bet/win/screen after a restart, it just can't put a
reconstructed session back into whatever mid-feature state it was in — the same caveat plain `VideoSlotSession`
and any other game without this contract already had. Implementing it is entirely optional and additive; existing
games and the standalone `VideoSlotSession` behave exactly as before whether or not they implement it.

`initialPayload`/`roundPayload` are the `getSessionSerializer()` counterparts — present only for a game
implementing it. `initialPayload` holds `getInitialData(session)`'s output, captured exactly once, at session
creation; it's never recomputed on a spin, since a session's own descriptive data (paytable, availableSymbols,
...) doesn't change between rounds. `roundPayload` holds `getRoundData(session)`'s output, captured fresh after
every spin and replaced each time — it's the actual outcome of the most recent round, not accumulated across
spins. `GET /sessions/:sessionId` reads both straight back out of storage and merges them (see that endpoint's
own note above) rather than re-serializing a reconstructed session, which would silently produce a wrong payload
(see the note there for why).

Credits are handled separately through a `WalletPort`, and are **deliberately not part of `PokieSessionState`** —
a restart always resets balances even when a `FileSessionRepository` keeps the game state:

```ts
export interface WalletPort {
    getBalance(sessionId: string): Promise<number>;
    setBalance(sessionId: string, balance: number): Promise<void>;
}
```

This is the original contract, unchanged — a plain read/full-overwrite pair. Anything implementing it, including
your own pre-existing custom `WalletPort`, keeps working unchanged; see
[Spin orchestration & idempotency](#spin-orchestration--idempotency) below for the additive transactional API
`SpinCommandHandler` actually settles a spin through, and how a plain `WalletPort` gets one automatically. A
custom `WalletPort` implementation can verify its own `getBalance`/`setBalance` behavior against `InMemoryWallet`'s
using the exported `walletPortContractTests` Jest suite:

```ts
import {walletPortContractTests} from "pokie";

walletPortContractTests("MyWalletPort", () => new MyWalletPort());
```

`InMemoryWallet` is the default (and only built-in) implementation, and `PokieDevServer` treats it differently
depending on whether you configured one:

- **No `wallet` option passed** — `PokieDevServer` uses its own default `InMemoryWallet`, and seeds each new
  session's balance from that session's own `getCreditsAmount()` at creation time. This preserves `pokie serve`'s
  original out-of-box behavior: the balance you see is whatever the loaded game package's own config already
  defaults to.
- **`wallet` passed explicitly** — that `WalletPort` (an `InMemoryWallet(initialBalance)` or your own
  implementation) becomes the sole source of a new session's starting balance instead: `PokieDevServer` reads it
  via `getBalance()` for the not-yet-seen `sessionId` and applies it onto the freshly created session, rather than
  the other way around. A session's own default credits never get written back into an explicitly configured
  wallet.

Either way, a session's balance only changes from its starting value after an actual spin (`setBalance()` is
always called after `play()`).

Both are constructor options on `PokieDevServer`, additive to the existing `{host, port}` options (as is
`idempotencyRepository`, see below):

```ts
import {FileSessionRepository, InMemoryWallet, loadPokieGame, PokieDevServer} from "pokie";

const game = await loadPokieGame("./sample-slot");
const server = new PokieDevServer(game, {
    host: "127.0.0.1",
    port: 4000,
    sessionRepository: new FileSessionRepository("./sessions"),
    wallet: new InMemoryWallet(1000),
});
```

A live `GameSessionHandling` object is still needed to actually run `play()` — this is kept in a process-local
cache owned by `SpinCommandHandler` (see below), separate from `SessionRepository`. `PokieDevServer` primes it
with the freshly constructed session on every `POST /sessions`. On a cache miss (e.g. right after a restart), it
reconstructs one via `game.createSession(state.context)` plus `state.bet`, then restores `state.featureState`
onto it via `fromSessionState()` if the game implements `BuildableFromSessionState`, before spinning. Anything not
covered by bet/win/screen/featureState — RNG stream position, for instance — still starts fresh in that case,
same caveat as `--seed` reproducibility elsewhere in this CLI.

### Optimistic locking (session versioning)

`SessionRepository` itself stays the plain, unversioned two-method contract documented above — nothing
about it changed. Both built-in implementations, `InMemorySessionRepository` and
`FileSessionRepository`, additionally implement a second, additive interface:

```ts
export interface VersionedSessionRepository extends SessionRepository {
    loadVersioned(sessionId: string): Promise<{state: PokieSessionState; version: number} | undefined>;
    saveVersioned(sessionId: string, state: PokieSessionState, expectedVersion: number): Promise<number>;
}
```

Every `save()` (through either method) bumps a per-`sessionId` version counter, starting at 1 on the
first save. `saveVersioned()` only writes when `expectedVersion` still matches the repository's current
version, returning the new version on success; otherwise it rejects with a `SessionVersionConflictError`
and leaves whatever's currently stored **completely untouched** — no partial write, no silent
overwrite.

A client can observe the current version through `internal.sessionVersion` on `POST /sessions`,
`POST /sessions/:sessionId/spin`, and `GET /sessions/:sessionId` — present only under `?debug=1`/
`?debug=true` and only when the configured repository is versioned, same opt-in as every other
`internal` field (see [Public vs. internal/debug responses](#public-vs-internaldebug-responses)
above).

`SpinCommandHandler` feature-detects this via `isVersionedSessionRepository()`: when the configured
repository supports it, the state it loads at the start of an attempt is saved back through
`saveVersioned()` with the version it was read at, instead of the plain unconditional `save()`. A
version mismatch becomes a new `SpinCommandResult` outcome, `{status: "conflict", sessionId, reason}`
— by the time it's returned, every wallet transaction this attempt applied has already been reversed
and the live session evicted, the same compensation any other mid-flight failure gets (see
[Failure handling is best-effort compensation, not a transaction](#failure-handling-is-best-effort-compensation-not-a-transaction)
below). `PokieDevServer` maps this to `409 {"error": "..."}` on `POST /sessions/:sessionId/spin`. A
conflicted attempt is never cached under its `requestId` either — a client retry with the same
`requestId` runs for real against whatever is current, rather than replaying the failed attempt.

The version compared above is always the one `SpinCommandHandler` itself just loaded — never a
client-declared expectation. A caller that wants to assert "I expect the session to still be at version
N" and get a `409` on demand when that's stale (rather than only when a genuinely concurrent writer
raced it) passes `expectedSessionVersion` on the spin request body itself — see
[`POST /sessions/:sessionId/spin`](#post-sessionssessionidspin) above — checked by
`SpinCommandHandler.handle()`'s optional third parameter before anything else runs, so a mismatch here
never even reaches `canPlayNextGame()`/`play()`/the wallet.

This mainly matters for a repository **shared across multiple `PokieDevServer` instances or
processes** — e.g. two servers pointed at the same `FileSessionRepository` directory. Within a single
instance, every command for a given `sessionId` is already serialized through `SpinCommandHandler`'s
own per-session queue (see [Idempotency and concurrency](#idempotency-and-concurrency) below), so its
own load-then-save can never race against itself; a conflict there would mean something outside
`SpinCommandHandler` wrote to the repository in between, which the built-in commands never do.

`FileSessionRepository` itself also serializes every `save()`/`saveVersioned()` for one `sessionId`
through its own internal, in-process queue (independent of `SpinCommandHandler`'s), so two calls made
directly against the *same* `FileSessionRepository` object — bypassing `SpinCommandHandler` entirely —
can't interleave their read-then-write either; `fs.readFile`/`fs.writeFile` are async and yield to the
event loop, so without that queue two such calls could both read the same version and both write,
silently corrupting one write with the other. That queue is purely in-memory, though, so it only
protects calls made through *that one instance*. It does nothing for two *separate*
`FileSessionRepository` instances/processes sharing the same directory: `saveVersioned()` re-reads the
file immediately before writing, which narrows that cross-process race, but doesn't close it — there's
no OS-level file lock, so two processes reading the same expected version at nearly the same instant
can still both pass the check before either writes, and the loser's write is silently lost. A
deployment needing a hard guarantee across processes must provide real file locking or a transactional
store itself, the same tradeoff as the wallet/idempotency durability discussion below.

A plain, pre-existing custom `SessionRepository` (only `save()`/`load()`) keeps working exactly as
before — no conflict detection, no `sessionVersion`, no `409`s — since it never implemented
`VersionedSessionRepository` to begin with; implementing that interface is entirely additive and
opt-in, same pattern as `TransactionalWalletPort`/`isTransactionalWalletPort()` for the wallet.

### Spin orchestration & idempotency

`POST /sessions/:sessionId/spin` is implemented by `SpinCommandHandler`, a reusable, transport-agnostic class
(`SpinCommandResult` has no HTTP status codes) that owns the whole spin: replay an idempotent retry, load/
reconstruct the session, gate on `canPlayNextGame()`, run `play()`, settle the wallet, and persist the new state:

```ts
export interface SpinCommandHandling {
    primeSession(sessionId: string, session: GameSessionHandling): void;
    handle(sessionId: string, requestId?: string): Promise<SpinCommandResult>;
}
```

#### Transactional wallet settlement

`SpinCommandHandler` never calls `WalletPort.setBalance()` directly to settle a spin. It settles through a
separate, additive interface:

```ts
export interface TransactionalWalletPort extends WalletPort {
    debit(sessionId: string, transactionId: string, amount: number): Promise<number>;
    credit(sessionId: string, transactionId: string, amount: number): Promise<number>;
    reverse(sessionId: string, transactionId: string): Promise<number>;
}
```

`debit`/`credit` take a caller-chosen `transactionId` and should be idempotent per `(sessionId, transactionId)` —
repeating one that's still in effect must not mutate the balance again. `reverse` compensates the *specific*
transaction recorded under `transactionId` (crediting back a debit, debiting back a credit) instead of asking the
caller to separately track and pass an amount to undo, and must itself be idempotent (reversing twice is a
no-op) — and once reversed, that same `transactionId` stops counting as "already applied": a later call reusing
it (e.g. a retried command after its first attempt was compensated) is applied for real again rather than
silently treated as a no-op replay of the transaction that no longer has any effect. `InMemoryWallet` implements
this natively. A caller-supplied plain `WalletPort` (including your own pre-existing custom implementation,
predating this interface entirely) is transparently wrapped by `PokieDevServer` in a `TransactionalWalletAdapter`,
which keeps its own in-memory transaction ledger on top of `getBalance`/`setBalance` to provide the same
behavior — nothing about an existing custom `WalletPort` needs to change. `isTransactionalWalletPort()` is the
feature-detection `PokieDevServer` uses to skip wrapping a wallet that's already transactional. A custom
`TransactionalWalletPort` (or a plain `WalletPort` you want to check through the adapter) can be verified with:

```ts
import {transactionalWalletPortContractTests, TransactionalWalletAdapter} from "pokie";

transactionalWalletPortContractTests("MyWalletPort (adapted)", () => new TransactionalWalletAdapter(new MyWalletPort()));
```

For each spin, the stake is debited **before** `play()` and the win is credited **after**, as two separate
transactions. Each gets its own id, `{roundId}:{attemptId}:debit` / `:credit` — `roundId` is the spin's
`requestId` (or a generated id when none was given), tying a transaction back to the logical command for
traceability; `attemptId` is freshly generated every time `SpinCommandHandler` actually executes a spin, so a
retried command that follows a reversed prior attempt always gets brand-new transaction ids rather than reusing
the reversed ones — the logical request id and the per-attempt transaction ids are deliberately different things:

- **Stake**: `session.getBet()`, unless the session implements the optional `StakeAmountDetermining` contract
  below, in which case `getStakeAmount()` decides instead. The wallet balance itself is never used to infer "this
  must be a free spin" — a session's `canPlayNextGame()` can legitimately return `true` at any balance for reasons
  that have nothing to do with a free round, so balance alone isn't a safe signal either way.
- **Win**: whatever reconciles the wallet to the session's own final credits after `play()` — i.e.
  `balanceBeforePlay - stakeDebited + winCredited` always equals `session.getCreditsAmount()` post-`play()`. This
  is what keeps the numbers correct even when a session's own accounting doesn't match a naive bet/win split
  (e.g. a free-games round that banks several spins' wins and only pays them out once the round finishes):
  whatever the session's own credits moved by, beyond the stake actually charged, is exactly what gets credited.

```ts
export interface StakeAmountDetermining {
    getStakeAmount(): number;
}
```

Optional and feature-detected, same pattern as `ConvertableToSessionState`/`BuildableFromSessionState`. A session
implementing it is asked what its *next* `play()` will actually charge — `VideoSlotWithFreeGamesSession`
implements it, returning `0` while an unfinished free-games round is in progress (the same condition its own
`canPlayNextGame()` uses to let a spin through regardless of balance) and `getBet()` otherwise, so a free spin
debits zero **at any wallet balance**, not just a low one. A session that doesn't implement this interface is
simply assumed to always charge its full `getBet()`.

#### Failure handling is best-effort compensation, not a transaction

If anything fails after entering the mutating phase — a wallet call, persisting the new session state, or
persisting the idempotency result — `SpinCommandHandler` *attempts* to undo whatever it already did for that
attempt: every wallet transaction already applied is individually reversed by its own `transactionId`, any
already-persisted session state is restored to what it was before the attempt, and the live session is evicted
from the handler's cache. When every one of those compensating steps succeeds, a retry finds either the complete
result of a prior successful attempt or a clean pre-attempt state to spin fresh against.

That's **best-effort, process-local compensation** — not a cross-store database transaction, and not a strict
guarantee. Two concrete ways it can fall short:

- **Process crash.** If the process dies (or is killed) between two of the awaited calls this handler makes — e.g.
  right after debiting/crediting the wallet but before persisting the new session state, or right after
  persisting the session state but before persisting the idempotency result — no catch block ever runs, so
  nothing gets compensated. The wallet, `SessionRepository`, and `idempotencyRepository` can be left durably
  diverged (e.g. a debited wallet whose session state was never updated) until something else reconciles them.
  The built-in `InMemoryWallet` and `InMemoryIdempotencyRepository` lose everything on a crash anyway, so nothing
  survives on their side to diverge — but `FileSessionRepository` writes to disk and *does* survive a crash, so
  its persisted session state can easily end up ahead of (diverged from) an in-memory wallet/idempotency store
  that reset to nothing on restart. A real durable/persistent `WalletPort` or `IdempotencyRepository` doesn't get
  this protection for free just by being used with `SpinCommandHandler`, and pairing `FileSessionRepository` with
  the in-memory wallet/idempotency defaults is exactly this scenario, not a hypothetical one.
- **Compensation failure.** The reversal/restore calls themselves can fail (e.g. the same outage that made the
  original call fail is still ongoing). That failure is swallowed, so it doesn't replace or hide the original
  error `handle()` rejects with — but it also means the compensation silently didn't happen: the wallet and/or
  `SessionRepository` can be left reflecting a partially-applied attempt.

A production deployment that needs real durable atomicity across the wallet, `SessionRepository`, and
`idempotencyRepository` — one that survives a process crash or a failed compensating write — is responsible for
providing it itself, typically by implementing `WalletPort`/`SessionRepository`/`IdempotencyRepository` (or a
subset of them sharing state) over one transactional store and committing the relevant writes together at that
layer. `SpinCommandHandler`'s own compensation is a correctness improvement over doing nothing on failure; it is
not a substitute for that.

**`SpinReconciliationServicing`** (`reconcileOne(sessionId, requestId)`/`reconcileAll()`) is the shipped,
v1.3-compatible palliative for exactly the "process crash" gap above — not a substitute for real cross-store
atomicity, but real recovery logic, not a no-op. `reconcileOne` is called inline by
`SpinCommandHandler.handleSerialized()` whenever a retried `requestId`'s own idempotency result is missing but
its operation record isn't terminal; `reconcileAll()` sweeps every currently-incomplete operation record (e.g. at
startup, against whatever a durable `SpinOperationLog` carried across a restart). Every outcome — `"no-action-needed"`,
`"already-committed"`, a safe automatic `"reversed"`/`"resumed"`, `"deferred"` (a lease is contested, or the
record is too recent to safely act on), or an honest `"manual-recovery-required"` — carries a human-readable
reason; nothing is ever inferred from a checkpoint alone when the wallet supports transaction inspection (see
`isWalletTransactionInspecting`), and no branch ever re-invokes `session.play()` for an attempt being recovered —
only already-computed data is ever replayed. True cross-store atomicity (one transactional store spanning wallet
+ session + idempotency) remains a v2-scale architectural change, not something this palliative attempts.

#### Idempotency and concurrency

Idempotency is a separate, additive `IdempotencyRepository`, keyed by `(sessionId, requestId)`:

```ts
export interface IdempotencyRepository<T = unknown> {
    load(sessionId: string, requestId: string): Promise<T | undefined>;
    save(sessionId: string, requestId: string, result: T): Promise<void>;
}
```

`InMemoryIdempotencyRepository` is the default (a `Map` for the lifetime of the process, same tradeoff as
`InMemorySessionRepository`/`InMemoryWallet`), overridable via the `idempotencyRepository` constructor option.
When `POST /sessions/:sessionId/spin`'s body includes a `requestId`, `SpinCommandHandler.handle()` checks this
repository first and, on a hit, returns the stored result without touching the session, wallet, or
`SessionRepository` again. A successful spin (`status: "played"`) is the only outcome ever stored — `blocked`
(`canPlayNextGame()` false) and `not-found` made no state changes to begin with, so there's nothing to protect
against replaying; `conflict` (see [Optimistic locking](#optimistic-locking-session-versioning) above) is the
same way — its wallet transactions were already reversed before it's returned, so caching it would only make a
retry replay a failed attempt instead of trying for real against the now-current version. Omitting `requestId`
skips idempotency entirely, spinning for real every time.

Every command for a given `sessionId` — the same `requestId` retried concurrently, or two genuinely different
spins racing — is serialized through an internal per-session queue, so there's never more than one
`play()`/wallet-settlement/persist in flight for a session at once. That's also what makes a concurrently
repeated `requestId` safe without any separate "in-flight" tracking: the second call is simply queued behind the
first, and by the time its own turn runs, the first's result is already in `idempotencyRepository` for it to
find — it never spins a second time. A concurrent request for a *different* `sessionId` is unaffected and runs
independently.

### Failure modes

- Missing `<packageRoot>`, an unknown option, a non-numeric `--port`, or a missing `--host` value throw a
  `Usage: pokie serve ...` error before the server starts (same as every other command).
- An invalid or unavailable `packageRoot` prints a concise recovery diagnostic: run
  `pokie validate <packageRoot>` to diagnose it, then retry. Resolver, materialization, and package-loader
  details are intentionally not exposed.
- If the port is already in use, stop the process using it or retry with `--port <number>` (or `--port 0` for an
  available port). Any other listener-start failure tells you to check the configured host and port and retry.
- Once the server is running, errors are JSON HTTP responses (`400`/`404`/`409`/`500` with `{"error": "..."}`),
  not thrown/exit codes — `pokie serve` is a long-running process, not a one-shot command. `409` is specific to
  a spin's session version going stale — see [Optimistic locking](#optimistic-locking-session-versioning) above.

The reusable server sits behind `src/server` (`PokieDevServer`, implementing `PokieDevServerHandling`) — the same
"thin CLI wrapper over a reusable class" shape as [`pokie replay`](#pokie-replay-packageroot):

```ts
import {loadPokieGame, PokieDevServer, PokieDevServerHandling} from "pokie";

const game = await loadPokieGame("./sample-slot");
const server: PokieDevServerHandling = new PokieDevServer(game, {host: "127.0.0.1", port: 4000});
const address = await server.start(); // {host, port} — port is the OS-assigned one if 0 was requested
// ...
await server.stop();
```

## `pokie client <packageRoot>`

Serves the universal browser UI: create a session, save its `sessionId`, restore it
after a page reload, spin, and see credits/bet/win/screen update — plus playback for any
`MultiStageRoundSessionSerializer`-based `stages` array (e.g. a cascade round) and a generic collapsible raw-JSON
view for whatever it doesn't specifically recognize (see [Network Serialization](serialization.md)).

**`pokie client` never starts an API server itself** — it's a static-file server only, expecting a separately
running `pokie serve` (default `http://127.0.0.1:3000`). Use [`pokie dev`](#pokie-dev-packageroot)
to run both together with zero configuration.

```
pokie serve ./sample-slot            # in one terminal
pokie client ./sample-slot            # in another
```

```
POKIE client UI listening on http://127.0.0.1:3100
Talking to a pokie serve API expected at http://127.0.0.1:3000 — start it separately (e.g. "pokie serve") or use "pokie dev" to run both together.
```

Options:

- `--port <number>` — port to listen on (default `3100`). Pass `0` to let the OS assign a free port.
- `--host <string>` — host/interface to bind (default `127.0.0.1`).
- `--api-host <string>` / `--api-port <number>` — where to expect the `pokie serve` API (default
  `127.0.0.1:3000`).
- `--no-open` — don't try to open a browser.

Once listening, `pokie client` best-effort opens a browser pointed at the UI it just started — the same
`open`/`start`/`xdg-open` mechanism, and the same `--no-open` escape hatch, `pokie dev` (below) uses. A two-step
`pokie serve` + `pokie client` workflow ends up at the exact same canonical player, opened the exact same way, as
running `pokie dev` directly.

`<packageRoot>` is required — for signature symmetry with `pokie serve`/`pokie dev`, and because the scaffolded
`"client": "pokie client ."` script always passes one — but it's **never loaded**: the browser UI is entirely
game-agnostic, so `pokie client` doesn't call `loadPokieGame` at all.

If the UI port is already in use, stop the process using it or retry with `--port <number>` (or `--port 0` for an
available port). Any other listener-start failure tells you to check the configured host and port and retry.

The client's own configured API address is served from the same origin at `GET /config`
(`{"apiBaseUrl": "http://host:port"}`), which is how the served page knows where to `fetch()` without any
build-time configuration — `pokie dev` (below) sets this to the API port it actually bound, so the two always
agree even when both are started with `--port 0`.

The reusable server sits behind `src/server` (`PokieClientServer`, implementing `PokieClientServerHandling`),
the same shape as `PokieDevServer`:

```ts
import {PokieClientServer, PokieClientServerHandling} from "pokie";

const server: PokieClientServerHandling = new PokieClientServer("./dist/cli/client", {
    host: "127.0.0.1",
    port: 3100,
    apiAddress: {host: "127.0.0.1", port: 3000},
});
const address = await server.start();
// ...
await server.stop();
```

## `pokie dev <packageRoot>`

Runs [`pokie serve`](#pokie-serve-packageroot) and
[`pokie client`](#pokie-client-packageroot) together — as two HTTP listeners in one process, not
child processes — waits for the API's `GET /health` to actually respond, best-effort opens the default browser
pointed at the client, and cleanly stops both servers on `Ctrl+C` (`SIGINT`/`SIGTERM`).

```
pokie dev ./sample-slot
```

```
POKIE dev server listening on http://127.0.0.1:3000
POKIE client UI listening on http://127.0.0.1:3100
This is a local/dev reference setup for a single game package — not a casino backend or RGS.
```

Options:

- `--port <number>` / `--host <string>` — the API server's port/host (same defaults as `pokie serve`).
- `--client-port <number>` / `--client-host <string>` — the client server's port/host (same defaults as
  `pokie client`).
- `--no-open` — don't try to open a browser.

Opening the browser is entirely best-effort: it shells out to `open` (macOS), `start` (Windows), or `xdg-open`
(everything else), and a failure there (no display, sandboxed environment, missing binary, ...) is swallowed —
it never fails the command. Registering `SIGINT`/`SIGTERM` handlers to stop both servers means `pokie dev` also
calls `process.exit()` itself once both `.stop()` calls settle (successfully or not) — Node won't exit
automatically once a custom signal handler is registered.

If the package cannot be resolved, materialized, or loaded, `pokie dev` tells you to run
`pokie validate <packageRoot>` and retry without exposing underlying resolver or loader details. If either API or
UI listener cannot start, use the diagnostic's matching `--port` or `--client-port` recovery option; a busy port
can be freed or replaced with `0` for an available port, while another listener failure means checking the
configured host and port before retrying.

## `pokie`

Launches **POKIE Studio**: a local web app (its own HTTP server plus a small browser-based
frontend) that hosts a GUI for the commands above. The Home nav below already covers `create`/`init`/`build`/
opening a project; the Project Dashboard (see its own section) covers `inspect`/`validate`/`sim`/`report`/`replay`.
Like `pokie serve`/`pokie dev`, this is a **local/dev tool, not a casino backend or RGS** — no real-money wallet,
no authentication, and no operator/integration logic of any kind. Studio's own Play tab drives a real game
session entirely in-process (never a server, never a host/port a browser could be pointed at) — to actually
stand up an HTTP server for external clients to hit, use [`pokie serve`](#pokie-serve-packageroot)
or [`pokie dev`](#pokie-dev-packageroot) directly.

The frontend itself is a React + Mantine single-page app built with Vite (`cli/studio-client/`); its API/
behavior is exactly what's documented below, unchanged from the sections that follow. See
[`studio-frontend.md`](studio-frontend.md) for the frontend's own stack, layout, dev workflow, and test setup.

Several invocations launch it, resolved by `resolveCliInvocation` (`cli/resolveCliInvocation.ts`):

- `pokie .` — Project mode for the current directory.
- `pokie [projectRoot]` — Project mode for the supplied project root, as long as that path isn't itself one of the command
  names below and actually exists (a typo'd command name is never silently treated as a path — see below).

Bare Studio flags discover a project from the working directory, so `pokie --no-open` inside a project opens that
project rather than Home. `pokie` with no arguments is reserved for the first-contact command guide above.

"Is this a game package" is decided by the same `"pokie": {"entry": ...}` field in `package.json` that
[`loadPokieGame`](game-packages.md) itself reads — the discovery walk reuses that one definition instead of a
second one, and it stops there: whether the entry module actually loads stays the Project Dashboard's own
question, so a project with a broken entry still opens its dashboard and reports the error there. Nothing is
remembered between runs either — the target is always rediscovered from the current working directory, never
restored from a "last opened project".

Every other named POKIE invocation (`pokie sim ...`, `pokie serve ...`, etc.) is unaffected — a first
argument that matches a known command name always dispatches to that command, never to Studio.

Whichever mode the server starts in, the frontend opens directly on that mode's own screen: Project mode lands on
`#/project/overview` and Home mode on `#/home/design`. The browser can't know the mode from the URL (a hash route
is never sent to the server), so `#/` asks `GET /api/context` once at startup and redirects accordingly —
replacing the entry, so Back doesn't return to it.

```
pokie .
```

```
POKIE Studio listening on http://127.0.0.1:3200
```

A browser tab opens automatically (same best-effort `open`/`start`/`xdg-open` mechanism as `pokie dev`, and the
same `--no-open` escape hatch) showing the opened package's Project Dashboard. Home is task-oriented, with exactly
2 tabs —
**Design Game** (`/home/design`, the default) and **Projects** (`/home/projects`) — see
[`studio-frontend.md`](studio-frontend.md#ux--information-architecture) for the full layout/navigation detail.
There is no separate scaffolding/init/build-from-existing-blueprint-file surface any more: those flows now live
only in the CLI (`pokie init [directory]` for a prepared, immediately valid package; `pokie create [name]` for an
editable Blueprint Project) — Home never shells out to them, it simply doesn't duplicate them.

- **Design Game** is the guided happy path: a **New Blueprint** dialog (Blank / Random / from an existing
  blueprint file) starts a draft, then the same Blueprint Editor used to configure, validate, and build it —
  editing the exact same DTO [`pokie build <project> --target tsPackage`](#pokie-build-project) accepts (no
  separate Studio-only blueprint schema).
  A **Form**/**JSON** toggle switches between the field-by-field editor (with add/remove/duplicate/reorder
  controls for every collection: symbols, bets, paylines, paytable rows, reel-strip symbols, symbol-weight rows,
  plus wild/scatter checkboxes and a reel-strips-vs-symbol-weights mode toggle) and a raw JSON textarea kept in
  sync with it — a Form edit always re-derives the JSON text, a syntactically valid JSON edit always re-derives
  the Form, and invalid JSON (or JSON that parses but isn't an object) leaves the last-known-good state untouched
  rather than clearing the editor; any top-level field the Form doesn't know about survives every round trip
  unchanged. **Validate** runs the same `GameBlueprintValidator` used everywhere else, without touching disk.
  Load/Save-by-path and the raw JSON view are tucked behind a "Show advanced options" disclosure — the guided
  flow itself never requires them. **Build** runs the exact same `tsPackage` conversion
  [`pokie build <project> --target tsPackage`](#pokie-build-project) runs through `ArtifactBuilderRegistry` —
  not a separate Studio-only pipeline — including the same safe-rebuild/conflict check (building into a
  directory that already contains files a prior build didn't generate is refused with the same descriptive
  error `pokie build` itself gives; re-building against a directory a build already succeeded against earlier
  in the session asks for confirmation first), followed by an **Open in Studio** button on success — the bridge into the
  Project Dashboard. A **Reel Strip Modeler** mode (alongside Default/Reel strips/Symbol weights) edits a
  `GameBlueprint`'s per-reel [`reelStripGeneration`](#reelstripgeneration-build-time-reel-strip-generation)
  array: each reel independently toggles between **Literal** (the same per-symbol strip editor as the Reel
  strips mode) and **Generated** (that reel's own length, seed, max attempts, an exclusive counts-or-weights
  table, a locked-positions table, and its `constraints` array edited as raw JSON — there are seven constraint
  types with quite different fields, so this reuses the same JSON-editing affordance the whole-blueprint JSON
  view already has instead of one bespoke widget per type). Switching a reel between Literal/Generated, or a
  generated reel's own source between counts/weights, never discards what was already entered on the side being
  left. A generated reel's own **Length** can be set automatically to the sum of its currently active
  counts/weights (**Auto length**); its `constraints` can be started from a handful of built-in **presets**
  (still just plain `ReelStripConstraintSpec` objects appended to the same JSON array); and a reel's own draft
  can be replaced wholesale with another already-configured reel's own entry (**Copy from reel**). **Resolve
  reels** calls `POST /api/home/blueprints/reel-strip-generation-preview` (see the API section), which runs the
  exact same `resolveReelStripGeneration`/`ReelStripGenerator`/`ReelStripAnalyzer` `pokie build` itself uses —
  never a reimplementation — and shows every reel's exact resulting symbol sequence, symbol-count analysis, and
  (for a generated reel whose constraints can't be satisfied) every generation attempt's own diagnostics/
  violations, without writing anything. **Save** always writes the *authored* `reelStripGeneration` array
  (counts/weights/seed/constraints), never a resolved/materialized strip.
- **Projects** lists every already-known project — managed (created/opened this Studio session, in-memory only,
  reset on restart) and registered (persisted across restarts via `StudioProjectRegistrationService`) — each
  showing its name, path, and last-opened time; a project whose directory/`package.json` can no longer be found
  is flagged **missing** rather than silently dropped. **Open** loads it with `loadPokieGame`, the same package
  loader every other command uses, and switches to the **Project** dashboard on success. **Import Project**
  previews/validates a target path before ever registering it — a detected PAR sheet routes into Design Game's
  own PAR Sheet Import/Export panel instead of being registered as a package, since there's no "open" story for
  a PAR sheet the way there is for a runnable one.

None of these ever shell out to `pokie create`/`init`/`build` as a subprocess, or duplicate their logic — see
`StudioBlueprintService` (`cli/studio/blueprint/StudioBlueprintService.ts`) for the Blueprint Editor and
`StudioHomeService` (`cli/studio/home/StudioHomeService.ts`) for Open/recent-projects bookkeeping — both drive
the same underlying services directly.

A **Documentation** section links into this repository's docs.

Options:

- `--port <number>` / `--host <string>` — where Studio listens (default `127.0.0.1:3200`).
- `--no-open` — don't try to open a browser.

### Project Dashboard

Opening or creating a project — or launching Studio directly with `pokie .`/`pokie [projectRoot]`
— switches Studio into the **Project** mode/route, identified by that project's `projectRoot`, and shows the
**Project Dashboard**.

The Dashboard has several tabs today, switched client-side with no full page reload — **Overview**, **Game
Model**, **Play**, and **Simulation** first (the primary flow, in that order), then **Replay**,
**Build/Export**, **Certification**, and **Fairness** grouped as "Advanced" in the navigation (still one click
away, just visually secondary — a tab is only offered at all once the loaded project's own resolved capabilities
support it; see [`studio-frontend.md`](studio-frontend.md#ux--information-architecture) for the exact, current
tab list). There is no standalone "Validate" tab any more — validation is automatic diagnostics folded into
Overview itself, run on load and re-run on demand — and no standalone Deployment/Outcome Libraries/Stake Engine
Export tabs either. Deployment and Stake Engine Export have moved to **Build/Export** cards, so their legacy deep
links redirect there with migration guidance. Outcome Libraries' retired select-existing/inspect/compare work has
no Build/Export equivalent: its legacy deep links land on **Overview**, explain that it is unavailable in Studio,
and point to the opened outcome source plus the CLI comparison commands. The old workflows themselves no longer
mount. Overview is informational diagnostics only — it surfaces validation status
alongside the rest of the project's state, with no wizard-like next-step recommendation or call to action:

- **Overview** shows the game's name/id/version, the absolute `projectRoot`, its `package.json` identity (name,
  version — the same data [`pokie inspect`](#pokie-inspect-packageroot) prints), and its validation report
  (errors, warnings, suggestions), refreshed
  automatically and re-runnable on demand. An **Inspect** quick action re-runs the inspection (handy after
  rebuilding without restarting Studio).
- **Game Model** is a read-only, resolved-project-type-aware projection of the game (manifest, reels/rows,
  symbols, paylines, paytable, reel strips/symbol weights, available bets) via `GET /api/project/gameModel` — for
  a project with an editable source blueprint, each section also offers **Edit** straight from this view (scoped
  to one section at a time), reusing the exact same Blueprint Editor components Design Game's guided flow uses.
- **Play** is Studio's own — and only — game mode: **New session**/**Reset** create a real session directly in
  Studio's own backend (never a server, never a host/port a browser could be pointed at — to stand up an actual
  HTTP server, use [`pokie serve`](#pokie-serve-packageroot)/[`pokie dev`](#pokie-dev-packageroot)
  instead) and spin it for real, with every round rendering through the same `RoundArtifactInspector` the Replay
  tab uses. Also reachable for a resolved outcome-library project, sampled through its own outcome-source draw.
- **Simulation** — see its own section below.
- **Replay** — see its own section below.
- **Build/Export** — see its own section below.
- **Certification** and **Fairness** are thin GUI wrappers over the exact same backend building blocks their CLI
  counterparts use — [`pokie certification`](#pokie-certification-build-bundledir-configjson) and
  [`pokie fairness`](#pokie-fairness-seed-commit-serverseedtxt---out-file---overwrite) respectively — with no
  dedicated walkthrough of their own in this file yet; see each linked CLI section (or
  [`certification-evidence-bundle.md`](certification-evidence-bundle.md)/[`provably-fair.md`](provably-fair.md))
  for the underlying workflow each tab drives through the Studio API.

Every quick action calls `GamePackageInspecting`/`PokieGamePackageValidating`/the simulation services directly (the
same services `pokie inspect`/`pokie validate`/`pokie sim` use) — Studio never spawns a CLI command as a
subprocess, and never duplicates their logic.

The Dashboard itself has four states, all handled explicitly by the frontend:

- **empty** — Studio is in Home mode; there's no project to show a dashboard for.
- **loading** — only right after Studio starts directly into Project mode (`pokie .`/`pokie [projectRoot]`); the entry
  module hasn't finished loading yet. Design Game's Build and Projects' Open both already have the manifest in
  hand by the time they switch Studio into Project mode, so they go straight to **loaded**.
- **loaded** — the game's manifest (id/name/version) loaded successfully.
- **error** — loading the entry module failed (missing build output, a package that doesn't satisfy the
  `PokieGame` contract, a corrupt/missing `package.json`, an entry module that throws on import, ...). Overview
  stays usable even here — Inspect only reads `package.json`/`build-info.json` (no entry module needed), and its
  folded-in validation diagnostics are exactly how to see the concrete reason loading failed.

#### Simulation

The **Simulation** tab runs a [`pokie sim`](#pokie-sim-packageroot)-equivalent simulation against the active
project and shows a human-readable report — without ever shelling out to `pokie sim` or reimplementing its logic.
A form asks for **rounds** (required, a positive integer), an optional **seed**, and **workers** (a positive
integer, default `1`), same as `pokie sim --rounds/--seed/--workers`; running it shows **queued** → **running**
(with a live rounds-completed/total progress line — aggregated across every worker when `workers > 1` — and
elapsed duration) → **completed**/**failed**/**cancelled**. A **Cancel** button is available while
queued/running (asking for confirmation before it actually cancels — see below for what cancelling actually stops
when `workers > 1`), and once the job reaches a terminal state, a **Run again with the same parameters** button
re-submits the exact same rounds/seed/workers.

The report shown on completion includes at minimum: game id/version, rounds (and requested rounds, if the game
stopped itself early), seed, total bet, total payout, RTP, hit frequency, volatility/standard deviation, the RTP
95% confidence interval, max win, a base/free-games/custom category **breakdown** table when the report has one
(same as [`pokie sim`](#pokie-sim-packageroot)'s own breakdown — omitted entirely for a game whose session doesn't
support round categorization), and any **warnings**/**reproducibility** command the report carries.

Only one simulation may be queued/running per project at a time — starting a second one while the first is still
active returns a `409` naming the already-active job's id, rather than silently starting a competing run.

Studio drives every simulation through the same [`ParallelSimulationRunner`](simulation.md#parallel-simulation-workers)
`pokie sim --workers` uses — not a separate implementation of its own. For `workers === 1` (the default), that
means the same bounded-chunks-with-a-yield-between-them approach as before (progress/cancellation only take effect
between chunks, since [`AggregateSimulationRunner`](#pokie-sim-packageroot) itself is a synchronous,
uninterruptible loop with no hooks of its own); for `workers > 1`, real worker threads are spawned per
`ParallelSimulationRunner`'s own rules (see [Worker package-loading limitations](simulation.md#worker-package-loading-limitations)
— this is why Workers is only usable against a real, on-disk project, which every open Studio project already
is), and cancelling terminates every one of them immediately rather than waiting for a chunk boundary. Either way,
a cancelled/failed job never surfaces a partial report as if it were a successful one. Stopping Studio itself
(`Ctrl+C`) cancels every still-active simulation the same way.

#### Reports

Every simulation that reaches **completed** shows up in the **Reports** tab's list — reopenable at any point during
the current Studio process, not just right after it finishes. Each row shows the simulation id, game id/version,
requested vs. actual rounds, seed, RTP, hit frequency, max win, started/completed time, duration, whether the
report has warnings, and its status; clicking one opens the full report below the list. The Simulation tab's own
"View in Reports" button jumps straight to that same detail view for the simulation that just ran, and the detail
view's own "Back to Simulation parameters" button returns to the Simulation tab with **rounds**/**seed** pre-filled
from that report, ready to re-run. **Refresh** re-fetches the list without a full page reload — handy after
starting another simulation from a different tab.

The detail view offers three downloads — **Download JSON**, **Download Markdown**, **Download HTML** — plain links
to `GET /api/project/reports/:id/download?format=...` (see below); the browser's own save dialog handles the rest,
no client-side blob handling needed. Markdown/HTML are rendered with the exact same
`MarkdownSimulationReportRenderer`/`HtmlSimulationReportRenderer` [`pokie report`](#pokie-report-simulationreportjson)
uses — Studio never spawns `pokie report` as a subprocess, and never reimplements its formatting.

Only **completed** simulations ever appear in the list — a failed/cancelled job has no report to show, though it's
still retained (see below) in case its id is looked up directly. Opening a report for a simulation that hasn't
completed yet, has no report (failed/cancelled), or doesn't exist at all are all handled explicitly (see the API
section's `409`/`404` cases below) rather than crashing the detail view.

Studio keeps at most the 20 most recently completed/failed/cancelled simulations per project (oldest evicted
first) — a queued/running job is never evicted, no matter how many terminal jobs pile up around it. This is a
process-local, in-memory limit (same as the simulation jobs themselves): restarting Studio clears it.

#### Replay

The **Replay** tab (also called Replay & Debug) runs a [`pokie replay`](#pokie-replay-packageroot)-equivalent
replay against the active project — reusing `loadPokieGame`/`GameSessionHandling.play()` directly (the same
primitives `ReplayRecorder` itself uses), never shelling out to `pokie replay` or reimplementing its logic.

Replay has no single sequential order shared by every source — a live spin has nothing to reproduce, a pasted
artifact validates before it can (optionally) reproduce, and a fresh seed/round or simulation round has no prior
result to compare against at all — so `ReplayTab.tsx` doesn't force any of this through a `Stepper`. Instead it
renders one page: a **source choice** (a segmented control), that source's own configuration/load controls, then —
once something's loaded — a card showing what's loaded, an action bar for whatever's actually available
(reproduce/cancel/retry), and the result view, all inline with nothing gated behind a click to "continue". Export
is likewise an action, not a page: a **Download JSON** button is always visible, just disabled until the
currently-selected source has something to export. Switching the source resets every per-source selection and any
loaded/reproduced state outright, so a stale card or result from a previous source never lingers under a newly
picked one.

The source choice offers four methods:

- **Recreate from seed** — a **target round number in a new replay session** (required, a positive integer) and an
  optional **seed**, same as `pokie replay --round/--seed`. Reproducing always creates a brand-new game session and
  plays it forward from round 1 through the target round — it never looks up an existing session's recorded round,
  even when the seed happens to match one that was recorded before (that's what **Session Spin**/**Replay Artifact**
  are for). **Load** stages it as the round/seed to reproduce.
- **Replay Artifact** — paste a replay artifact JSON (as produced by this same tab's own Export) into a textarea;
  **Validate & load** posts it to `POST /api/project/replays/inspect-artifact` (see below), which applies the exact
  same round/seed validation `POST /api/project/replays` itself would. A structurally invalid nested artifact is
  reported back as non-fatal warnings rather than blocking outright — round/seed alone are enough to attempt a
  reproduction. Or pick one directly from a **Recent Replays** list to both load it and mark it as the "expected"
  side for comparison.
- **Session Spin** — pick a round from a shared, project-scoped recent-spins list (`GET /api/project/rounds`
  — see the API section below), optionally filtered down to one session; every real round played anywhere in
  Studio (a Play tab spin/scenario search, an Outcome Source Analysis sample draw, a Replay tab "Recent Simulation"
  reproduction) is recorded into this one list, most-recent-first, capped at the 20 most recent, cleared on project
  switch. This is an already-recorded result, so there's nothing to reproduce — picking one loads straight into its
  own inspect view, with no Reproduce action at all.
- **Recent Simulation** — pick a completed simulation report, then a round number within it, and **Load** stages
  that round to reproduce with the simulation's own seed.

For a loaded **Replay Artifact** record, the loaded card first runs it through a reproducibility gate
(`describeReplayReproducibility`): reproducing forward from round 1 is only a *verifiable* match of the original
result when the record's seed and game id/version provenance are known and match the currently loaded project, and
— whenever the record carries a round artifact at all — its `stateBefore`/`stateAfter` and a `debug.reelStops` RNG
trace are present to check a fresh reproduction against. An artifact missing any of these (e.g. an import that only
kept the round-level result, or a hand-trimmed record) disables **Reproduce** with a specific reason and
remediation (add the missing field) rather than silently running an unverifiable replay.

**Reproduce** (not offered for Session Spin, which has nothing to reproduce) runs the replay as a background job,
in bounded chunks against one long-lived session — the exact same reason [Simulation](#simulation) is chunked:
replaying a large `round` in a single call would block the whole HTTP server's event loop for as long as it took.
`POST /api/project/replays` therefore returns immediately (`202`) with a **queued** job; the action bar then shows
**queued** → **running** (with a live completed-rounds/requested-round progress line and elapsed duration) →
**completed**/**failed**/**cancelled**, with the result view appearing inline the moment an active run goes
terminal. A **Cancel** button is available while queued/running (asking for confirmation first), and once
terminal, **Run again with the same parameters** re-submits the exact same round/seed. Only one replay may be
queued/running per project at a time — starting a second one while the first is still active returns a `409`
naming the already-active job's id. Cancellation, like Simulation's, can only take effect between chunks, not
mid-chunk. The session itself is created exactly once per job and reused across every chunk — never recreated, and
its RNG/game state is never reset — so the sequence of rounds actually played, and therefore the resulting
descriptor, is identical to what `ReplayRecorder`'s own uninterrupted loop would produce for the same seed/round;
only the *scheduling* differs. Studio bounds `round` to an explicit safety ceiling (`MAX_STUDIO_REPLAY_ROUND`,
100,000) — `pokie replay` itself has no such limit; this mostly bounds how long a single replay job can occupy its
project's one-active-replay-at-a-time slot.

The result view shows, for **Session Spin**: a read-only table (game, session id, this session's own round number,
request id, recorded-at timestamp, source — Play tab spin vs. an outcome-library draw vs. an Outcome Source
Analysis sample vs. a Recent Simulation reproduction — credits, bet, win), the spin's own **screen** grid, and an
Advanced disclosure with debug data/raw before-after state/the full session JSON.
For every other method, once a round has actually been reproduced, a video-slot round's full `RoundArtifactJson`
(see [Round Artifacts](round-artifacts.md)) renders through the same `RoundArtifactInspector` component every
other artifact-viewing tab uses, plus — whenever an "expected" artifact is loaded (a pasted/picked Replay Artifact)
— a match/mismatch comparison banner covering **screen**, **wins**, **totalPayout**, **steps**, **featureEvents**,
**state** (the before/after transition), and **rngReelStops** (an explicit `debug.reelStops` field only) as
independent dimensions, each `match`/`mismatch`/`unavailable` (a dimension missing or malformed on either side is
`unavailable`, never silently folded into a match or a thrown error). A non-video-slot session instead shows the
plain round summary (game, round, seed, total bet/payout, timestamp, duration) and screen (or a "no screen
available" notice for a session without `getSymbolsCombination()`).

**Download JSON** downloads the result as JSON: for Session Spin, a client-built blob of the full session view; for
every other method, it links to `GET /api/project/replays/:id/download` — only available once the job is
`"completed"`; a failed/cancelled job has no descriptor to download, same as a failed/cancelled simulation having
no report.

The tab also carries a standing notice that replay reproducibility is best-effort: a deterministic game reproduces
exactly for the same seed/round, but a game whose outcome doesn't depend solely on the seed may not.

A **Recent Replays** list (shown at the bottom of the page, below the source choice/loaded card/action bar) lists
every replay job for the active project regardless of status (including a still-running one, unlike Simulation's
Reports list which only ever shows completed jobs), most-recently-started first, each with **Inspect** (fetch and
load it straight into the loaded card/result view) and **Reproduce & compare** (switch to Replay Artifact, load it
as the "expected" side) actions. Studio keeps at most the 20 most recent *terminal* (completed/failed/cancelled)
replays per project (oldest evicted first) — a queued/running job is never evicted. This is a process-local,
in-memory limit, same as Reports: restarting Studio clears it, and a replay from one project becomes unreachable (a
`404`, indistinguishable from an unknown id) once Studio switches to a different project. Stopping Studio itself
(`Ctrl+C`) cancels every still-active replay the same way it cancels every still-active simulation.

#### Build/Export

**Build/Export** (`ExportDeployTab.tsx`) is the sole Studio build surface. The old standalone Deployment and Stake
Engine Export workspaces have moved to their corresponding cards here; Outcome Libraries' retired
select-existing/inspect/compare workspace is not a builder and has no equivalent card. Every retained builder is
grouped by kind (`ExportDeployTargets.ts`):

- **Outcome libraries** — generates or selects the canonical `WeightedOutcomeLibrary` every other card below reads
  from (a build step in its own right, not a delivery target), the same underlying operation as
  `pokie export <config.json> --to outcomes`.
- **Static export** — writes a standalone, self-contained bundle to disk (e.g. a Stake Engine export via
  [`StakeEngineExporter`](stake-engine-export.md)) — nothing is registered, nothing runs a delivery step.
- **Build artifact** — runs the project through `pokie`'s own `ArtifactBuilderRegistry`, the exact same
  `pokie build <project> --target <target>` conversions the CLI itself offers, only ever listing a target the
  project's own resolved type actually supports.
- **Remote deployment** — a GUI over the `pokie` package's own [External Adapter SDK](external-adapter-sdk.md):
  `StudioDeploymentService` (`cli/studio/deployment/StudioDeploymentService.ts`) never projects a `RoundArtifact`,
  generates an artifact, or validates compatibility/output itself; every one of those steps is delegated straight
  to `ExternalDeploymentService.deploy()`, the SDK's own single orchestrator. Studio ships no private RGS
  integration of its own — Publish is only ever offered once a project has registered a real
  `ExternalDeploymentTarget` (see the SDK doc above); until then, this group shows only a placeholder card
  explaining that nothing deployable is registered yet. Studio only owns two things on top of the SDK: which
  real, registered target(s) are available for the active project to select as cards, and turning the card's own
  form into the SDK's input shapes. Selecting a registered
  target shows its `id`, `version`, `requirements` (`minPokieVersion`/`symbolAlphabet`/
  `requiresHomogeneousProvenance`, whichever are set), and `capabilities`; the deploy form then asks for one or
  more **modes**, each a **mode name** and a **library JSON path** (a `WeightedOutcomeLibrary` file, resolved
  relative to the active project's own root — the same "a path, never an inline blob" convention every other
  Project Dashboard feature follows; refused with `400` if it resolves outside the project root); **Add mode**
  appends another mode row for a multi-mode deployment (only accepted by a target that declares the `multiMode`
  capability). **Check & Preview** and **Publish** are not two different pipelines — both call the exact same
  `ExternalDeploymentService.deploy()`, against the exact same target, differing in exactly one thing: Preview
  strips the target's own `runtimeAdapter` first, so the SDK's own existing "only call `runtimeAdapter.deliver()`
  when the target declares one" behavior means nothing is ever written anywhere; Publish keeps it (behind a
  confirmation prompt, since it writes files). Either way, the response is rendered **stage by stage** — target
  descriptor, compatibility, round projection, artifact generation, artifact validation, target diagnostic, and
  delivery — each shown as ok/error/skipped, with every stage's own `ValidationIssue`s listed underneath it; a
  stage is "skipped" exactly when `ExternalDeploymentService` itself never ran it (an earlier stage already
  failed), never inferred any other way by the client. **Generated artifacts** lists every file the run produced;
  clicking one shows its own textual content (already returned as part of the run's own response — no second
  request) — so a preview's own output can be read in full *before* anything is ever published.

Build/Export is deliberately a single-mode, zero-configuration surface run against the project's own first
current build mode (or `"base"` when none is known) — a project that genuinely needs a multi-mode bundle has no
separate dedicated workflow to fall back to yet. Outcome Libraries' select-an-existing-library/inspect/compare
tooling has no Build/Export equivalent — only generating a fresh library does. Accordingly, legacy Deployment and
Stake Engine Export links (`/project/deployment`, `/project/stakeEngineExport`) redirect to Build/Export and explain
the retained card; legacy Outcome Libraries links (`/project/outcomeLibraries`) land on Overview with an explicit
unavailable explanation and CLI comparison recovery. Obsolete Validate routes land on Overview diagnostics with
the corresponding recovery guidance.

### API

Studio's frontend and JSON API share one origin/server (unlike `pokie serve`/`pokie client`'s deliberate split) —
no CORS handling is needed. Every response is a typed, plain-data DTO — no stack traces are ever sent to the
client, even for a load/validation failure.

- `GET /api/health` — `200 {"status": "ok"}`, always, once Studio is up.
- `GET /api/context` — the current mode: `{"mode": "home"}` or `{"mode": "project", "projectRoot": "..."}`.
- `GET /api/studio/diagnostics` — safe, plain diagnostic data, in either mode: `{"studioVersion", "nodeVersion",
  "mode", "projectRoot"?, "activeSimulationCount", "activeReplayCount", "recentProjectStoragePath",
  "uptimeSeconds"}`. Every field is a primitive already safe to expose — never a stack trace, an environment
  variable, a token, or a service instance; `recentProjectStoragePath` is always the literal
  `"in-memory (no persistent path)"`, since recent projects are never actually persisted to disk (see
  **Recent Projects** above).
- `GET /api/home/recent-projects` — the in-memory recent-projects list: `{projectRoot, name, openedAt,
  missing}[]`, most-recently-started first. `missing` is `true` when the project's directory/`package.json` can no
  longer be found on disk — the entry itself is never dropped just because of that (see
  `StudioHomeService.listRecentProjects()`).
- `GET /api/home/fs/browse?path=<optional>` — backs the "Browse" action on every filesystem-path input in Home
  (e.g. Import Project, the New Blueprint dialog's Load-existing option). Lists `path`'s immediate children
  (defaulting to the directory Studio itself was started in when `path` is omitted): always `200` with
  `{"status": "ok", "resolvedPath", "displayPath", "parentPath"?, "entries": [{"name", "isDirectory"}]}`
  (directories sorted before files, dotfiles hidden; `displayPath` is relative — `"./games/foo"` — when
  `resolvedPath` falls strictly inside Studio's own working directory, and Studio's own absolute
  working-directory path (never a bare `"."`) otherwise, including when `resolvedPath` *is* that root) or
  `{"status": "error", "error": "...", "resolvedPath"}` for a nonexistent/unreadable/non-directory path — never a
  4xx, same reasoning as `POST /api/home/projects/open` below.
- `POST /api/home/blueprints/validate` `{"blueprint": <any JSON value>}` — runs `GameBlueprintValidator` against
  `blueprint` as given (no file is read or written): `400 {"error": "..."}` only if `blueprint` itself is missing
  from the request body; otherwise always `200` with `{"status": "ok", "warnings": [...]}` or `{"status": "invalid",
  "errors": [...], "warnings": [...]}`.
- `POST /api/home/blueprints/load` `{"path": string}` — reads and parses `path` as a `GameBlueprint` JSON file (the
  same `loadGameBlueprint` `pokie build` itself uses): `200 {"status": "ok", "path": "<resolved path>", "blueprint":
  <parsed value>}`, or `200 {"status": "load-error", "error": "..."}` for a missing file, invalid JSON, or a path
  that resolves inside Studio's own internal asset directory. `400 {"error": "..."}` only for a missing/malformed
  `path`.
- `POST /api/home/blueprints/save` `{"path": string, "blueprint": <any JSON value>, "overwrite"?: boolean}` — writes
  `blueprint` to `path` as formatted JSON (known `GameBlueprint` fields in a fixed order, any unrecognized top-level
  fields preserved and appended after them, 4-space indent, trailing newline — deterministic: re-saving unchanged
  content produces byte-identical output). If `path` already exists and `overwrite` isn't `true`, nothing is written
  and the response is `409 {"status": "conflict", "path": "...", "error": "..."}` — resend with `"overwrite": true`
  to replace it. `201 {"status": "ok", "path": "..."}` on a successful write; `200 {"status": "error", "error":
  "..."}` for an fs failure or a path resolving inside Studio's own internal directory (safe message, never a stack
  trace). `400 {"error": "..."}` only for a missing `path`/`blueprint`, or a non-boolean `overwrite`.
- `POST /api/home/blueprints/reel-strip-generation-preview` `{"blueprint": <any JSON value>}` — same request shape
  and shape-validation as `/validate` (`400 {"error": "..."}` only if `blueprint` itself is missing); resolves
  `blueprint.reelStripGeneration` (if present) via the real `resolveReelStripGeneration`/`ReelStripGenerator` and
  analyzes every reel's resulting strip via `ReelStripAnalyzer` — never writes anything. Always `200 {"status": "ok",
  "errors": [...], "warnings": [...], "reels": [...]}`: `errors`/`warnings` are the same `GameBlueprintValidator`
  issues `/validate` would report, but never block `reels` — a blueprint-level problem unrelated to
  reelStripGeneration itself (a broken paytable, an invalid `availableBets`, ...) never hides every other,
  resolvable reel's result. `reels` is empty when the blueprint has no `reelStripGeneration` at all; a
  reelStripGeneration entry that isn't even a well-formed object (a hand-edited JSON blueprint) is simply left out
  of `reels` rather than failing the request. Each remaining entry is either `{"reelIndex", "type": "literal",
  "strip", "analysis"}` or, for a `"generated"` reel, `{"reelIndex", "type": "generated", "seed", "success",
  "attemptsUsed", "diagnostics", "strip"?, "analysis"?}` — `strip`/`analysis` present if and only if `success` is
  `true`; a failed reel's `diagnostics` carries every attempt made (not just the last one) with that attempt's own
  violations, the same information a `pokie build` failure would print, without failing the request as a whole
  (every other reel's result is still returned).
- `POST /api/home/blueprints/build-preview` `{"blueprint": <any JSON value>, "outDir"?: string, "sourcePath"?:
  string}` — validates the blueprint and previews what a build would generate, without writing anything: `200
  {"status": "invalid", "errors": [...], "warnings": [...]}` or `200 {"status": "ok", "warnings": [...],
  "manifest", "reels", "rows", "symbolsCount", "blueprintHash", "expectedFiles"}`, same reasoning as
  `GET /api/project/validate`.
- `POST /api/home/blueprints/build` — same request shape as the preview; on top of `invalid`, generates the package
  via the exact same `tsPackage` `ArtifactBuilderRegistry` conversion `pokie build <project> --target tsPackage`
  runs, including its missing-or-empty-directory check
  (an `outDir` resolving inside Studio's own internal directory is also refused, the same way as `save` above):
  `200 {"status": "error", "error": "..."}` or `201 {"status": "ok", "projectRoot", "manifest", "createdFiles",
  "buildInfo", "warnings"}` on success — the built project is also recorded as a recent project, so its
  **Open in Studio** button (`POST /api/home/projects/open` below) works exactly like every other Home flow's.
- `POST /api/home/projects/open` `{"projectRoot": string}` — loads `projectRoot` with `loadPokieGame` and switches
  Studio to Project mode on success (`200 {"context": {...}, "manifest": {...}}`); `400 {"error": "..."}` if it
  isn't a valid [game package](game-packages.md). This is the one explicit Home → Project Studio context
  transition — it mutates the same running server's state in place, never starting a new HTTP server or Studio
  process (see `StudioServer.handleHomeOpenProject`).
- `POST /api/projects/close` — switches back to Home mode.
- `GET /api/project/context` — the Project Dashboard's own read model, always one of the four states above:
  `{"status": "empty"}` / `{"status": "loading", "projectRoot": "..."}` /
  `{"status": "loaded", "projectRoot": "...", "game": {"id": "...", "name": "...", "version": "..."}}` /
  `{"status": "error", "projectRoot": "...", "error": "..."}`.
- `GET /api/project/inspect` — the active project's `GamePackageInspectionReport` (same shape as
  [`pokie inspect`](#pokie-inspect-packageroot)'s JSON), or `409 {"error": "No active project."}` in Home mode.
- `GET /api/project/validate` — the active project's Studio validation response (the package variant is a
  `PokieGamePackageValidationReport`; the CLI adds its own schemaVersion 1 wrapper documented at
  [`pokie validate`](#pokie-validate-project)), or `409 {"error": "No active project."}` in Home mode.
- `POST /api/project/simulations` `{"rounds": number, "seed"?: string, "workers"?: number}` — starts a simulation
  for the active project and returns immediately (`202`) with the new job in `"queued"` status; the simulation
  itself runs in the background, never blocking this request. `workers` defaults to `1` when omitted. `400
  {"error": "..."}` for an invalid `rounds` (missing, not an integer, less than 1, or above the safe Studio
  ceiling of 2,000,000 — see `MAX_STUDIO_SIMULATION_ROUNDS`), an invalid `seed` (present but empty/not a string),
  or an invalid `workers` (present but not an integer between 1 and `MAX_SIMULATION_WORKERS`, currently 32); `409
  {"error": "No active project."}` in Home mode; `409 {"error": "...", "activeJobId": "..."}` if a simulation is
  already queued/running for this project — a retried/duplicated request can never spawn a competing job or
  corrupt the one already in flight.
- `GET /api/project/simulations/:id` — that job's current state:
  `{id, status, rounds, seed?, workers, startedAt, roundsCompleted, durationMs, report?, statistics?, error?}` — `status` is
  `"queued"`/`"running"`/`"completed"`/`"failed"`/`"cancelled"`; `report` (a full `SimulationReport`, see
  [`pokie sim`](#pokie-sim-packageroot)) and `statistics` (the extra volatility/standard-deviation/confidence-
  interval fields `SimulationAccumulator` computes but `SimulationReport` itself doesn't carry) are only present
  once `status` is `"completed"`; `error` (a safe message, never a stack trace) only once `status` is `"failed"`.
  `404 {"error": "..."}` for an unknown id.
- `DELETE /api/project/simulations/:id` — requests cancellation of a queued/running job (returns its current
  view — the record only actually flips to `"cancelled"` once that's noticed, on the next `GET`/poll: at the next
  chunk boundary for `workers === 1`, or as soon as its worker threads are terminated for `workers > 1`);
  idempotent on an already-terminal job (just returns it unchanged, not an error). `404 {"error": "..."}` for an
  unknown id.
- `GET /api/project/reports` — the active project's completed simulations, most-recently-completed first:
  `{id, status: "completed", game: {id, version}, requestedRounds, actualRounds, seed?, workers, rtp, hitFrequency,
  maxWin, startedAt, completedAt, durationMs, hasWarnings}[]`. A failed/cancelled job never appears here (it has no report
  to summarize). `409 {"error": "No active project."}` in Home mode.
- `GET /api/project/reports/:id` — that simulation's full `SimulationReport` (same shape as
  [`pokie sim`](#pokie-sim-packageroot)'s own JSON). `404 {"error": "..."}` for an unknown id **or** one that
  belongs to a different project (deliberately indistinguishable from "unknown" — this can never be used to probe
  whether some other project has a simulation with a given id). `409 {"error": "..."}` if the simulation hasn't
  completed yet (still queued/running) or completed without a report (failed/cancelled) — the message names which.
- `GET /api/project/reports/:id/download?format=json|markdown|html` — the same report as a downloadable file:
  correct `Content-Type` per format (`application/json`, `text/markdown`, `text/html`, each `charset=utf-8`) and
  `Content-Disposition: attachment; filename="..."` with a filename built from the game id/version and simulation
  id (sanitized — any character outside `[a-zA-Z0-9._-]` is replaced, so this is safe regardless of what a game's
  id/version happen to contain). `400 {"error": "..."}` for a missing/invalid `format`; the same `404`/`409` cases
  as the JSON endpoint above otherwise.
- `POST /api/project/replays` `{"round": number, "seed"?: string}` — starts a replay for the active project and
  returns immediately (`202`) with the new job in `"queued"` status; the replay itself runs in the background,
  never blocking this request. `400 {"error": "..."}` for an invalid `round` (missing, not an integer, less than 1,
  or above the safe Studio ceiling of 100,000 — see `MAX_STUDIO_REPLAY_ROUND`) or an invalid `seed` (present but
  empty/not a string); `409 {"error": "No active project."}` in Home mode; `409 {"error": "...", "activeJobId":
  "..."}` if a replay is already queued/running for this project — a retried/duplicated request can never spawn a
  competing job or corrupt the one already in flight.
- `GET /api/project/replays/:id` — that job's current state: `{id, status, round, seed?, startedAt,
  completedRounds, durationMs, game?, descriptor?, error?}` — `status` is
  `"queued"`/`"running"`/`"completed"`/`"failed"`/`"cancelled"`; `game` (id/name/version) is known as soon as the
  package has loaded, before the round-playing loop even starts; `descriptor` (a `ReplayDescriptor`, same base
  shape as [`pokie replay`](#pokie-replay-packageroot)'s own JSON — including `screen: null` for a session without
  `getSymbolsCombination()` — but with three fields Studio's own execution path additionally populates that
  `pokie replay` never does: an optional `artifact` (the full `RoundArtifactJson` for the target round, only for a
  video-slot session — `getSymbolsCombination()` + `getWinEvaluationResult()`), and optional `stateBefore`/
  `stateAfter` (serialized session state immediately before/after the target round's `play()`, via the same
  session-serialization mechanism `pokie serve`'s own internal/debug response uses — absent when the game/session
  doesn't support it or capture failed, never a replay failure by itself)) is only present once `status` is
  `"completed"`; `error` (a safe message, never a stack trace) only once `status` is `"failed"`. `404 {"error":
  "..."}` for an unknown id **or** one that belongs to a different project (deliberately indistinguishable from
  "unknown", same reasoning as Reports' detail endpoint above); `409 {"error": "No active project."}` in Home mode.
- `DELETE /api/project/replays/:id` — requests cancellation of a queued/running replay (returns its current view —
  the record only actually flips to `"cancelled"` once the chunk loop notices, on the next `GET`/poll); idempotent
  on an already-terminal job (just returns it unchanged, not an error). `404 {"error": "..."}` for an unknown id or
  one belonging to a different project.
- `GET /api/project/replays` — the active project's most recent replay jobs regardless of status, most-recently-
  started first: `{id, status, game?, round, seed?, completedRounds, totalBet?, totalWin?, startedAt, completedAt?,
  durationMs, error?}[]` (no `screen` — fetch the detail endpoint for that). `409 {"error": "No active project."}`
  in Home mode.
- `GET /api/project/replays/:id/download` — the completed job's `ReplayDescriptor` as a downloadable JSON file:
  `Content-Type: application/json; charset=utf-8` and `Content-Disposition: attachment; filename="..."` with a
  filename built from the game id/version and replay id (sanitized the same way as Reports' download filenames).
  `404 {"error": "..."}` for an unknown id or one belonging to a different project; `409 {"error": "..."}` if the
  replay hasn't completed yet (still queued/running) or completed without a descriptor (failed/cancelled) — the
  message names which.
- `POST /api/project/replays/inspect-artifact` `{"round": number, "seed"?: string, "artifact"?: unknown}` — the
  Replay tab's own "Replay Artifact" Find/Load steps validating a pasted artifact JSON before attempting a
  reproduction: applies the exact same `round`/`seed` validation `POST /api/project/replays` itself applies (so
  this can never accept something the real replay start would then reject), and, only if `artifact` is present,
  runs it through `RoundArtifactValidator`. `200 {"round": number, "seed"?: string, "artifactWarnings": string[]}`
  — a structurally invalid `artifact` is reported back as non-fatal `artifactWarnings`, never a failure by itself,
  since `round`/`seed` alone are enough to attempt a reproduction. `400 {"error": "..."}` for an invalid
  `round`/`seed`; `409 {"error": "No active project."}` in Home mode.
- `GET /api/project/rounds` — the active project's shared, cross-tab recent-spins list (see
  [Session Spin](#replay) above), most-recent-first: `StudioRuntimeSessionView[]`, each including `studioRound`
  (session-local round index), `studioRequestId` (when the producer supplied one), `studioRecordedAt`,
  `studioSource` (which tab/route produced it — `"play"`, `"play-outcome-source"`, `"outcome-source-sample"`, or
  `"simulation-sample"`). Always `200`, possibly an empty array (nothing played yet, or the project was since
  switched) — never an error for "nothing to show". `409 {"error": "No active project."}` in Home mode.
- `GET /api/project/deployment/targets` — every registered [External Adapter SDK](external-adapter-sdk.md)
  target's `{id, version, requirements, capabilities}` (empty until a project registers a real
  `ExternalDeploymentTarget` — see Build/Export's own "Remote deployment" card above). `409 {"error": "No
  active project."}` in Home mode.
- `POST /api/project/deployment/runs` `{"targetId": string, "modes"?: [{"modeName": string, "librarySelector":
  {"kind": "json" | "bundle" | "stakeengine", ...}}], "publish"?: boolean}` — runs
  `ExternalDeploymentService.deploy()` (the SDK's own single orchestrator) for `targetId`. Omitting `modes` asks
  the canonical project planner to resolve compatible registered Outcome Libraries; supplied modes use the same
  project-contained `librarySelector` contract as Studio Stake export: `json` selects a raw library file, `bundle`
  selects a named mode from a canonical Outcome Library bundle, and `stakeengine` selects a named mode from a Stake
  Engine export. `publish` defaults to `false` — a side-effect-free preview, since the target's own
  `runtimeAdapter` is stripped before `deploy()` is called; `true` keeps it, so a successful run actually
  publishes. `400 {"error": "..."}` for a structurally malformed request (`targetId`, an explicitly supplied
  empty `modes` list, duplicate/missing mode names, malformed `librarySelector`, or non-boolean `publish`). The
  service then reports selector containment, mode/provenance, source-read, compatibility and target failures in
  the returned run view, with the matching repair/rebuild/reselect recovery. `404 {"error": "Unknown deployment
  target \"...\"."}` for an unknown `targetId`. Otherwise always `200` with the SDK's own
  `ExternalDeploymentResult`, mirrored field-for-field (every generated artifact's `content` decoded to a plain
  string) — a domain-level pipeline failure (incompatible content, a failed projector, an unwritable output
  directory, ...) is carried in that DTO's own stage-by-stage issue arrays, never a 4xx/5xx, the same "only a
  malformed request throws" convention every other Project Dashboard route follows. `409 {"error": "No active
  project."}` in Home mode.

## Workflow

A typical end-to-end loop, from a fresh directory to a running dev server, chaining every subcommand above:

```
pokie init sample-slot

pokie validate ./sample-slot

pokie sim ./sample-slot --rounds 100000 --seed before --out before.json
pokie report before.json --format markdown --out before.md

# ...tweak the game's paytable/config...

pokie sim ./sample-slot --rounds 100000 --seed before --out after.json
pokie diff before.json after.json

pokie replay ./sample-slot --seed before --round 42 --out replay.json

pokie dev ./sample-slot
```

Each step builds on the same `<packageRoot>`:

- [`validate`](#pokie-validate-project) needs a prepared package (`pokie init`, or `pokie build` + the
  same-shaped output) — it checks the contract before anything else runs.
- [`sim --out`](#pokie-sim-packageroot) produces the JSON report that
  [`report`](#pokie-report-simulationreportjson) renders and [`diff`](#pokie-diff-leftprojectorreportjson-rightprojectorreportjson)
  compares — run `sim` twice (before/after a config change, same `--seed`) to get two reports worth diffing.
- [`replay`](#pokie-replay-packageroot) is independent of `sim`'s output files, but reproducibility across all
  three of `sim`/`diff`/`replay` depends on the same caveat: the game package must actually thread `context.seed`
  into a deterministic RNG for `--seed` to mean anything (see [Limitations](#limitations) below).
- [`dev`](#pokie-dev-packageroot) (or `serve`/`client` run separately) is normally the last,
  interactive step, not part of a scripted pipeline — it only needs the same built package and runs until
  stopped. `pokie build`/`pokie init` already scaffold `npm run start`/`server`/`client` scripts wrapping these
  three commands.

## What's next

All 21 public top-level commands this file documents (`build`/`certification`/`client`/`create`/`dev`/`diff`/
`edit`/`export`/`fairness`/`generate`/`import`/`init`/`inspect`/`reel`/`replay`/`report`/`sample`/`serve`/`sim`/
`validate`) are shipped today, built on the same [game package](game-packages.md) primitives (`loadPokieGame`,
`isPokieGame`, `PokieGameContractValidationRule`). [POKIE Studio](#pokie) already
covers most of these workflows with a real GUI, not just the CLI: designing/building a game (Home's Design Game
tab, including PAR Sheet import/export and reel strip generation), and, once a project is open, inspection/
validation (Overview), the Game Model view, Play, Simulation, Replay, Build/Export (outcome library generation,
static export, build artifacts, and remote deployment via the External Adapter SDK), Certification/Evidence
Bundle, and Fairness all have a working Studio surface — see [`HomePage`/`ProjectDashboardPage`](studio-frontend.md)
for each tab. `pokie serve`/`pokie dev`/`pokie client` have no Studio GUI
counterpart — Studio's own Play tab drives a real session entirely in-process instead; use the CLI directly to
stand up an HTTP server. The generic `StudioToolHandling` extension seam
(`cli/studio/StudioToolHandling.ts`) is unused dead code today — every Studio surface above is wired as its own
bespoke route on `StudioServer`, not through that seam — kept only as a documented possible future refactor, not
a gap in coverage.

Genuinely not yet covered, tracked as post-v1.3 candidates rather than gaps in this CLI: a named
expanding/sticky-wilds session decorator (the generic `SymbolOverlayTransformer` primitive already supports
building one), property-based/golden-snapshot testing, a docs site/playground, and any FromStan org/npm
migration work. Performance benchmarks are covered (`npm run bench` — see
[`docs/testing.md`](testing.md#benchmarks)), not part of this CLI's own surface.

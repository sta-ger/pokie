import crypto from "crypto";
import {buildPreGeneratedRoundResult} from "../../pregenerated/buildPreGeneratedRoundResult.js";
import {deriveDeterministicSeed} from "../../pregenerated/internal/deriveDeterministicSeed.js";
import {PreGeneratedOutcomeSelectionValidator} from "../../pregenerated/PreGeneratedOutcomeSelectionValidator.js";
import type {PreGeneratedOutcomeSelection} from "../../pregenerated/PreGeneratedOutcomeSelection.js";
import {PreGeneratedOutcomeSourceConflictError} from "../../pregenerated/PreGeneratedOutcomeSourceConflictError.js";
import type {PreGeneratedOutcomeSourcing} from "../../pregenerated/PreGeneratedOutcomeSourcing.js";
import type {PreGeneratedRoundTransaction} from "../../pregenerated/PreGeneratedRoundTransaction.js";
import {SeededWeightedOutcomeRandomSource} from "../../pregenerated/SeededWeightedOutcomeRandomSource.js";
import {InMemoryIdempotencyRepository} from "../idempotency/InMemoryIdempotencyRepository.js";
import type {IdempotencyRepository} from "../idempotency/IdempotencyRepository.js";
import type {TransactionalWalletPort} from "../wallet/TransactionalWalletPort.js";
import {InMemoryPreGeneratedSessionRepository} from "./InMemoryPreGeneratedSessionRepository.js";
import {isVersionedPreGeneratedSessionRepository} from "./isVersionedPreGeneratedSessionRepository.js";
import {PreGeneratedSessionVersionConflictError} from "./PreGeneratedSessionVersionConflictError.js";
import type {PreGeneratedSessionRepository} from "./PreGeneratedSessionRepository.js";
import type {PreGeneratedSessionState} from "./PreGeneratedSessionState.js";
import type {PreGeneratedSpinCommandHandling} from "./PreGeneratedSpinCommandHandling.js";
import type {PreGeneratedSpinCommandResult} from "./PreGeneratedSpinCommandResult.js";

// Orchestrates a single pre-generated round end-to-end: deterministically draw the next round's outcome from a
// configured PreGeneratedOutcomeSourcing (never running a game's own calculation path), replay an idempotent
// retry, settle the wallet from that outcome's already-known stake/totalWin, and persist the new state together
// with the idempotency result as one committed outcome. Mirrors SpinCommandHandler's own orchestration shape
// (idempotency replay, per-session serialization, wallet settlement, best-effort compensation,
// optimistic-locking conflict detection) applied to a pre-enumerated outcome source instead of a live
// GameSessionHandling. The outcome source is deliberately abstract (see PreGeneratedOutcomeSourcing) — an
// already-built WeightedOutcomeLibrary in memory (InMemoryPreGeneratedOutcomeSource) or a canonical outcome-
// library bundle read directly off disk (OutcomeLibraryBundleOutcomeSource), one index read per draw, never a
// full library materialized — this handler never knows or cares which.
//
// Every command for a given sessionId is serialized through a per-session queue (see enqueue()), same
// mechanism and same rationale as SpinCommandHandler: it's what makes a concurrently repeated requestId
// safe without a separate "in-flight" cache.
//
// Wallet settlement needs no live-session reconciliation the way SpinCommandHandler's does — the
// outcome's own artifact.stake/artifact.totalWin are already exact, canonical numbers, so this simply
// debits the stake and (when totalWin > 0) credits the win, in that order.
//
// Every wallet transaction for an attempt gets its own id, `{roundId}:{attemptId}:debit`/`:credit` —
// `roundId` is the requestId (or a fresh id when none was given), stable across every retry of that
// same logical request; `attemptId` is freshly minted every time this method actually runs, exactly
// mirroring SpinCommandHandler's own convention (see its class doc comment for the full rationale).
// This matters even more here than it might first appear: two separate PreGeneratedSpinCommandHandler
// instances (e.g. two server processes) can both be asked to settle the *same* (sessionId, requestId)
// — say, a client retry that landed on a different instance while the first instance's attempt is
// still in flight. Without a fresh attemptId, both attempts would derive the exact same transaction
// ids for the same requestId; if the second (losing) attempt's own optimistic-locking save then
// conflicts and its compensation reverses "its" transactions, it would actually be reversing the
// *first* (winning) attempt's already-committed, identically-id'd transactions — corrupting a round
// that had already legitimately settled. A fresh attemptId per attempt keeps every attempt's own
// transactions uniquely identified, so a losing attempt's compensation can only ever touch its own.
//
// Round-to-round determinism: round index `state.roundsPlayed + 1` combined with the session's own
// seed (see deriveDeterministicSeed) is what PreGeneratedRoundReplayer reproduces later — the session
// itself never stores anything about *which* outcome a past round drew, only how many rounds have been
// played, since the outcome is always exactly reproducible from (seed, round) against the same library.
//
// Library identity check: a loaded session's own `libraryId`/`libraryHash` (stamped at creation) is compared
// against the *exact* identity the outcome source reports it just drew from — not a separately-fetched,
// potentially stale or newer snapshot. The draw always happens first (deterministic, no wallet/session side
// effects yet), immediately followed by this comparison, before the idempotency cache is ever consulted and
// before any wallet transaction — so a bundle-backed source rebuilt in between two calls can never have its
// identity check and its selection straddle two different versions: whichever version the very next draw
// actually came from is exactly what gets compared. A mismatch — a session created against a different
// library/bundle content, or the same libraryId since regenerated with different weights — returns a
// "conflict" result immediately, with nothing left to compensate.
//
// Two more checks run in that same pre-wallet window, immediately after the draw: a PreGeneratedOutcomeSourceConflictError
// thrown by drawOutcome() itself (a source-level conflict — e.g. a bundle whose outcomes file changed between
// the index being read and the winning record's own byte range being read, mid-draw, within that single call —
// see OutcomeLibraryBundleOutcomeSource) is caught and turned into "conflict" the same way; and the drawn
// selection is run through PreGeneratedOutcomeSelectionValidator, so a forged or malformed selection (a buggy or
// malicious custom PreGeneratedOutcomeSourcing implementation is just as capable of producing one as a real
// adapter drifting out of sync) is rejected before it ever reaches the wallet either.
//
// Optimistic locking: when sessionRepository additionally implements VersionedPreGeneratedSessionRepository
// (see isVersionedPreGeneratedSessionRepository.ts — InMemoryPreGeneratedSessionRepository does), the
// state loaded at the start of an attempt is saved back via saveVersioned() with the version it was read
// at, instead of the plain unconditional save(). This mainly protects a repository *shared across
// multiple PreGeneratedSpinCommandHandler instances* — within one instance, every command for a given
// sessionId is already serialized through enqueue()/sessionQueues above, so its own load-then-save can
// never race against itself. A version mismatch (someone else's save landed in between) surfaces as a
// PreGeneratedSessionVersionConflictError, caught below and turned into a "conflict"
// PreGeneratedSpinCommandResult after the same wallet-reversal/session-eviction compensation any other
// mid-flight failure gets — never a silent overwrite of whatever the other attempt committed.
//
// Best-effort compensation on failure mirrors SpinCommandHandler's own: every wallet transaction this
// attempt applied is individually reversed, and an already-saved session state is restored to what it
// was before this attempt — see SpinCommandHandler's class doc comment for the same process-crash and
// compensation-failure caveats, which apply here identically.
export class PreGeneratedSpinCommandHandler<T extends string | number = string> implements PreGeneratedSpinCommandHandling<T> {
    private readonly outcomeSource: PreGeneratedOutcomeSourcing<T>;
    private readonly wallet: TransactionalWalletPort;
    private readonly sessionRepository: PreGeneratedSessionRepository;
    private readonly idempotencyRepository: IdempotencyRepository<PreGeneratedSpinCommandResult<T>>;
    private readonly selectionValidator = new PreGeneratedOutcomeSelectionValidator<T>();
    private readonly sessionQueues = new Map<string, Promise<unknown>>();

    constructor(
        outcomeSource: PreGeneratedOutcomeSourcing<T>,
        wallet: TransactionalWalletPort,
        sessionRepository: PreGeneratedSessionRepository = new InMemoryPreGeneratedSessionRepository(),
        idempotencyRepository: IdempotencyRepository<PreGeneratedSpinCommandResult<T>> = new InMemoryIdempotencyRepository(),
    ) {
        this.outcomeSource = outcomeSource;
        this.wallet = wallet;
        this.sessionRepository = sessionRepository;
        this.idempotencyRepository = idempotencyRepository;
    }

    public handle(sessionId: string, requestId?: string): Promise<PreGeneratedSpinCommandResult<T>> {
        return this.enqueue(sessionId, () => this.handleSerialized(sessionId, requestId));
    }

    // Identical mechanism to SpinCommandHandler's own enqueue(): chains `work` onto whatever is already
    // queued for `sessionId`, so a concurrently repeated requestId only ever runs once.
    private enqueue<R>(sessionId: string, work: () => Promise<R>): Promise<R> {
        const previous = this.sessionQueues.get(sessionId) ?? Promise.resolve();
        const result = previous.then(work, work);
        this.sessionQueues.set(
            sessionId,
            result.then(
                () => undefined,
                () => undefined,
            ),
        );
        return result;
    }

    private async handleSerialized(sessionId: string, requestId: string | undefined): Promise<PreGeneratedSpinCommandResult<T>> {
        const {state, version} = await this.loadState(sessionId);
        if (!state) {
            return {status: "not-found", sessionId};
        }

        // The draw always happens first — deterministic, no wallet/session side effects — so every check below
        // always relates to the *exact* version this same draw came from, never a separately, independently
        // re-fetched one. All of it runs before consulting the idempotency cache: a cached result was
        // necessarily computed against whatever the source reported at the time, which a stale cache entry has
        // no way to reverify on its own. Nothing has been applied yet at this point (no wallet transaction), so
        // there's nothing to compensate — unlike the storage-level version conflict below, which can only be
        // discovered after settlement has already run.
        const round = state.roundsPlayed + 1;
        const randomSource = new SeededWeightedOutcomeRandomSource(deriveDeterministicSeed(state.seed, round));

        let selection: PreGeneratedOutcomeSelection<T>;
        try {
            selection = await this.outcomeSource.drawOutcome(randomSource);
        } catch (error) {
            // A source-level conflict (see PreGeneratedOutcomeSourceConflictError's own doc comment) — the
            // content this draw relied on no longer matches what the source itself last promised (e.g. a
            // bundle rewritten mid-draw). Any other error is a genuine fault, not an operational conflict, and
            // propagates unchanged.
            if (error instanceof PreGeneratedOutcomeSourceConflictError) {
                return {status: "conflict", sessionId, reason: error.message};
            }
            throw error;
        }

        // A forged/malformed selection — a buggy or malicious custom PreGeneratedOutcomeSourcing implementation
        // is just as capable of producing one as a real adapter drifting out of sync — is treated the same way:
        // this source cannot be trusted for this draw, so nothing proceeds.
        const selectionIssues = this.selectionValidator.validate(selection);
        if (selectionIssues.length > 0) {
            return {
                status: "conflict",
                sessionId,
                reason: `Session "${sessionId}"'s outcome source returned an invalid selection: ${selectionIssues.map((issue) => issue.code).join(", ")}.`,
            };
        }

        if (selection.libraryId !== state.libraryId || selection.libraryHash !== state.libraryHash) {
            return {
                status: "conflict",
                sessionId,
                reason:
                    `Session "${sessionId}" was created against a different library than this handler's outcome ` +
                    `source currently reports (libraryId "${state.libraryId}"/hash "${state.libraryHash}" vs ` +
                    `current libraryId "${selection.libraryId}"/hash "${selection.libraryHash}").`,
            };
        }

        if (requestId !== undefined) {
            const cached = await this.idempotencyRepository.load(sessionId, requestId);
            if (cached !== undefined) {
                return cached;
            }
        }

        return this.settle(sessionId, state, version, requestId, round, selection);
    }

    // Reads both the state and, when sessionRepository supports it, the version it was read at — a
    // single call either way, never a redundant second read on the plain-repository path. Mirrors
    // SpinCommandHandler's own loadState() exactly.
    private async loadState(sessionId: string): Promise<{state: PreGeneratedSessionState | undefined; version: number | undefined}> {
        if (isVersionedPreGeneratedSessionRepository(this.sessionRepository)) {
            const versioned = await this.sessionRepository.loadVersioned(sessionId);
            return {state: versioned?.state, version: versioned?.version};
        }
        return {state: await this.sessionRepository.load(sessionId), version: undefined};
    }

    private async settle(
        sessionId: string,
        state: PreGeneratedSessionState,
        expectedVersion: number | undefined,
        requestId: string | undefined,
        round: number,
        selection: PreGeneratedOutcomeSelection<T>,
    ): Promise<PreGeneratedSpinCommandResult<T>> {
        const roundId = requestId ?? crypto.randomUUID();
        const attemptId = crypto.randomUUID();
        const outcome = selection.outcome;

        const debitTransactionId = `${roundId}:${attemptId}:debit`;
        const creditTransactionId = `${roundId}:${attemptId}:credit`;
        const appliedTransactionIds: string[] = [];
        let sessionStateSaved = false;

        try {
            const balanceBefore = await this.wallet.getBalance(sessionId);
            let balanceAfter = await this.wallet.debit(sessionId, debitTransactionId, outcome.artifact.stake);
            appliedTransactionIds.push(debitTransactionId);

            const transactions: PreGeneratedRoundTransaction[] = [
                {id: debitTransactionId, type: "debit", amount: outcome.artifact.stake},
            ];
            if (outcome.artifact.totalWin > 0) {
                balanceAfter = await this.wallet.credit(sessionId, creditTransactionId, outcome.artifact.totalWin);
                appliedTransactionIds.push(creditTransactionId);
                transactions.push({id: creditTransactionId, type: "credit", amount: outcome.artifact.totalWin});
            }

            const result = buildPreGeneratedRoundResult({
                expectedLibraryId: state.libraryId,
                expectedLibraryHash: state.libraryHash,
                selection,
                runtime: {
                    roundId,
                    sessionId,
                    ...(requestId !== undefined ? {requestId} : {}),
                    balanceBefore,
                    balanceAfter,
                    transactions,
                },
            });

            const newState: PreGeneratedSessionState = {
                libraryId: state.libraryId,
                libraryHash: state.libraryHash,
                seed: state.seed,
                roundsPlayed: round,
            };

            let newVersion: number | undefined;
            if (isVersionedPreGeneratedSessionRepository(this.sessionRepository) && expectedVersion !== undefined) {
                newVersion = await this.sessionRepository.saveVersioned(sessionId, newState, expectedVersion);
            } else {
                await this.sessionRepository.save(sessionId, newState);
            }
            sessionStateSaved = true;

            const commandResult: PreGeneratedSpinCommandResult<T> = {status: "played", sessionId, result};
            if (newVersion !== undefined) {
                commandResult.version = newVersion;
            }
            if (requestId !== undefined) {
                await this.idempotencyRepository.save(sessionId, requestId, commandResult);
            }
            return commandResult;
        } catch (error) {
            if (sessionStateSaved) {
                await this.restoreSessionState(sessionId, state);
            }
            await this.reverseApplied(sessionId, appliedTransactionIds);
            if (error instanceof PreGeneratedSessionVersionConflictError) {
                return {status: "conflict", sessionId, reason: error.message};
            }
            throw error;
        }
    }

    // Best-effort compensating write, undoing this attempt's own sessionRepository.save() when a later
    // step (persisting the idempotency result) fails — see the class doc comment for the risk
    // discussion this shares with SpinCommandHandler's own restoreSessionState().
    private async restoreSessionState(sessionId: string, state: PreGeneratedSessionState): Promise<void> {
        try {
            await this.sessionRepository.save(sessionId, state);
        } catch {
            // The error that triggered this restore is what the caller of handle() sees; a failure to
            // restore shouldn't replace or hide it.
        }
    }

    private async reverseApplied(sessionId: string, transactionIds: string[]): Promise<void> {
        for (const transactionId of transactionIds.slice().reverse()) {
            try {
                await this.wallet.reverse(sessionId, transactionId);
            } catch {
                // Best-effort compensation — see the class doc comment.
            }
        }
    }
}
